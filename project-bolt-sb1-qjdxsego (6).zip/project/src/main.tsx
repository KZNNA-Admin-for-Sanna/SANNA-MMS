import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import * as Sentry from '@sentry/react';
import App from './App';
import './index.css';
import { initErrorTracking } from './lib/errorTracking';

// Initialize error tracking
initErrorTracking();

// Create error boundary wrapper
const SentryErrorBoundary = Sentry.ErrorBoundary;

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <SentryErrorBoundary fallback={<p>An error has occurred</p>}>
      <App />
    </SentryErrorBoundary>
  </StrictMode>
);