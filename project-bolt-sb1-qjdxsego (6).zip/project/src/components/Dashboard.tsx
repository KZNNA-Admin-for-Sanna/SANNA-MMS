import React, { useState } from 'react';
import { Member, PNAType } from '../types/member';
import { differenceInDays, format } from 'date-fns';
import { BulkEmailForm } from './BulkEmailForm';
import { AlertTriangle, Wallet, Mail } from 'lucide-react';

interface DashboardProps {
  members: Member[];
}

export function Dashboard({ members }: DashboardProps) {
  const [showEmailForm, setShowEmailForm] = useState(false);
  
  const activeMembers = members.filter((m) => m.status === 'Active').length;
  const dormantMembers = members.filter((m) => m.status === 'Dormant').length;
  const honoraryMembers = members.filter((m) => m.membership_type === 'honorary').length;
  
  const activeMembersSum = members
    .filter(m => m.status === 'Active')
    .reduce((total, member) => total + member.amount_paid, 0);

  const dormantMembersSum = members
    .filter(m => m.status === 'Dormant')
    .reduce((total, member) => total + member.amount_paid, 0) * -1;

  const pnaRevenue = members
    .filter(m => m.status === 'Active')
    .reduce((acc, member) => {
      if (!acc[member.pna]) {
        acc[member.pna] = 0;
      }
      acc[member.pna] += member.amount_paid;
      return acc;
    }, {} as Record<PNAType, number>);

  const pnaNames: Record<PNAType, string> = {
    'GNA': 'Gauteng Naturist Association',
    'KZNNA': 'KwaZulu-Natal Naturist Association',
    'WPNA': 'Western Province Naturist Association',
    'NWNA': 'North West Naturist Association',
    'IMNA': 'Individual Members Naturist Association',
    'SANYA': 'South African Naturist Youth Association',
    'FSNA': 'Free State Naturist Association',
    'NCNA': 'Northern Cape Naturist Association',
    'LNA': 'Limpopo Naturist Association',
    'MPNA': 'Mpumalanga Naturist Association',
    'ECNA': 'Eastern Cape Naturist Association',
    'WCNA': 'Western Cape Naturist Association'
  };

  const expiringMembers = members
    .filter((m) => {
      if (!m.date_renewed || m.membership_type === 'honorary') return false;
      const daysUntilExpiry = differenceInDays(
        new Date(new Date(m.date_renewed).setFullYear(new Date(m.date_renewed).getFullYear() + 1)),
        new Date()
      );
      return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
    })
    .sort((a, b) => {
      const aExpiry = new Date(new Date(a.date_renewed!).setFullYear(new Date(a.date_renewed!).getFullYear() + 1));
      const bExpiry = new Date(new Date(b.date_renewed!).setFullYear(new Date(b.date_renewed!).getFullYear() + 1));
      return differenceInDays(aExpiry, bExpiry);
    });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZA', {
      style: 'currency',
      currency: 'ZAR',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  return (
    <>
      <div className="mb-4 bg-gray-100 p-4 rounded-lg shadow-light-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-4">
          <div className="flex items-center">
            <Wallet className="h-6 w-6 text-light-action-primary mr-2" />
            <h2 className="text-xl font-semibold text-light-text-primary">Total Revenue</h2>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowEmailForm(true)}
              className="flex items-center px-4 py-2 bg-light-action-secondary text-white rounded-md hover:bg-opacity-90"
            >
              <Mail className="h-5 w-5 mr-2" />
              Send Bulk Email
            </button>
            <p className="text-2xl font-bold text-light-action-primary">
              {formatCurrency(activeMembersSum)}
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(pnaRevenue).map(([pna, amount]) => (
            <div key={pna} className="flex justify-between items-center p-2 bg-gray-100 rounded shadow-light-sm">
              <div className="text-sm">
                <div className="font-medium text-light-text-primary">{pna}</div>
                <div className="text-light-text-secondary text-xs truncate max-w-[200px]">{pnaNames[pna as PNAType]}</div>
              </div>
              <div className="font-medium text-light-action-primary">
                {formatCurrency(amount)}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gray-100 p-6 rounded-lg shadow-light-md">
          <h3 className="text-lg font-semibold text-light-text-primary">Active Members</h3>
          <p className="text-3xl font-bold text-light-action-primary">{activeMembers}</p>
          <div className="mt-2 flex items-center">
            <Wallet className="h-4 w-4 text-light-action-primary mr-2" />
            <span className="text-sm text-light-text-primary">
              Total: {formatCurrency(activeMembersSum)}
            </span>
          </div>
        </div>

        <div className="bg-gray-100 p-6 rounded-lg shadow-light-md">
          <h3 className="text-lg font-semibold text-light-text-primary">Dormant Members</h3>
          <p className="text-3xl font-bold text-light-action-error">{dormantMembers}</p>
          <div className="mt-2 flex items-center">
            <Wallet className="h-4 w-4 text-light-action-error mr-2" />
            <span className="text-sm text-light-action-error">
              Lost Revenue: {formatCurrency(dormantMembersSum)}
            </span>
          </div>
        </div>

        <div className="bg-gray-100 p-6 rounded-lg shadow-light-md">
          <h3 className="text-lg font-semibold text-light-text-primary">Honorary Members</h3>
          <p className="text-3xl font-bold text-light-action-gold">{honoraryMembers}</p>
        </div>

        <div className="bg-gray-100 p-6 rounded-lg shadow-light-md relative group">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-lg font-semibold text-light-text-primary">Expiring Soon</h3>
              <p className="text-3xl font-bold text-light-action-secondary">{expiringMembers.length}</p>
            </div>
            {expiringMembers.length > 0 && (
              <AlertTriangle className="h-6 w-6 text-light-action-secondary animate-pulse" />
            )}
          </div>
          
          {expiringMembers.length > 0 && (
            <div className="mt-4 space-y-2">
              <p className="text-sm font-medium text-light-text-primary">Upcoming Expirations:</p>
              <div className="max-h-32 overflow-y-auto">
                {expiringMembers.map((member) => {
                  const expiryDate = new Date(new Date(member.date_renewed!).setFullYear(new Date(member.date_renewed!).getFullYear() + 1));
                  const daysLeft = differenceInDays(expiryDate, new Date());
                  return (
                    <div key={member.id} className="text-sm text-light-text-secondary">
                      <div className="truncate">{member.first_name} {member.surname}</div>
                      <div className="text-light-action-secondary">
                        {daysLeft} {daysLeft === 1 ? 'day' : 'days'} left
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {showEmailForm && (
        <BulkEmailForm onClose={() => setShowEmailForm(false)} />
      )}
    </>
  );
}