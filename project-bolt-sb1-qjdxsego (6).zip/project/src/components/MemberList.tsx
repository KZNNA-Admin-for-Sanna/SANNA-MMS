import React, { useState, useMemo } from 'react';
import { Member, MemberNote, PNAType } from '../types/member';
import { format, differenceInDays, differenceInMonths, differenceInYears, addMonths } from 'date-fns';
import { supabase } from '../lib/supabase';
import { UserCircle, AlertTriangle, Wallet, ArrowUpDown, FileSpreadsheet, Clock, Edit2, Trash2 } from 'lucide-react';
import { MemberProfile } from './MemberProfile';
import { MemberEditForm } from './MemberEditForm';
import toast from 'react-hot-toast';
import * as XLSX from 'xlsx';

interface MemberListProps {
  members: Member[];
  onEdit: (member: Member) => void;
  onDelete: (member: Member) => void;
}

type SortField = 'membership_type' | 'pna' | 'status' | 'surname';
type SortDirection = 'asc' | 'desc';

const pnaColors: Record<PNAType, string> = {
  'GNA': 'bg-blue-500',
  'KZNNA': 'bg-green-500',
  'WPNA': 'bg-yellow-500',
  'NWNA': 'bg-purple-500',
  'IMNA': 'bg-pink-500',
  'SANYA': 'bg-orange-500',
  'FSNA': 'bg-red-500',
  'NCNA': 'bg-indigo-500',
  'LNA': 'bg-teal-500',
  'MPNA': 'bg-cyan-500',
  'ECNA': 'bg-emerald-500',
  'WCNA': 'bg-violet-500'
};

export function MemberList({ members, onEdit, onDelete }: MemberListProps) {
  const [selectedMember, setSelectedMember] = useState<string | null>(null);
  const [notes, setNotes] = useState<MemberNote[]>([]);
  const [showProfile, setShowProfile] = useState<Member | null>(null);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [sortField, setSortField] = useState<SortField>('surname');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [membershipFilter, setMembershipFilter] = useState<string>('all');
  const [pnaFilter, setPnaFilter] = useState<string>('all');

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getTimeSinceJoined = (joinDate: string) => {
    const years = differenceInYears(new Date(), new Date(joinDate));
    const months = differenceInMonths(new Date(), new Date(joinDate)) % 12;
    
    let timeString = '';
    if (years > 0) {
      timeString += `${years}y`;
    }
    if (months > 0) {
      if (timeString) timeString += ' ';
      timeString += `${months}m`;
    }
    if (!timeString) {
      timeString = '<1m';
    }
    return timeString;
  };

  const sortedAndFilteredMembers = useMemo(() => {
    let filtered = [...members];

    if (membershipFilter !== 'all') {
      filtered = filtered.filter(m => m.membership_type === membershipFilter);
    }
    if (pnaFilter !== 'all') {
      filtered = filtered.filter(m => m.pna === pnaFilter);
    }

    return filtered.sort((a, b) => {
      let comparison = 0;
      switch (sortField) {
        case 'membership_type':
          comparison = a.membership_type.localeCompare(b.membership_type);
          break;
        case 'pna':
          comparison = a.pna.localeCompare(b.pna);
          break;
        case 'status':
          comparison = a.status.localeCompare(b.status);
          break;
        case 'surname':
          comparison = a.surname.localeCompare(b.surname);
          break;
      }
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [members, sortField, sortDirection, membershipFilter, pnaFilter]);

  function isExpiringSoon(member: Member): boolean {
    if (!member.date_renewed || member.membership_type === 'honorary') return false;
    const monthsSinceRenewal = differenceInMonths(new Date(), new Date(member.date_renewed));
    return monthsSinceRenewal >= 11 && monthsSinceRenewal < 12;
  }

  function getDaysUntilExpiry(member: Member): number | null {
    if (!member.date_renewed || member.membership_type === 'honorary') return null;
    const expiryDate = addMonths(new Date(member.date_renewed), 12);
    return differenceInDays(expiryDate, new Date());
  }

  const getStatusColor = (status: string, member: Member) => {
    if (isExpiringSoon(member)) {
      return 'bg-light-action-secondary text-white';
    }
    switch (status) {
      case 'Dormant':
        return 'bg-light-action-error/30 text-light-action-error';
      case 'Resigned':
        return 'bg-black text-white';
      case 'Banned':
        return 'bg-light-action-error text-white';
      default:
        return 'bg-light-action-primary text-white';
    }
  };

  const getMembershipBadge = (type: string) => {
    switch (type) {
      case 'honorary':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-light-action-gold text-white">Honorary</span>;
      default:
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-light-elevated text-light-text-secondary">Annual</span>;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZA', {
      style: 'currency',
      currency: 'ZAR',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const handleExportToExcel = () => {
    try {
      const exportData = sortedAndFilteredMembers.map(member => ({
        'INF Number': member.inf_stamp_number,
        'First Name': member.first_name,
        'Surname': member.surname,
        'Email': member.email || '',
        'Telephone': member.telephone || '',
        'Town': member.town || '',
        'Suburb': member.suburb || '',
        'PNA': member.pna,
        'Membership Type': member.membership_type,
        'Status': member.status,
        'Join Date': member.join_date ? format(new Date(member.join_date), 'dd/MM/yyyy') : '',
        'Last Renewed': member.date_renewed ? format(new Date(member.date_renewed), 'dd/MM/yyyy') : '',
        'Amount Paid': member.amount_paid,
        'Outstanding Balance': member.outstanding_balance
      }));

      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Members');
      const fileName = `members_${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
      XLSX.writeFile(wb, fileName);
      
      toast.success('Members exported successfully');
    } catch (error) {
      console.error('Error exporting members:', error);
      toast.error('Failed to export members');
    }
  };

  const SortButton = ({ field, label }: { field: SortField; label: string }) => (
    <button
      onClick={() => handleSort(field)}
      className="flex items-center space-x-1 hover:text-light-action-primary"
    >
      <span>{label}</span>
      <ArrowUpDown className={`h-4 w-4 ${sortField === field ? 'text-light-action-primary' : 'text-light-text-secondary'}`} />
    </button>
  );

  return (
    <div className="overflow-x-auto bg-light-surface rounded-lg shadow-light-md">
      {showProfile && !editingMember && (
        <MemberProfile
          member={showProfile}
          onClose={() => setShowProfile(null)}
          onUpdate={() => {
            setShowProfile(null);
            window.location.reload();
          }}
        />
      )}

      {editingMember && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-light-surface rounded-lg shadow-light-lg max-w-4xl w-full m-4 max-h-[90vh] overflow-y-auto">
            <MemberEditForm
              member={editingMember}
              onSave={() => {
                setEditingMember(null);
                window.location.reload();
              }}
              onCancel={() => setEditingMember(null)}
            />
          </div>
        </div>
      )}

      <div className="p-4 border-b border-light-elevated">
        <div className="flex flex-wrap gap-4 items-center justify-between">
          <div className="flex gap-4">
            <div>
              <label className="block text-sm font-medium text-light-text-secondary mb-1">
                Membership Type
              </label>
              <select
                value={membershipFilter}
                onChange={(e) => setMembershipFilter(e.target.value)}
                className="rounded-md border-light-elevated bg-light-surface text-light-text-primary focus:border-light-action-primary focus:ring-light-action-primary"
              >
                <option value="all">All Types</option>
                <option value="annual">Annual</option>
                <option value="honorary">Honorary</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-light-text-secondary mb-1">
                PNA
              </label>
              <select
                value={pnaFilter}
                onChange={(e) => setPnaFilter(e.target.value)}
                className="rounded-md border-light-elevated bg-light-surface text-light-text-primary focus:border-light-action-primary focus:ring-light-action-primary"
              >
                <option value="all">All PNAs</option>
                <option value="GNA">GNA</option>
                <option value="KZNNA">KZNNA</option>
                <option value="WPNA">WPNA</option>
                <option value="NWNA">NWNA</option>
                <option value="IMNA">IMNA</option>
                <option value="SANYA">SANYA</option>
                <option value="FSNA">FSNA</option>
                <option value="NCNA">NCNA</option>
                <option value="LNA">LNA</option>
                <option value="MPNA">MPNA</option>
                <option value="ECNA">ECNA</option>
                <option value="WCNA">WCNA</option>
              </select>
            </div>
          </div>

          <button
            onClick={handleExportToExcel}
            className="flex items-center px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 transition-colors"
          >
            <FileSpreadsheet className="h-5 w-5 mr-2" />
            Export to Excel
          </button>
        </div>
      </div>

      <table className="min-w-full divide-y divide-light-elevated">
        <thead className="bg-light-secondary">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-text-secondary uppercase tracking-wider">
              <SortButton field="surname" label="Member Info" />
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-text-secondary uppercase tracking-wider">
              Contact
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-text-secondary uppercase tracking-wider">
              <SortButton field="membership_type" label="Membership" />
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-text-secondary uppercase tracking-wider">
              <SortButton field="pna" label="PNA" />
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-text-secondary uppercase tracking-wider">
              <SortButton field="status" label="Status" />
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-text-secondary uppercase tracking-wider">
              Amount Paid
            </th>
          </tr>
        </thead>
        <tbody className="bg-light-surface divide-y divide-light-elevated">
          {sortedAndFilteredMembers.map((member) => {
            const isExpiring = isExpiringSoon(member);
            const daysLeft = getDaysUntilExpiry(member);
            const rowClasses = isExpiring ? 'bg-light-action-secondary/10' : '';

            return (
              <tr key={member.id} className={rowClasses}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center justify-between">
                    <button
                      onClick={() => setShowProfile(member)}
                      className="flex items-center space-x-3 hover:bg-light-secondary rounded-lg p-1 text-left"
                    >
                      {member.photo_url ? (
                        <img
                          src={member.photo_url}
                          alt={`${member.first_name} ${member.surname}`}
                          className="h-10 w-10 rounded-full object-cover"
                        />
                      ) : (
                        <UserCircle className="h-10 w-10 text-light-elevated" />
                      )}
                      <div>
                        <div className="text-sm font-medium text-light-text-primary group-hover:text-light-action-primary">
                          {member.first_name} {member.surname}
                          {member.join_date && (
                            <span className="ml-2 text-xs text-light-text-secondary">
                              <Clock className="h-3 w-3 inline-block mr-1" />
                              {getTimeSinceJoined(member.join_date)}
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-light-text-secondary">{member.inf_stamp_number}</div>
                      </div>
                    </button>
                    <div className="flex space-x-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onEdit(member);
                        }}
                        className="p-2 text-light-action-primary hover:bg-light-secondary rounded-md"
                        title="Edit Member"
                      >
                        <Edit2 className="h-5 w-5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDelete(member);
                        }}
                        className="p-2 text-light-action-error hover:bg-light-secondary rounded-md"
                        title="Delete Member"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-light-text-primary">{member.email}</div>
                  <div className="text-sm text-light-text-secondary">{member.telephone}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex flex-col space-y-1">
                    {getMembershipBadge(member.membership_type)}
                    {member.membership_type === 'annual' && member.date_renewed && (
                      <div className="text-sm text-light-text-secondary">
                        Renewed: {format(new Date(member.date_renewed), 'dd/MM/yyyy')}
                        {isExpiring && (
                          <div className="flex items-center mt-1 text-light-action-secondary">
                            <AlertTriangle className="h-4 w-4 mr-1" />
                            <span>Expires in {daysLeft} {daysLeft === 1 ? 'day' : 'days'}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${pnaColors[member.pna]} text-white`}>
                    {member.pna}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(member.status, member)}`}>
                    {isExpiring ? 'Expiring Soon' : member.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {member.status === 'Active' && (
                    <div className="flex items-center text-sm text-light-text-primary">
                      <Wallet className="h-4 w-4 mr-2 text-light-action-primary" />
                      {formatCurrency(member.amount_paid)}
                    </div>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}