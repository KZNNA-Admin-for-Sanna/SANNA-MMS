import React, { useState } from 'react';
import ReactCrop, { Crop, PixelCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

interface ImageCropperProps {
  imageUrl: string;
  onCropComplete: (croppedImage: string) => void;
  onCancel: () => void;
}

export function ImageCropper({ imageUrl, onCropComplete, onCancel }: ImageCropperProps) {
  const [crop, setCrop] = useState<Crop>({
    unit: '%',
    width: 90,
    height: 90,
    x: 5,
    y: 5,
  });

  const getCroppedImg = async (image: HTMLImageElement, crop: PixelCrop): Promise<string> => {
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = crop.width;
    canvas.height = crop.height;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      throw new Error('No 2d context');
    }

    // Create a new image with crossOrigin set to anonymous
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        ctx.drawImage(
          img,
          crop.x * scaleX,
          crop.y * scaleY,
          crop.width * scaleX,
          crop.height * scaleY,
          0,
          0,
          crop.width,
          crop.height
        );
        try {
          const base64Image = canvas.toDataURL('image/jpeg');
          resolve(base64Image);
        } catch (err) {
          reject(err);
        }
      };
      img.onerror = () => {
        reject(new Error('Failed to load image'));
      };
      // Add cache buster to force reload with CORS headers
      img.src = `${imageUrl}${imageUrl.includes('?') ? '&' : '?'}_=${Date.now()}`;
    });
  };

  const handleComplete = async (crop: PixelCrop) => {
    const image = document.querySelector('img') as HTMLImageElement;
    if (!image) return;

    try {
      const croppedImageUrl = await getCroppedImg(image, crop);
      onCropComplete(croppedImageUrl);
    } catch (error) {
      console.error('Error cropping image:', error);
      // If cropping fails, pass through the original image
      onCropComplete(imageUrl);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-xl max-w-2xl w-full">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Crop Image</h3>
        <div className="mb-4">
          <ReactCrop
            crop={crop}
            onChange={(_, percentCrop) => setCrop(percentCrop)}
            onComplete={(c) => handleComplete(c)}
            aspect={1}
            circularCrop
          >
            <img src={imageUrl} alt="Crop preview" crossOrigin="anonymous" />
          </ReactCrop>
        </div>
        <div className="flex justify-end space-x-3">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-gray-600 hover:text-gray-800"
          >
            Cancel
          </button>
          <button
            onClick={() => handleComplete(crop as PixelCrop)}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Apply Crop
          </button>
        </div>
      </div>
    </div>
  );
}