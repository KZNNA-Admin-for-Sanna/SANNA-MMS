import React, { useState, useRef } from 'react';
import { Member, MemberNote } from '../types/member';
import { supabase } from '../lib/supabase';
import { Save, X, AlertCircle, Link, UserX, Shield, Lock, Trash2, Mail, Ban, QrCode, Camera, Clock, AlertTriangle } from 'lucide-react';
import toast from 'react-hot-toast';
import { AdminActionDialog } from './AdminActionDialog';
import QRCode from 'qrcode';
import { PhotoEditor } from './PhotoEditor';
import { validateImage } from '../lib/imageUtils';
import { format, differenceInMonths, differenceInYears } from 'date-fns';

interface MemberEditFormProps {
  member: Member;
  onSave: () => void;
  onCancel: () => void;
}

interface FormErrors {
  first_name?: string;
  surname?: string;
  email?: string;
  inf_stamp_number?: string;
  inf_registration_link?: string;
  join_date?: string;
  [key: string]: string | undefined;
}

export function MemberEditForm({ member, onSave, onCancel }: MemberEditFormProps) {
  const [formData, setFormData] = useState<Member>(member);
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});
  const [showAdminAction, setShowAdminAction] = useState<{
    type: 'ban' | 'deactivate' | 'remove-admin';
    title: string;
    message: string;
  } | null>(null);
  const [showQrCode, setShowQrCode] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);
  const [showPhotoEditor, setShowPhotoEditor] = useState(false);
  const [tempPhotoUrl, setTempPhotoUrl] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [statusNote, setStatusNote] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.first_name?.trim()) {
      newErrors.first_name = 'First name is required';
    }

    if (!formData.surname?.trim()) {
      newErrors.surname = 'Surname is required';
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (formData.inf_registration_link && !formData.inf_registration_link.match(/^https?:\/\/[^\s/$.?#].[^\s]*$/)) {
      newErrors.inf_registration_link = 'Please enter a valid URL';
    }

    if (!formData.join_date) {
      newErrors.join_date = 'Join date is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const getTimeSinceJoined = (joinDate: string) => {
    const years = differenceInYears(new Date(), new Date(joinDate));
    const months = differenceInMonths(new Date(), new Date(joinDate)) % 12;
    
    let timeString = '';
    if (years > 0) {
      timeString += `${years}y`;
    }
    if (months > 0) {
      if (timeString) timeString += ' ';
      timeString += `${months}m`;
    }
    if (!timeString) {
      timeString = '<1m';
    }
    return timeString;
  };

  const handleAdminAction = async (action: string, reason: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No authenticated user');

      const updates: Partial<Member> = {};
      switch (action) {
        case 'ban':
          updates.status = 'Banned';
          break;
        case 'deactivate':
          updates.status = 'Inactive';
          break;
        case 'remove-admin':
          updates.role = null;
          break;
      }

      const { error: updateError } = await supabase
        .from('members')
        .update(updates)
        .eq('id', member.id);

      if (updateError) throw updateError;

      const { error: logError } = await supabase
        .from('admin_actions')
        .insert({
          action_type: action,
          target_member_id: member.id,
          executed_by: user.id,
          reason,
          details: {
            member_name: `${member.first_name} ${member.surname}`,
            member_email: member.email,
            previous_status: member.status,
            previous_role: member.role
          }
        });

      if (logError) throw logError;

      toast.success('Action completed successfully');
      onSave();
    } catch (error) {
      console.error('Error performing admin action:', error);
      toast.error('Failed to perform action');
    }
  };

  const handleResetPassword = async () => {
    if (!formData.email) {
      toast.error('Member has no email address');
      return;
    }

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(formData.email);
      if (error) throw error;
      toast.success('Password reset email sent');
    } catch (error) {
      console.error('Error sending password reset:', error);
      toast.error('Failed to send password reset email');
    }
  };

  const handleResendVerification = async () => {
    if (!formData.email) {
      toast.error('Member has no email address');
      return;
    }

    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: formData.email
      });
      
      if (error) throw error;
      toast.success('Verification email sent');
    } catch (error) {
      console.error('Error sending verification email:', error);
      toast.error('Failed to send verification email');
    }
  };

  const generateQrCode = async (url: string) => {
    try {
      const qrCode = await QRCode.toDataURL(url, {
        width: 200,
        margin: 2,
        color: {
          dark: '#111827',
          light: '#FFFFFF'
        }
      });
      setQrCodeUrl(qrCode);
      setShowQrCode(true);
    } catch (error) {
      console.error('Error generating QR code:', error);
      toast.error('Failed to generate QR code');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    if (['Resigned', 'Banned'].includes(formData.status) && (!statusNote || statusNote.length < 100)) {
      toast.error('A detailed note (minimum 100 characters) is required for this status change');
      return;
    }

    setIsSaving(true);

    try {
      const { error: memberError } = await supabase
        .from('members')
        .update({
          first_name: formData.first_name,
          surname: formData.surname,
          inf_stamp_number: formData.inf_stamp_number,
          inf_registration_link: formData.inf_registration_link || null,
          email: formData.email,
          telephone: formData.telephone,
          town: formData.town,
          suburb: formData.suburb,
          membership_type: formData.membership_type,
          pna: formData.pna,
          date_renewed: formData.date_renewed,
          status: formData.status,
          join_date: formData.join_date
        })
        .eq('id', member.id);

      if (memberError) throw memberError;

      if (statusNote) {
        const { error: noteError } = await supabase
          .from('member_notes')
          .insert({
            member_id: member.id,
            note: statusNote,
            effective_date: new Date().toISOString()
          });

        if (noteError) throw noteError;
      }

      toast.success('Member updated successfully');
      onSave();
    } catch (error) {
      console.error('Error updating member:', error);
      toast.error('Failed to update member');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const error = validateImage(file);
    if (error) {
      toast.error(error);
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setTempPhotoUrl(reader.result as string);
      setShowPhotoEditor(true);
    };
    reader.readAsDataURL(file);
  };

  const handlePhotoCropComplete = async (croppedImage: Blob) => {
    try {
      setShowPhotoEditor(false);
      setIsSaving(true);

      const fileName = `${member.id}-profile-${Date.now()}.jpg`;
      
      const { error: uploadError, data } = await supabase.storage
        .from('member-photos')
        .upload(fileName, croppedImage, {
          contentType: 'image/jpeg',
          upsert: true,
          onUploadProgress: (progress) => {
            const percentage = (progress.loaded / progress.total) * 100;
            setUploadProgress(Math.round(percentage));
          },
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('member-photos')
        .getPublicUrl(fileName);

      const { error: updateError } = await supabase
        .from('members')
        .update({ photo_url: publicUrl })
        .eq('id', member.id);

      if (updateError) throw updateError;

      setFormData(prev => ({ ...prev, photo_url: publicUrl }));
      toast.success('Photo updated successfully');
    } catch (error) {
      console.error('Error uploading photo:', error);
      toast.error('Failed to upload photo');
    } finally {
      setIsSaving(false);
      setUploadProgress(0);
    }
  };

  const removePhoto = async () => {
    try {
      setIsSaving(true);

      const { error } = await supabase
        .from('members')
        .update({ photo_url: null })
        .eq('id', member.id);

      if (error) throw error;

      setFormData(prev => ({ ...prev, photo_url: null }));
      toast.success('Photo removed successfully');
    } catch (error) {
      console.error('Error removing photo:', error);
      toast.error('Failed to remove photo');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-light-surface p-4 sm:p-6 rounded-lg">
      <div className="mb-6 flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
        {formData.photo_url ? (
          <div className="relative">
            <img
              src={formData.photo_url}
              alt={`${formData.first_name} ${formData.surname}`}
              className="h-24 w-24 rounded-full object-cover"
            />
            <button
              onClick={removePhoto}
              className="absolute -top-2 -right-2 p-1 bg-light-action-error text-white rounded-full hover:bg-opacity-90"
              title="Remove photo"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div className="h-24 w-24 border-2 border-dashed border-light-elevated rounded-full flex items-center justify-center">
            <Camera className="h-8 w-8 text-light-text-secondary" />
          </div>
        )}
        <div className="space-y-2 w-full sm:w-auto">
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            onChange={handlePhotoChange}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full sm:w-auto px-4 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90"
          >
            {formData.photo_url ? 'Change Photo' : 'Upload Photo'}
          </button>
          {uploadProgress > 0 && (
            <div className="w-full bg-light-elevated rounded-full h-2">
              <div
                className="bg-light-action-primary h-2 rounded-full transition-all"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          )}
        </div>
      </div>

      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h2 className="text-xl font-semibold text-light-text-primary">
            Edit Member: {member.first_name} {member.surname}
          </h2>
          {member.join_date && (
            <div className="flex items-center mt-1 text-light-text-secondary">
              <Clock className="h-4 w-4 mr-1" />
              Member for {getTimeSinceJoined(member.join_date)}
            </div>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          <div className="flex items-center space-x-2 bg-light-secondary rounded-lg p-2">
            {member.role === 'admin' && (
              <button
                onClick={() => setShowAdminAction({
                  type: 'remove-admin',
                  title: 'Remove Admin Rights',
                  message: 'This will remove all administrative privileges from this account.'
                })}
                className="p-2 text-light-action-error hover:bg-light-elevated rounded-md tooltip-trigger"
                title="Remove Admin Rights"
              >
                <Shield className="h-5 w-5" />
              </button>
            )}
            <button
              onClick={() => setShowAdminAction({
                type: 'deactivate',
                title: 'Deactivate Account',
                message: 'This will temporarily suspend the member\'s account access.'
              })}
              className="p-2 text-light-action-error hover:bg-light-elevated rounded-md tooltip-trigger"
              title="Deactivate Account"
            >
              <UserX className="h-5 w-5" />
            </button>
            <button
              onClick={() => setShowAdminAction({
                type: 'ban',
                title: 'Ban Member',
                message: 'This will permanently ban the member from accessing the system.'
              })}
              className="p-2 text-light-action-error hover:bg-light-elevated rounded-md tooltip-trigger"
              title="Ban Member"
            >
              <Ban className="h-5 w-5" />
            </button>
            <div className="h-6 w-px bg-light-elevated mx-2" />
            <button
              onClick={handleResetPassword}
              className="p-2 text-light-text-secondary hover:bg-light-elevated rounded-md tooltip-trigger"
              title="Reset Password"
            >
              <Lock className="h-5 w-5" />
            </button>
            <button
              onClick={handleResendVerification}
              className="p-2 text-light-text-secondary hover:bg-light-elevated rounded-md tooltip-trigger"
              title="Resend Verification Email"
            >
              <Mail className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="mb-6 flex flex-wrap gap-2">
        <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium" 
          style={{
            backgroundColor: member.status === 'Active' ? '#10B981' :
                           member.status === 'Inactive' ? '#F59E0B' :
                           member.status === 'Banned' ? '#EF4444' : '#6B7280',
            color: 'white'
          }}
        >
          {member.status}
        </div>
        {member.role === 'admin' && (
          <span className="inline-flex items-center px-3 py-1 rounded-full bg-light-action-purple text-white text-sm font-medium">
            Admin
          </span>
        )}
        {!formData.email_verified && formData.email && (
          <span className="inline-flex items-center px-3 py-1 rounded-full bg-light-action-error text-white text-sm font-medium">
            Email Not Verified
          </span>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              First Name
              <span className="text-light-action-error">*</span>
            </label>
            <input
              type="text"
              name="first_name"
              value={formData.first_name}
              onChange={handleChange}
              className={`mt-1 block w-full rounded-md ${
                errors.first_name 
                  ? 'border-light-action-error' 
                  : 'border-light-elevated'
              } focus:border-light-action-primary focus:ring-light-action-primary`}
            />
            {errors.first_name && (
              <p className="text-sm text-light-action-error flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                {errors.first_name}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              Surname
              <span className="text-light-action-error">*</span>
            </label>
            <input
              type="text"
              name="surname"
              value={formData.surname}
              onChange={handleChange}
              className={`mt-1 block w-full rounded-md ${
                errors.surname 
                  ? 'border-light-action-error' 
                  : 'border-light-elevated'
              } focus:border-light-action-primary focus:ring-light-action-primary`}
            />
            {errors.surname && (
              <p className="text-sm text-light-action-error flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                {errors.surname}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              INF Stamp Number
            </label>
            <input
              type="text"
              name="inf_stamp_number"
              value={formData.inf_stamp_number || ''}
              onChange={handleChange}
              className={`mt-1 block w-full rounded-md ${
                errors.inf_stamp_number 
                  ? 'border-light-action-error' 
                  : 'border-light-elevated'
              } focus:border-light-action-primary focus:ring-light-action-primary`}
            />
            {errors.inf_stamp_number && (
              <p className="text-sm text-light-action-error flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                {errors.inf_stamp_number}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              Email
            </label>
            <input
              type="email"
              name="email"
              value={formData.email || ''}
              onChange={handleChange}
              className={`mt-1 block w-full rounded-md ${
                errors.email 
                  ? 'border-light-action-error' 
                  : 'border-light-elevated'
              } focus:border-light-action-primary focus:ring-light-action-primary`}
            />
            {errors.email && (
              <p className="text-sm text-light-action-error flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                {errors.email}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              Telephone
            </label>
            <input
              type="tel"
              name="telephone"
              value={formData.telephone || ''}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-light-elevated focus:border-light-action-primary focus:ring-light-action-primary"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              Town
            </label>
            <input
              type="text"
              name="town"
              value={formData.town || ''}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-light-elevated focus:border-light-action-primary focus:ring-light-action-primary"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              Suburb
            </label>
            <input
              type="text"
              name="suburb"
              value={formData.suburb || ''}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-light-elevated focus:border-light-action-primary focus:ring-light-action-primary"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              Join Date
              <span className="text-light-action-error">*</span>
            </label>
            <input
              type="date"
              name="join_date"
              value={formData.join_date || ''}
              onChange={handleChange}
              className={`mt-1 block w-full rounded-md ${
                errors.join_date 
                  ? 'border-light-action-error' 
                  : 'border-light-elevated'
              } focus:border-light-action-primary focus:ring-light-action-primary`}
            />
            {errors.join_date && (
              <p className="text-sm text-light-action-error flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                {errors.join_date}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              Membership Type
            </label>
            <select
              name="membership_type"
              value={formData.membership_type}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-light-elevated focus:border-light-action-primary focus:ring-light-action-primary"
            >
              <option value="annual">Annual</option>
              <option value="honorary">Honorary</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              Provincial Association (PNA)
            </label>
            <select
              name="pna"
              value={formData.pna}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-light-elevated focus:border-light-action-primary focus:ring-light-action-primary"
            >
              <option value="GNA">GNA - Gauteng Naturist Association</option>
              <option value="KZNNA">KZNNA - KwaZulu-Natal Naturist Association</option>
              <option value="WPNA">WPNA - Western Province Naturist Association</option>
              <option value="NWNA">NWNA - North West Naturist Association</option>
              <option value="IMNA">IMNA - Individual Members Naturist Association</option>
              <option value="SANYA">SANYA - South African Naturist Youth Association</option>
              <option value="FSNA">FSNA - Free State Naturist Association</option>
              <option value="NCNA">NCNA - Northern Cape Naturist Association</option>
              <option value="LNA">LNA - Limpopo Naturist Association</option>
              <option value="MPNA">MPNA - Mpumalanga Naturist Association</option>
              <option value="ECNA">ECNA - Eastern Cape Naturist Association</option>
              <option value="WCNA">WCNA - Western Cape Naturist Association</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-light-text-primary">
              Status
            </label>
            <select
              name="status"
              value={formData.status}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-light-elevated focus:border-light-action-primary focus:ring-light-action-primary"
            >
              <option value="Active">Active</option>
              <option value="Dormant">Dormant</option>
              <option value="Resigned">Resigned</option>
              <option value="Banned">Banned</option>
            </select>
            {['Resigned', 'Banned'].includes(formData.status) && (
              <p className="text-sm text-light-action-error flex items-center mt-1">
                <AlertTriangle className="h-4 w-4 mr-1" />
                This status requires a detailed note
              </p>
            )}
          </div>

          {formData.membership_type === 'annual' && (
            <div className="space-y-2">
              <label className="block text-sm font-medium text-light-text-primary">
                Date Renewed
              </label>
              <input
                type="date"
                name="date_renewed"
                value={formData.date_renewed || ''}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-light-elevated focus:border-light-action-primary focus:ring-light-action-primary"
              />
            </div>
          )}

          <div className="col-span-full">
            <label className="block text-sm font-medium text-light-text-primary">
              INF Registration Link
            </label>
            <div className="mt-1 flex rounded-md shadow-sm">
              <input
                type="url"
                name="inf_registration_link"
                value={formData.inf_registration_link || ''}
                onChange={handleChange}
                placeholder="https://example.com/registration"
                className={`flex-1 rounded-l-md ${
                  errors.inf_registration_link 
                    ? 'border-light-action-error' 
                    : 'border-light-elevated'
                } focus:border-light-action-primary focus:ring-light-action-primary`}
              />
              {formData.inf_registration_link && (
                <button
                  type="button"
                  onClick={() => generateQrCode(formData.inf_registration_link!)}
                  className="px-3 py-2 bg-light-action-primary text-white rounded-r-md hover:bg-opacity-90"
                >
                  <QrCode className="h-5 w-5" />
                </button>
              )}
            </div>
            {errors.inf_registration_link && (
              <p className="mt-1 text-sm text-light-action-error flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                {errors.inf_registration_link}
              </p>
            )}
          </div>

          {(['Resigned', 'Banned'].includes(formData.status) || statusNote) && (
            <div className="col-span-full">
              <label className="block text-sm font-medium text-light-text-primary">
                Status Change Note
                {['Resigned', 'Banned'].includes(formData.status) && (
                  <span className="text-light-action-error ml-1">*</span>
                )}
              </label>
              <textarea
                value={statusNote}
                onChange={(e) => setStatusNote(e.target.value)}
                className="mt-1 block w-full rounded-md border-light-elevated focus:border-light-action-primary focus:ring-light-action-primary"
                rows={4}
                placeholder={['Resigned', 'Banned'].includes(formData.status)
                  ? "Please provide a detailed reason for this status change (minimum 100 characters)"
                  : "Optional note about the status change"
                }
              />
              <p className="mt-1 text-sm text-light-text-secondary">
                {statusNote.length} characters
                {['Resigned', 'Banned'].includes(formData.status) && (
                  <span className="text-light-action-error ml-1">(minimum 100 required)</span>
                )}
              </p>
            </div>
          )}
        </div>

        <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-6">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-light-text-secondary hover:text-light-text-primary"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center px-4 py-2 bg-light-action-primary text-white rounde
d-md hover:bg-opacity-90 disabled:opacity-50"
          >
            <Save className="h-4 w-4 mr-2" />
            {isSaving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>

      {showQrCode && qrCodeUrl && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-light-surface p-6 rounded-lg shadow-light-lg max-w-sm w-full m-4">
            <h3 className="text-lg font-semibold text-light-text-primary mb-4">
              INF Registration QR Code
            </h3>
            <div className="bg-white p-4 rounded-lg inline-block mb-4">
              <img src={qrCodeUrl} alt="QR Code" className="mx-auto" />
            </div>
            <p className="text-sm text-light-text-secondary mb-4">
              Scan this code to access the INF registration page
            </p>
            <button
              onClick={() => setShowQrCode(false)}
              className="px-4 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {showPhotoEditor && tempPhotoUrl && (
        <PhotoEditor
          imageUrl={tempPhotoUrl}
          onSave={handlePhotoCropComplete}
          onCancel={() => {
            setShowPhotoEditor(false);
            setTempPhotoUrl(null);
          }}
        />
      )}

      {showAdminAction && (
        <AdminActionDialog
          member={member}
          action={showAdminAction.type}
          title={showAdminAction.title}
          message={showAdminAction.message}
          onClose={() => setShowAdminAction(null)}
          onConfirm={(reason) => {
            handleAdminAction(showAdminAction.type, reason);
            setShowAdminAction(null);
          }}
        />
      )}
    </div>
  );
}