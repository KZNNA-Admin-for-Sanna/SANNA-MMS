import React, { useState } from 'react';
import { Member } from '../types/member';
import { AlertTriangle, X } from 'lucide-react';

interface AdminActionDialogProps {
  member: Member;
  action: 'ban' | 'deactivate' | 'remove-admin';
  title: string;
  message: string;
  onClose: () => void;
  onConfirm: (reason: string) => void;
}

export function AdminActionDialog({ 
  member, 
  action, 
  title, 
  message, 
  onClose, 
  onConfirm 
}: AdminActionDialogProps) {
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (reason.length < 20) {
      return;
    }
    setIsSubmitting(true);
    onConfirm(reason);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-light-surface p-6 rounded-lg shadow-light-lg max-w-lg w-full">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center text-light-action-error">
            <AlertTriangle className="h-6 w-6 mr-2" />
            <h3 className="text-xl font-semibold text-light-text-primary">
              {title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-light-text-secondary hover:text-light-text-primary"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mb-6">
          <p className="text-light-text-secondary mb-4">{message}</p>
          <div className="bg-light-secondary p-3 rounded-md">
            <p className="text-sm text-light-text-primary">
              <strong>Member:</strong> {member.first_name} {member.surname}
            </p>
            <p className="text-sm text-light-text-secondary">
              <strong>Email:</strong> {member.email}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-sm font-medium text-light-text-primary mb-1">
              Reason for Action
              <span className="text-light-action-error ml-1">*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full rounded-md border-light-elevated bg-light-surface text-light-text-primary focus:border-light-action-primary focus:ring-light-action-primary"
              rows={4}
              placeholder="Please provide a detailed reason for this action..."
              required
            />
            <p className="mt-1 text-sm text-light-text-secondary">
              {reason.length} characters (minimum 20 required)
            </p>
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-light-text-secondary hover:text-light-text-primary"
              disabled={isSubmitting}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-light-action-error text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
              disabled={isSubmitting || reason.length < 20}
            >
              {isSubmitting ? 'Processing...' : 'Confirm Action'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}