import React, { useState } from 'react';
import { format } from 'date-fns';
import { Member } from '../types/member';
import { UserCircle, UserPlus, Check, X } from 'lucide-react';
import { handleEmailSignUp } from '../lib/auth';
import { logger } from '../lib/logger';
import toast from 'react-hot-toast';

interface RegisteredUsersProps {
  members: Member[];
}

interface RegisterUserDialogProps {
  member: Member;
  onClose: () => void;
  onSuccess: () => void;
}

function RegisterUserDialog({ member, onClose, onSuccess }: RegisterUserDialogProps) {
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Password requirements
  const requirements = [
    { label: 'At least 8 characters', test: (p: string) => p.length >= 8 },
    { label: 'Contains a number', test: (p: string) => /\d/.test(p) },
    { label: 'Contains a lowercase letter', test: (p: string) => /[a-z]/.test(p) },
    { label: 'Contains an uppercase letter', test: (p: string) => /[A-Z]/.test(p) },
    { label: 'Contains a special character', test: (p: string) => /[!@#$%^&*(),.?":{}|<>]/.test(p) }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!member.email) {
      toast.error('Member must have an email address');
      return;
    }

    // Check all password requirements
    const meetsAllRequirements = requirements.every(req => req.test(password));
    if (!meetsAllRequirements) {
      toast.error('Password does not meet all requirements');
      return;
    }
    
    setIsLoading(true);
    try {
      logger.debug('Registering user for member:', member.id);
      const success = await handleEmailSignUp(member.email, password);
      
      if (success) {
        logger.info('User registration successful');
        onSuccess();
      }
    } catch (error) {
      logger.error('Error registering user:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
        <div className="flex items-center mb-4">
          <UserPlus className="h-6 w-6 text-blue-500 mr-2" />
          <h3 className="text-lg font-semibold text-gray-900">Create User Account</h3>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Member</label>
            <div className="mt-1 p-3 bg-gray-50 rounded-md">
              <p className="font-medium">{member.first_name} {member.surname}</p>
              <p className="text-sm text-gray-500">{member.email}</p>
              {member.inf_stamp_number && (
                <p className="text-sm text-gray-500">INF: {member.inf_stamp_number}</p>
              )}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700">
              Password
              <span className="text-red-500">*</span>
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              placeholder="••••••••"
              required
            />
            
            {/* Password Requirements */}
            <div className="mt-3 space-y-2">
              <p className="text-sm font-medium text-gray-700">Password Requirements:</p>
              <div className="bg-gray-50 p-3 rounded-md space-y-2">
                {requirements.map((req, index) => (
                  <div key={index} className="flex items-center text-sm">
                    {req.test(password) ? (
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                    ) : (
                      <X className="h-4 w-4 text-red-500 mr-2" />
                    )}
                    <span className={req.test(password) ? 'text-green-700' : 'text-gray-600'}>
                      {req.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-900"
              disabled={isLoading}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading || !requirements.every(req => req.test(password))}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {isLoading ? 'Creating...' : 'Create Account'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function RegisteredUsers({ members }: RegisteredUsersProps) {
  const [registeringMember, setRegisteringMember] = useState<Member | null>(null);

  const unregisteredMembers = members.filter(member => 
    !member.auth_user_id && 
    member.status === 'Active' && 
    member.email
  );
  
  const registeredMembers = members.filter(member => member.auth_user_id);

  return (
    <div className="mt-8 bg-white rounded-lg shadow-lg p-6">
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Unregistered Members</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {unregisteredMembers.map(member => (
            <div 
              key={member.id}
              className="bg-gray-50 rounded-lg p-4 flex items-center space-x-4"
            >
              <div className="flex-shrink-0">
                {member.photo_url ? (
                  <img
                    src={member.photo_url}
                    alt={`${member.first_name} ${member.surname}`}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                ) : (
                  <UserCircle className="h-12 w-12 text-gray-400" />
                )}
              </div>
              
              <div className="flex-grow min-w-0">
                <h3 className="font-medium text-gray-900 truncate">
                  {member.first_name} {member.surname}
                </h3>
                <p className="text-sm text-gray-500 truncate">
                  {member.email}
                </p>
                {member.inf_stamp_number && (
                  <p className="text-sm text-gray-400">
                    INF: {member.inf_stamp_number}
                  </p>
                )}
              </div>

              <button
                onClick={() => setRegisteringMember(member)}
                className="flex-shrink-0 p-2 text-blue-600 hover:bg-blue-50 rounded-full"
                title="Create User Account"
              >
                <UserPlus className="h-5 w-5" />
              </button>
            </div>
          ))}

          {unregisteredMembers.length === 0 && (
            <p className="col-span-full text-center text-gray-500 py-8">
              No unregistered members found
            </p>
          )}
        </div>
      </div>
      
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Registered Users</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {registeredMembers.map(member => (
            <div 
              key={member.id}
              className="bg-gray-50 rounded-lg p-4 flex items-center space-x-4"
            >
              <div className="flex-shrink-0">
                {member.photo_url ? (
                  <img
                    src={member.photo_url}
                    alt={`${member.first_name} ${member.surname}`}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                ) : (
                  <UserCircle className="h-12 w-12 text-gray-400" />
                )}
              </div>
              
              <div className="flex-grow min-w-0">
                <h3 className="font-medium text-gray-900 truncate">
                  {member.first_name} {member.surname}
                </h3>
                <p className="text-sm text-gray-500 truncate">
                  {member.email}
                </p>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-gray-400">
                    {format(new Date(member.created_at), 'dd MMM yyyy')}
                  </span>
                </div>
              </div>
            </div>
          ))}

          {registeredMembers.length === 0 && (
            <p className="col-span-full text-center text-gray-500 py-8">
              No registered users yet
            </p>
          )}
        </div>
      </div>

      {registeringMember && (
        <RegisterUserDialog
          member={registeringMember}
          onClose={() => setRegisteringMember(null)}
          onSuccess={() => {
            setRegisteringMember(null);
            window.location.reload();
          }}
        />
      )}
    </div>
  );
}