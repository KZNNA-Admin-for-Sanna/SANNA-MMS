import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { PNAType } from '../types/member';
import { Mail, Send, Plus, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
}

interface BulkEmailFormProps {
  onClose: () => void;
}

export function BulkEmailForm({ onClose }: BulkEmailFormProps) {
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [selectedPNA, setSelectedPNA] = useState<PNAType>('GNA');
  const [showNewTemplate, setShowNewTemplate] = useState(false);
  const [newTemplate, setNewTemplate] = useState({
    name: '',
    subject: '',
    content: ''
  });
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    const { data, error } = await supabase
      .from('email_templates')
      .select('*')
      .order('name');

    if (error) {
      toast.error('Failed to fetch email templates');
      return;
    }

    setTemplates(data);
  };

  const handleCreateTemplate = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const { error } = await supabase
        .from('email_templates')
        .insert([newTemplate]);

      if (error) throw error;

      toast.success('Template created successfully');
      setShowNewTemplate(false);
      setNewTemplate({ name: '', subject: '', content: '' });
      fetchTemplates();
    } catch (error) {
      toast.error('Failed to create template');
      console.error('Error:', error);
    }
  };

  const handleDeleteTemplate = async (templateId: string) => {
    try {
      const { error } = await supabase
        .from('email_templates')
        .delete()
        .eq('id', templateId);

      if (error) throw error;

      toast.success('Template deleted successfully');
      fetchTemplates();
    } catch (error) {
      toast.error('Failed to delete template');
      console.error('Error:', error);
    }
  };

  const sendEmail = async (email: string, subject: string, content: string) => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
        data: {
          subject,
          template_content: content
        }
      });

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error sending email:', error);
      return false;
    }
  };

  const handleSendEmails = async () => {
    if (!selectedTemplate || !selectedPNA) {
      toast.error('Please select a template and PNA');
      return;
    }

    setIsSending(true);

    try {
      // Get all active members from the selected PNA
      const { data: members, error: membersError } = await supabase
        .from('members')
        .select('email')
        .eq('pna', selectedPNA)
        .eq('status', 'Active')
        .not('email', 'is', null);

      if (membersError) throw membersError;

      const emails = members.map(m => m.email).filter(Boolean);
      
      if (emails.length === 0) {
        toast.error('No active members found with email addresses');
        return;
      }

      // Get the selected template
      const template = templates.find(t => t.id === selectedTemplate);
      if (!template) {
        toast.error('Selected template not found');
        return;
      }

      // Send emails in batches of 5 to avoid rate limiting
      const batchSize = 5;
      const batches = Math.ceil(emails.length / batchSize);
      let successCount = 0;
      let failureCount = 0;

      for (let i = 0; i < batches; i++) {
        const batchEmails = emails.slice(i * batchSize, (i + 1) * batchSize);
        const results = await Promise.all(
          batchEmails.map(email => 
            sendEmail(email, template.subject, template.content)
          )
        );

        successCount += results.filter(Boolean).length;
        failureCount += results.filter(r => !r).length;

        // Add a small delay between batches
        if (i < batches - 1) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }

      // Log the email sending
      const { error: logError } = await supabase
        .from('email_logs')
        .insert([{
          template_id: selectedTemplate,
          sent_to: emails,
          pna: selectedPNA,
          status: 'sent'
        }]);

      if (logError) throw logError;

      if (failureCount > 0) {
        toast.warning(`Sent ${successCount} emails, ${failureCount} failed`);
      } else {
        toast.success(`Successfully sent ${successCount} emails`);
      }
      
      onClose();
    } catch (error) {
      console.error('Error sending emails:', error);
      toast.error('Failed to send emails');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-light-surface rounded-lg shadow-light-lg max-w-4xl w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-light-text-primary flex items-center">
            <Mail className="h-6 w-6 mr-2" />
            Send Bulk Email
          </h2>
          <button
            onClick={onClose}
            className="text-light-text-secondary hover:text-light-text-primary"
          >
            ×
          </button>
        </div>

        {showNewTemplate ? (
          <form onSubmit={handleCreateTemplate} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-light-text-primary">Template Name</label>
              <input
                type="text"
                required
                className="mt-1 block w-full rounded-md border-light-elevated shadow-sm focus:border-light-action-primary focus:ring-light-action-primary"
                value={newTemplate.name}
                onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-light-text-primary">Subject</label>
              <input
                type="text"
                required
                className="mt-1 block w-full rounded-md border-light-elevated shadow-sm focus:border-light-action-primary focus:ring-light-action-primary"
                value={newTemplate.subject}
                onChange={(e) => setNewTemplate({ ...newTemplate, subject: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-light-text-primary">Content</label>
              <textarea
                required
                rows={6}
                className="mt-1 block w-full rounded-md border-light-elevated shadow-sm focus:border-light-action-primary focus:ring-light-action-primary"
                value={newTemplate.content}
                onChange={(e) => setNewTemplate({ ...newTemplate, content: e.target.value })}
                placeholder="You can use the following placeholders:&#13;&#10;{firstName} - Member's first name&#13;&#10;{lastName} - Member's last name&#13;&#10;{membershipNumber} - Member's INF stamp number"
              />
            </div>
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setShowNewTemplate(false)}
                className="px-4 py-2 text-light-text-secondary hover:text-light-text-primary"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90"
              >
                Create Template
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-sm font-medium text-light-text-primary">Email Template</label>
                <button
                  onClick={() => setShowNewTemplate(true)}
                  className="flex items-center text-sm text-light-action-link hover:text-opacity-80"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  New Template
                </button>
              </div>
              <div className="space-y-2">
                {templates.map((template) => (
                  <div
                    key={template.id}
                    className={`p-4 rounded-lg border ${
                      selectedTemplate === template.id
                        ? 'border-light-action-primary bg-light-action-primary/10'
                        : 'border-light-elevated hover:border-light-action-primary'
                    } cursor-pointer relative group`}
                    onClick={() => setSelectedTemplate(template.id)}
                  >
                    <h3 className="font-medium text-light-text-primary">{template.name}</h3>
                    <p className="text-sm text-light-text-secondary">{template.subject}</p>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteTemplate(template.id);
                      }}
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 text-light-action-error hover:text-opacity-80"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-light-text-primary">Provincial Association</label>
              <select
                className="mt-1 block w-full rounded-md border-light-elevated shadow-sm focus:border-light-action-primary focus:ring-light-action-primary"
                value={selectedPNA}
                onChange={(e) => setSelectedPNA(e.target.value as PNAType)}
              >
                <option value="GNA">GNA - Gauteng Naturist Association</option>
                <option value="KZNNA">KZNNA - KwaZulu-Natal Naturist Association</option>
                <option value="WPNA">WPNA - Western Province Naturist Association</option>
                <option value="NWNA">NWNA - North West Naturist Association</option>
                <option value="IMNA">IMNA - Individual Members Naturist Association</option>
                <option value="SANYA">SANYA - South African Naturist Youth Association</option>
                <option value="FSNA">FSNA - Free State Naturist Association</option>
                <option value="NCNA">NCNA - Northern Cape Naturist Association</option>
                <option value="LNA">LNA - Limpopo Naturist Association</option>
                <option value="MPNA">MPNA - Mpumalanga Naturist Association</option>
                <option value="ECNA">ECNA - Eastern Cape Naturist Association</option>
                <option value="WCNA">WCNA - Western Cape Naturist Association</option>
              </select>
            </div>

            <div className="flex justify-end space-x-2">
              <button
                onClick={onClose}
                className="px-4 py-2 text-light-text-secondary hover:text-light-text-primary"
              >
                Cancel
              </button>
              <button
                onClick={handleSendEmails}
                disabled={!selectedTemplate || !selectedPNA || isSending}
                className="flex items-center px-4 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
              >
                <Send className="h-4 w-4 mr-2" />
                {isSending ? 'Sending...' : 'Send Emails'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}