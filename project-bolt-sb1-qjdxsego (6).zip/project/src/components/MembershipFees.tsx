import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Settings } from 'lucide-react';
import toast from 'react-hot-toast';

interface MembershipFee {
  id: string;
  year: number;
  amount: number;
  created_at: string;
}

export default function MembershipFees() {
  const [fees, setFees] = useState<MembershipFee[]>([]);
  const [newFee, setNewFee] = useState({ year: new Date().getFullYear(), amount: 330 });
  const [showForm, setShowForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchFees();
  }, []);

  const fetchFees = async () => {
    try {
      const { data, error } = await supabase
        .from('membership_fees')
        .select('*')
        .order('year', { ascending: false });

      if (error) throw error;
      setFees(data || []);
    } catch (error) {
      console.error('Error fetching fees:', error);
      toast.error('Failed to fetch membership fees');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    setIsSubmitting(true);
    try {
      // Check if fee for this year exists
      const { data: existingFees, error: checkError } = await supabase
        .from('membership_fees')
        .select('id')
        .eq('year', newFee.year);

      if (checkError) throw checkError;

      if (existingFees && existingFees.length > 0) {
        // Update existing fee
        const { error: updateError } = await supabase
          .from('membership_fees')
          .update({ amount: newFee.amount })
          .eq('year', newFee.year);

        if (updateError) throw updateError;
        toast.success('Membership fee updated successfully');
      } else {
        // Insert new fee
        const { error: insertError } = await supabase
          .from('membership_fees')
          .insert([{
            year: newFee.year,
            amount: newFee.amount
          }]);

        if (insertError) throw insertError;
        toast.success('Membership fee added successfully');
      }

      setShowForm(false);
      fetchFees();
    } catch (error) {
      console.error('Error saving fee:', error);
      toast.error('Failed to save membership fee');
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZA', {
      style: 'currency',
      currency: 'ZAR',
      minimumFractionDigits: 2
    }).format(amount);
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <Settings className="h-6 w-6 text-blue-600 dark:text-blue-400 mr-2" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Membership Fees</h2>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Set Fee
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Year</label>
              <input
                type="number"
                value={newFee.year}
                onChange={(e) => setNewFee({ ...newFee, year: parseInt(e.target.value) })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-600 dark:border-gray-500 dark:text-white"
                min={2000}
                max={2100}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Amount (ZAR)</label>
              <input
                type="number"
                value={newFee.amount}
                onChange={(e) => setNewFee({ ...newFee, amount: parseFloat(e.target.value) })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-600 dark:border-gray-500 dark:text-white"
                min={0}
                step={0.01}
                required
              />
            </div>
          </div>
          <div className="mt-4 flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100"
              disabled={isSubmitting}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Saving...' : 'Save'}
            </button>
          </div>
        </form>
      )}

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Year</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {fees.map((fee) => (
              <tr key={fee.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{fee.year}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{formatCurrency(fee.amount)}</td>
              </tr>
            ))}
            {fees.length === 0 && (
              <tr>
                <td colSpan={2} className="px-6 py-4 text-center text-sm text-gray-500 dark:text-gray-400">
                  No membership fees set
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}