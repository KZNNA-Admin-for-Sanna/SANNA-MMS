import React, { useState, useEffect } from 'react';
import { Member, MemberStory, GalleryPhoto } from '../types/member';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';
import { MapPin, Calendar, Camera, Plus, X, UserCircle, Edit2, Trash2, Link, QrCode } from 'lucide-react';
import toast from 'react-hot-toast';
import { ImageCropper } from './ImageCropper';
import QRCode from 'qrcode';

interface MemberProfileProps {
  member: Member;
  onClose: () => void;
  onUpdate: () => void;
}

export function MemberProfile({ member, onClose, onUpdate }: MemberProfileProps) {
  const [stories, setStories] = useState<MemberStory[]>([]);
  const [gallery, setGallery] = useState<GalleryPhoto[]>([]);
  const [newStory, setNewStory] = useState({ title: '', content: '' });
  const [showStoryForm, setShowStoryForm] = useState(false);
  const [showPhotoUpload, setShowPhotoUpload] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoCaption, setPhotoCaption] = useState('');
  const [showCropper, setShowCropper] = useState(false);
  const [tempPhotoUrl, setTempPhotoUrl] = useState<string | null>(null);
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);
  const [showQrCode, setShowQrCode] = useState(false);
  const [editingLink, setEditingLink] = useState(false);
  const [infLink, setInfLink] = useState(member.inf_registration_link || '');

  useEffect(() => {
    fetchStories();
    fetchGallery();
  }, [member.id]);

  useEffect(() => {
    if (member.inf_registration_link) {
      generateQrCode(member.inf_registration_link);
    }
  }, [member.inf_registration_link]);

  const generateQrCode = async (url: string) => {
    try {
      const qrCode = await QRCode.toDataURL(url, {
        width: 200,
        margin: 2,
        color: {
          dark: '#111827',
          light: '#FFFFFF'
        }
      });
      setQrCodeUrl(qrCode);
    } catch (error) {
      console.error('Error generating QR code:', error);
    }
  };

  const handleSaveLink = async () => {
    if (infLink && !infLink.match(/^https?:\/\/[^\s/$.?#].[^\s]*$/)) {
      toast.error('Please enter a valid URL');
      return;
    }

    try {
      const { error } = await supabase
        .from('members')
        .update({ inf_registration_link: infLink || null })
        .eq('id', member.id);

      if (error) throw error;

      if (infLink) {
        await generateQrCode(infLink);
      } else {
        setQrCodeUrl(null);
      }

      toast.success('INF registration link updated');
      setEditingLink(false);
      onUpdate();
    } catch (error) {
      console.error('Error updating INF link:', error);
      toast.error('Failed to update INF registration link');
    }
  };

  const fetchStories = async () => {
    const { data, error } = await supabase
      .from('member_stories')
      .select('*')
      .eq('member_id', member.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching stories:', error);
      return;
    }

    setStories(data);
  };

  const fetchGallery = async () => {
    const { data, error } = await supabase
      .from('member_gallery')
      .select('*')
      .eq('member_id', member.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching gallery:', error);
      return;
    }

    setGallery(data);
  };

  const handleStorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { error } = await supabase
        .from('member_stories')
        .insert([{
          member_id: member.id,
          title: newStory.title,
          content: newStory.content
        }]);

      if (error) throw error;

      toast.success('Story published successfully');
      setNewStory({ title: '', content: '' });
      setShowStoryForm(false);
      fetchStories();
    } catch (error) {
      console.error('Error publishing story:', error);
      toast.error('Failed to publish story');
    }
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Photo must be less than 5MB');
        return;
      }
      
      if (!file.type.startsWith('image/')) {
        toast.error('File must be an image');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setTempPhotoUrl(reader.result as string);
        setShowCropper(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCropComplete = (croppedImage: string) => {
    setShowCropper(false);
    
    fetch(croppedImage)
      .then(res => res.blob())
      .then(blob => {
        const file = new File([blob], 'gallery-photo.jpg', { type: 'image/jpeg' });
        setPhotoFile(file);
      });
  };

  const handlePhotoUpload = async () => {
    if (!photoFile) return;

    try {
      const fileExt = photoFile.name.split('.').pop();
      const fileName = `${member.id}-gallery-${Date.now()}.${fileExt}`;

      const { error: uploadError, data } = await supabase.storage
        .from('member-photos')
        .upload(fileName, photoFile, {
          onUploadProgress: (progress) => {
            const percentage = (progress.loaded / progress.total) * 100;
            setUploadProgress(Math.round(percentage));
          },
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('member-photos')
        .getPublicUrl(fileName);

      const { error: galleryError } = await supabase
        .from('member_gallery')
        .insert([{
          member_id: member.id,
          photo_url: publicUrl,
          caption: photoCaption
        }]);

      if (galleryError) throw galleryError;

      toast.success('Photo uploaded successfully');
      setPhotoFile(null);
      setPhotoCaption('');
      setShowPhotoUpload(false);
      fetchGallery();
    } catch (error) {
      console.error('Error uploading photo:', error);
      toast.error('Failed to upload photo');
    } finally {
      setUploadProgress(0);
    }
  };

  const handleDeletePhoto = async (photoId: string) => {
    try {
      const { error } = await supabase
        .from('member_gallery')
        .delete()
        .eq('id', photoId);

      if (error) throw error;

      toast.success('Photo deleted successfully');
      fetchGallery();
    } catch (error) {
      console.error('Error deleting photo:', error);
      toast.error('Failed to delete photo');
    }
  };

  const handleDeleteStory = async (storyId: string) => {
    try {
      const { error } = await supabase
        .from('member_stories')
        .delete()
        .eq('id', storyId);

      if (error) throw error;

      toast.success('Story deleted successfully');
      fetchStories();
    } catch (error) {
      console.error('Error deleting story:', error);
      toast.error('Failed to delete story');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-light-surface rounded-lg shadow-light-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center space-x-4">
              {member.photo_url ? (
                <img
                  src={member.photo_url}
                  alt={`${member.first_name} ${member.surname}`}
                  className="h-24 w-24 rounded-full object-cover"
                />
              ) : (
                <UserCircle className="h-24 w-24 text-light-elevated" />
              )}
              <div>
                <h2 className="text-2xl font-bold text-light-text-primary">
                  {member.first_name} {member.surname}
                </h2>
                <div className="flex items-center text-light-text-secondary mt-1">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>{member.town}, {member.suburb}</span>
                </div>
                <div className="flex items-center text-light-text-secondary mt-1">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span>Member since {format(new Date(member.join_date), 'MMMM yyyy')}</span>
                </div>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-light-text-secondary hover:text-light-text-primary"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          {/* INF Registration Link Section */}
          <div className="mb-8 bg-light-secondary p-4 rounded-lg">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-light-text-primary">INF Registration</h3>
              {!editingLink && (
                <div className="space-x-2">
                  {member.inf_registration_link && (
                    <button
                      onClick={() => setShowQrCode(true)}
                      className="px-3 py-2 text-light-action-primary hover:text-opacity-80"
                      title="Show QR Code"
                    >
                      <QrCode className="h-5 w-5" />
                    </button>
                  )}
                  <button
                    onClick={() => setEditingLink(true)}
                    className="px-3 py-2 text-light-action-primary hover:text-opacity-80"
                  >
                    <Edit2 className="h-5 w-5" />
                  </button>
                </div>
              )}
            </div>

            {editingLink ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-light-text-primary mb-1">
                    Registration Link
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={infLink}
                      onChange={(e) => setInfLink(e.target.value)}
                      placeholder="https://example.com/registration"
                      className="flex-1 rounded-md border-light-elevated focus:border-light-action-primary focus:ring-light-action-primary"
                    />
                    <button
                      onClick={handleSaveLink}
                      className="px-4 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => {
                        setEditingLink(false);
                        setInfLink(member.inf_registration_link || '');
                      }}
                      className="px-4 py-2 text-light-text-secondary hover:text-light-text-primary"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                {member.inf_registration_link ? (
                  <a
                    href={member.inf_registration_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center text-light-action-link hover:text-opacity-80"
                  >
                    <Link className="h-4 w-4 mr-2" />
                    {member.inf_registration_link}
                  </a>
                ) : (
                  <p className="text-light-text-secondary italic">No registration link provided</p>
                )}
              </div>
            )}
          </div>

          {/* QR Code Modal */}
          {showQrCode && qrCodeUrl && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-light-surface p-6 rounded-lg shadow-light-lg max-w-sm w-full text-center">
                <h3 className="text-lg font-semibold text-light-text-primary mb-4">
                  INF Registration QR Code
                </h3>
                <div className="bg-white p-4 rounded-lg inline-block mb-4">
                  <img src={qrCodeUrl} alt="QR Code" className="mx-auto" />
                </div>
                <p className="text-sm text-light-text-secondary mb-4">
                  Scan this code to access the INF registration page
                </p>
                <button
                  onClick={() => setShowQrCode(false)}
                  className="px-4 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90"
                >
                  Close
                </button>
              </div>
            </div>
          )}

          {/* Photo Gallery */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-light-text-primary">Photo Gallery</h3>
              <button
                onClick={() => setShowPhotoUpload(true)}
                className="flex items-center px-3 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90"
              >
                <Camera className="h-4 w-4 mr-2" />
                Add Photo
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {gallery.map((photo) => (
                <div key={photo.id} className="relative group">
                  <img
                    src={photo.photo_url}
                    alt={photo.caption || 'Gallery photo'}
                    className="w-full h-48 object-cover rounded-lg"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity rounded-lg flex items-center justify-center">
                    <button
                      onClick={() => handleDeletePhoto(photo.id)}
                      className="opacity-0 group-hover:opacity-100 p-2 bg-light-action-error text-white rounded-full hover:bg-opacity-90"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  {photo.caption && (
                    <p className="mt-1 text-sm text-light-text-secondary">{photo.caption}</p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Stories */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-light-text-primary">Stories</h3>
              <button
                onClick={() => setShowStoryForm(true)}
                className="flex items-center px-3 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90"
              >
                <Plus className="h-4 w-4 mr-2" />
                New Story
              </button>
            </div>
            {stories.map((story) => (
              <div key={story.id} className="bg-light-secondary rounded-lg p-4 mb-4 border border-light-elevated">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-lg font-medium text-light-text-primary">{story.title}</h4>
                    <p className="text-sm text-light-text-secondary">
                      {format(new Date(story.created_at), 'PPP')}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteStory(story.id)}
                    className="text-light-text-secondary hover:text-light-action-error"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                <p className="mt-2 text-light-text-primary whitespace-pre-wrap">{story.content}</p>
              </div>
            ))}
          </div>

          {/* New Story Form */}
          {showStoryForm && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-light-surface p-6 rounded-lg shadow-light-lg max-w-2xl w-full">
                <h3 className="text-lg font-semibold text-light-text-primary mb-4">New Story</h3>
                <form onSubmit={handleStorySubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-light-text-primary">Title</label>
                    <input
                      type="text"
                      value={newStory.title}
                      onChange={(e) => setNewStory({ ...newStory, title: e.target.value })}
                      className="mt-1 block w-full rounded-md border-light-elevated bg-light-surface text-light-text-primary focus:border-light-action-primary focus:ring-light-action-primary"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-light-text-primary">Content</label>
                    <textarea
                      value={newStory.content}
                      onChange={(e) => setNewStory({ ...newStory, content: e.target.value })}
                      rows={6}
                      className="mt-1 block w-full rounded-md border-light-elevated bg-light-surface text-light-text-primary focus:border-light-action-primary focus:ring-light-action-primary"
                      required
                    />
                  </div>
                  <div className="flex justify-end space-x-3">
                    <button
                      type="button"
                      onClick={() => setShowStoryForm(false)}
                      className="px-4 py-2 text-light-text-secondary hover:text-light-text-primary"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90"
                    >
                      Publish Story
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Photo Upload Form */}
          {showPhotoUpload && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-light-surface p-6 rounded-lg shadow-light-lg max-w-2xl w-full">
                <h3 className="text-lg font-semibold text-light-text-primary mb-4">Upload Photo</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-light-text-primary">Photo</label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoChange}
                      className="mt-1 block w-full text-light-text-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-light-text-primary">Caption</label>
                    <input
                      type="text"
                      value={photoCaption}
                      onChange={(e) => setPhotoCaption(e.target.value)}
                      className="mt-1 block w-full rounded-md border-light-elevated bg-light-surface text-light-text-primary focus:border-light-action-primary focus:ring-light-action-primary"
                    />
                  </div>
                  {uploadProgress > 0 && (
                    <div className="w-full bg-light-elevated rounded-full h-2.5">
                      <div
                        className="bg-light-action-primary h-2.5 rounded-full"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                  )}
                  <div className="flex justify-end space-x-3">
                    <button
                      onClick={() => setShowPhotoUpload(false)}
                      className="px-4 py-2 text-light-text-secondary hover:text-light-text-primary"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handlePhotoUpload}
                      disabled={!photoFile}
                      className="px-4 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
                    >
                      Upload Photo
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {showCropper && tempPhotoUrl && (
            <ImageCropper
              imageUrl={tempPhotoUrl}
              onCropComplete={handleCropComplete}
              onCancel={() => setShowCropper(false)}
            />
          )}
        </div>
      </div>
    </div>
  );
}