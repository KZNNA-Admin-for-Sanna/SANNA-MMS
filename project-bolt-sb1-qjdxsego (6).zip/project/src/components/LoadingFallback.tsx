import React from 'react';
import { Loader2 } from 'lucide-react';

interface LoadingFallbackProps {
  message?: string;
  minHeight?: string;
}

export function LoadingFallback({ 
  message = 'Loading...', 
  minHeight = '200px' 
}: LoadingFallbackProps) {
  return (
    <div 
      className="flex items-center justify-center" 
      style={{ minHeight }}
    >
      <div className="flex flex-col items-center">
        <Loader2 className="h-8 w-8 text-gray-400 animate-spin mb-2" />
        <div className="text-sm font-medium text-gray-600">{message}</div>
      </div>
    </div>
  );
}