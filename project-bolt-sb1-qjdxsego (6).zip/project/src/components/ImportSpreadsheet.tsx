import React, { useState } from 'react';
import { Upload, AlertCircle, CheckCircle } from 'lucide-react';
import { importSpreadsheetData } from '../lib/importData';
import toast from 'react-hot-toast';

interface ImportSpreadsheetProps {
  onComplete: () => void;
}

export default function ImportSpreadsheet({ onComplete }: ImportSpreadsheetProps) {
  const [isImporting, setIsImporting] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsImporting(true);
      setProgress(10);

      // Read the file
      const text = await file.text();
      setProgress(30);

      // Parse CSV
      const rows = text.split('\n')
        .map(row => row.split(';'))
        .filter(row => row.length > 1); // Filter out empty rows
      
      setProgress(50);

      // Remove header row
      rows.shift();
      
      setProgress(70);

      // Import the data
      const result = await importSpreadsheetData(rows);
      setProgress(100);

      if (result.success) {
        toast.success(result.message);
        onComplete();
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error('Error importing file:', error);
      toast.error('Failed to import file');
    } finally {
      setIsImporting(false);
      setProgress(0);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-light-surface p-6 rounded-lg shadow-light-lg max-w-md w-full">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-light-text-primary">Import Members</h2>
        </div>

        <div className="space-y-4">
          <div className="border-2 border-dashed border-light-elevated rounded-lg p-8 text-center">
            <Upload className="h-12 w-12 mx-auto text-light-text-secondary mb-4" />
            <p className="text-light-text-primary font-medium mb-2">
              Upload CSV File
            </p>
            <p className="text-sm text-light-text-secondary mb-4">
              File should contain member information in CSV format with semicolon (;) separators
            </p>
            <input
              type="file"
              accept=".csv"
              onChange={handleFileSelect}
              disabled={isImporting}
              className="hidden"
              id="file-upload"
            />
            <label
              htmlFor="file-upload"
              className={`inline-flex items-center px-4 py-2 bg-light-action-primary text-white rounded-md hover:bg-opacity-90 cursor-pointer ${
                isImporting ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {isImporting ? 'Importing...' : 'Select File'}
            </label>
          </div>

          {isImporting && (
            <div className="space-y-2">
              <div className="h-2 bg-light-elevated rounded-full overflow-hidden">
                <div 
                  className="h-full bg-light-action-primary transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-sm text-light-text-secondary text-center">
                Importing data... {progress}%
              </p>
            </div>
          )}

          <div className="bg-light-secondary p-4 rounded-lg">
            <h3 className="font-medium text-light-text-primary mb-2">Required Fields:</h3>
            <ul className="list-disc list-inside text-sm text-light-text-secondary space-y-1">
              <li>Member Number</li>
              <li>Association (PNA)</li>
              <li>First Name</li>
              <li>Surname</li>
              <li>Contact Details (phone/email)</li>
            </ul>
          </div>
        </div>

        <div className="flex justify-end mt-6">
          <button
            onClick={onComplete}
            className="px-4 py-2 text-light-text-secondary hover:text-light-text-primary"
            disabled={isImporting}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}