import React, { useState, useEffect, useRef } from 'react';
import { format, differenceInMonths } from 'date-fns';
import { Member, MembershipType, MemberStatus, PNAType } from '../types/member';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import { Upload, X, UserCircle, Edit2, Trash2, Link, QrCode, Camera } from 'lucide-react';
import { ImageCropper } from './ImageCropper';
import { MemberProfile } from './MemberProfile';

interface MemberFormProps {
  onSubmit: (member: Member) => void;
  onCancel: () => void;
  initialData?: Member;
}

export default function MemberForm({ onSubmit, onCancel, initialData }: MemberFormProps) {
  const [formData, setFormData] = useState<Partial<Member>>(
    initialData || {
      membership_type: 'annual',
      status: 'Active',
      pna: 'GNA',
      join_date: format(new Date(), 'yyyy-MM-dd')
    }
  );
  const [note, setNote] = useState('');
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(initialData?.photo_url || null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [showCropper, setShowCropper] = useState(false);
  const [tempPhotoUrl, setTempPhotoUrl] = useState<string | null>(null);
  const [showProfile, setShowProfile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Update status when date_renewed changes
  useEffect(() => {
    if (formData.membership_type === 'annual') {
      if (!formData.date_renewed) {
        setFormData(prev => ({ ...prev, status: 'Dormant' }));
      } else {
        const monthsSinceRenewal = differenceInMonths(new Date(), new Date(formData.date_renewed));
        if (monthsSinceRenewal >= 12) {
          setFormData(prev => ({ ...prev, status: 'Dormant' }));
        } else {
          setFormData(prev => ({ ...prev, status: 'Active' }));
        }
      }
    }
  }, [formData.date_renewed, formData.membership_type]);

  const validateStatusChange = (status: MemberStatus, note: string) => {
    if ((status === 'Resigned' || status === 'Banned') && note.length < 100) {
      return 'A detailed note of at least 100 characters is required for Resigned or Banned status';
    }
    if (note.length > 0 && note.length < 20) {
      return 'Notes must contain at least 20 characters';
    }
    return null;
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Photo must be less than 5MB');
        return;
      }
      
      if (!file.type.startsWith('image/')) {
        toast.error('File must be an image');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setTempPhotoUrl(reader.result as string);
        setShowCropper(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCropComplete = (croppedImage: string) => {
    setShowCropper(false);
    setPhotoPreview(croppedImage);
    
    // Convert base64 to File
    fetch(croppedImage)
      .then(res => res.blob())
      .then(blob => {
        const file = new File([blob], 'cropped-photo.jpg', { type: 'image/jpeg' });
        setPhotoFile(file);
      });
  };

  const removePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview(null);
    setFormData({ ...formData, photo_url: null });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const uploadPhoto = async (memberId: string): Promise<string | null> => {
    if (!photoFile) return formData.photo_url || null;

    const fileExt = photoFile.name.split('.').pop();
    const fileName = `${memberId}-${Date.now()}.${fileExt}`;

    try {
      const { error: uploadError, data } = await supabase.storage
        .from('member-photos')
        .upload(fileName, photoFile, {
          onUploadProgress: (progress) => {
            const percentage = (progress.loaded / progress.total) * 100;
            setUploadProgress(Math.round(percentage));
          },
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('member-photos')
        .getPublicUrl(fileName);

      return publicUrl;
    } catch (error) {
      console.error('Error uploading photo:', error);
      throw error;
    } finally {
      setUploadProgress(0);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const validationError = validateStatusChange(formData.status as MemberStatus, note);
    if (validationError) {
      toast.error(validationError);
      return;
    }

    if (formData.membership_type === 'annual' && formData.date_renewed && formData.join_date) {
      const renewalDate = new Date(formData.date_renewed);
      const joinDate = new Date(formData.join_date);
      
      if (renewalDate < joinDate) {
        toast.error('Renewal date cannot be before join date');
        return;
      }
    }

    try {
      let photoUrl = formData.photo_url;

      if (initialData) {
        // Update existing member
        if (photoFile) {
          photoUrl = await uploadPhoto(initialData.id);
        }

        const { error: memberError } = await supabase
          .from('members')
          .update({ ...formData, photo_url: photoUrl })
          .eq('id', initialData.id);

        if (memberError) throw memberError;

        // Add note if provided
        if (note.length > 0) {
          const { error: noteError } = await supabase
            .from('member_notes')
            .insert([{
              member_id: initialData.id,
              note,
              effective_date: new Date().toISOString()
            }]);

          if (noteError) throw noteError;
        }
      } else {
        // Insert new member
        const { data: memberData, error: memberError } = await supabase
          .from('members')
          .insert([formData])
          .select()
          .single();

        if (memberError) throw memberError;

        if (photoFile && memberData) {
          photoUrl = await uploadPhoto(memberData.id);
          const { error: updateError } = await supabase
            .from('members')
            .update({ photo_url: photoUrl })
            .eq('id', memberData.id);

          if (updateError) throw updateError;
        }

        // Add initial note if provided
        if (note.length > 0 && memberData) {
          const { error: noteError } = await supabase
            .from('member_notes')
            .insert([{
              member_id: memberData.id,
              note,
              effective_date: new Date().toISOString()
            }]);

          if (noteError) throw noteError;
        }
      }
      
      toast.success(initialData ? 'Member updated successfully' : 'Member added successfully');
      onSubmit(formData as Member);
    } catch (error) {
      toast.error('Error saving member');
      console.error('Error:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* View Profile Button - Only show for existing members */}
      {initialData && (
        <div className="flex justify-end">
          <button
            type="button"
            onClick={() => setShowProfile(true)}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            <UserCircle className="h-5 w-5 mr-2" />
            View Profile
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Photo Upload Section */}
        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Member Photo
          </label>
          <div className="flex items-center space-x-4">
            {photoPreview ? (
              <div className="relative">
                <img
                  src={photoPreview}
                  alt="Member preview"
                  className="h-32 w-32 object-cover rounded-full"
                />
                <button
                  type="button"
                  onClick={removePhoto}
                  className="absolute -top-2 -right-2 bg-red-100 rounded-full p-1 hover:bg-red-200"
                >
                  <X className="h-4 w-4 text-red-600" />
                </button>
              </div>
            ) : (
              <div className="h-32 w-32 border-2 border-dashed border-gray-300 rounded-full flex items-center justify-center">
                <div className="text-center">
                  <Upload className="mx-auto h-8 w-8 text-gray-400" />
                  <span className="mt-2 block text-xs text-gray-500">Upload Photo</span>
                </div>
              </div>
            )}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              onChange={handlePhotoChange}
              className="hidden"
            />
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 w-full"
              >
                {photoPreview ? 'Change Photo' : 'Select Photo'}
              </button>
              {uploadProgress > 0 && (
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div
                    className="bg-blue-600 h-2.5 rounded-full"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              )}
            </div>
          </div>
          <p className="mt-1 text-sm text-gray-500">
            Maximum file size: 5MB. Supported formats: JPG, PNG, GIF
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">INF Stamp Number</label>
          <input
            type="text"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.inf_stamp_number || ''}
            onChange={(e) => setFormData({ ...formData, inf_stamp_number: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">First Name</label>
          <input
            type="text"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.first_name || ''}
            onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Surname</label>
          <input
            type="text"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.surname || ''}
            onChange={(e) => setFormData({ ...formData, surname: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Telephone</label>
          <input
            type="tel"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.telephone || ''}
            onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Town</label>
          <input
            type="text"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.town || ''}
            onChange={(e) => setFormData({ ...formData, town: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Suburb</label>
          <input
            type="text"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.suburb || ''}
            onChange={(e) => setFormData({ ...formData, suburb: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Email</label>
          <input
            type="email"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.email || ''}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Join Date</label>
          <input
            type="date"
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.join_date || ''}
            onChange={(e) => setFormData({ ...formData, join_date: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Membership Type</label>
          <select
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.membership_type || 'annual'}
            onChange={(e) => setFormData({ ...formData, membership_type: e.target.value as MembershipType })}
          >
            <option value="annual">Annual</option>
            <option value="honorary">Honorary</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Provincial Association (PNA)</label>
          <select
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.pna || 'GNA'}
            onChange={(e) => setFormData({ ...formData, pna: e.target.value as PNAType })}
          >
            <option value="GNA">GNA - Gauteng Naturist Association</option>
            <option value="KZNNA">KZNNA - KwaZulu-Natal Naturist Association</option>
            <option value="WPNA">WPNA - Western Province Naturist Association</option>
            <option value="NWNA">NWNA - North West Naturist Association</option>
            <option value="IMNA">IMNA - Individual Members Naturist Association</option>
            <option value="SANYA">SANYA - South African Naturist Youth Association</option>
            <option value="FSNA">FSNA - Free State Naturist Association</option>
            <option value="NCNA">NCNA - Northern Cape Naturist Association</option>
            <option value="LNA">LNA - Limpopo Naturist Association</option>
            <option value="MPNA">MPNA - Mpumalanga Naturist Association</option>
            <option value="ECNA">ECNA - Eastern Cape Naturist Association</option>
            <option value="WCNA">WCNA - Western Cape Naturist Association</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Status</label>
          <select
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={formData.status || 'Active'}
            onChange={(e) => setFormData({ ...formData, status: e.target.value as MemberStatus })}
          >
            <option value="Active">Active</option>
            <option value="Dormant">Dormant</option>
            <option value="Resigned">Resigned</option>
            <option value="Banned">Banned</option>
          </select>
        </div>

        {formData.membership_type === 'annual' && (
          <div>
            <label className="block text-sm font-medium text-gray-700">Date Renewed</label>
            <input
              type="date"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value={formData.date_renewed || ''}
              onChange={(e) => setFormData({ ...formData, date_renewed: e.target.value })}
            />
          </div>
        )}

        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700">
            Note {(formData.status === 'Resigned' || formData.status === 'Banned') && 
              <span className="text-red-600">* (Required, minimum 100 characters)</span>
            }
          </label>
          <textarea
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            rows={4}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={formData.status === 'Resigned' || formData.status === 'Banned' 
              ? "Please provide:\n1. Effective Date\n2. Reason (min. 100 characters)\n3. Supporting Evidence\n4. Action Taken By"
              : "Add a note (optional, minimum 20 characters if provided)"
            }
          />
          <div className="mt-1 text-sm text-gray-500">
            {note.length} characters
            {(formData.status === 'Resigned' || formData.status === 'Banned') && 
              ` (minimum 100 required)`
            }
          </div>
        </div>
      </div>

      <div className="flex justify-end space-x-3 mt-6">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-gray-600 hover:text-gray-900"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          {initialData ? 'Update Member' : 'Add Member'}
        </button>
      </div>

      {showCropper && tempPhotoUrl && (
        <ImageCropper
          imageUrl={tempPhotoUrl}
          onCropComplete={handleCropComplete}
          onCancel={() => setShowCropper(false)}
        />
      )}

      {showProfile && initialData && (
        <MemberProfile
          member={initialData}
          onClose={() => setShowProfile(false)}
          onUpdate={() => {
            setShowProfile(false);
            onSubmit(formData as Member);
          }}
        />
      )}
    </form>
  );
}