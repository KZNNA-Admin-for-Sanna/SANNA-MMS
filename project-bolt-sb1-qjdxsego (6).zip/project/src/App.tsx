import React, { useState, useEffect, Suspense, lazy } from 'react';
import { Toaster } from 'react-hot-toast';
import { Users, Plus, Settings, RefreshCw, Upload } from 'lucide-react';
import { supabase, checkSupabaseConnection, retryOperation } from './lib/supabase';
import { Member } from './types/member';
import { Dashboard } from './components/Dashboard';
import { MemberList } from './components/MemberList';
import { LoginPage } from './components/LoginPage';
import { ErrorBoundary } from './components/ErrorBoundary';
import { logger } from './lib/logger';
import toast from 'react-hot-toast';

// Lazy load components that aren't immediately needed
const MemberForm = lazy(() => import('./components/MemberForm'));
const MembershipFees = lazy(() => import('./components/MembershipFees'));
const ImportSpreadsheet = lazy(() => import('./components/ImportSpreadsheet'));
const RegisteredUsers = lazy(() => import('./components/RegisteredUsers'));

function LoadingFallback() {
  return (
    <div className="min-h-[200px] flex items-center justify-center">
      <div className="text-lg font-semibold text-gray-600">Loading...</div>
    </div>
  );
}

function App() {
  const [members, setMembers] = useState<Member[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [showMembershipFees, setShowMembershipFees] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [selectedMember, setSelectedMember] = useState<Member | undefined>();
  const [filter, setFilter] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(true);
  const [isAdminUser, setIsAdminUser] = useState(false);
  const [connectionError, setConnectionError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    checkAuthStatus();
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      initializeApp();
    }
  }, [isAuthenticated, retryCount]);

  const checkAuthStatus = async () => {
    try {
      logger.debug('Checking auth status...');
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error) {
        logger.error('Auth check failed:', error);
        setConnectionError(true);
        return;
      }

      logger.debug('Auth status:', session ? 'authenticated' : 'not authenticated');
      setIsAuthenticated(!!session);
    } catch (error) {
      logger.error('Error checking auth status:', error);
      setConnectionError(true);
    }
  };

  const initializeApp = async () => {
    try {
      setIsLoading(true);
      setConnectionError(false);

      logger.debug('Initializing app...');

      const isConnected = await retryOperation(
        async () => await checkSupabaseConnection(),
        3,
        2000
      );

      if (!isConnected) {
        logger.error('Failed to connect to Supabase after retries');
        setConnectionError(true);
        return;
      }

      await fetchMembers();
      
      logger.info('App initialized successfully');
    } catch (error) {
      logger.error('Error initializing app:', error);
      setConnectionError(true);
      toast.error('Failed to initialize application');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetryConnection = () => {
    setRetryCount(prev => prev + 1);
  };

  const fetchMembers = async () => {
    try {
      const { data, error } = await retryOperation(async () => {
        return await supabase
          .from('members')
          .select('*')
          .order('surname', { ascending: true });
      });

      if (error) throw error;
      setMembers(data || []);
    } catch (error) {
      console.error('Error fetching members:', error);
      throw error;
    }
  };

  const handleEdit = (member: Member) => {
    setSelectedMember(member);
    setShowForm(true);
  };

  const handleDelete = async (member: Member) => {
    try {
      const { error } = await retryOperation(async () => {
        return await supabase
          .from('members')
          .delete()
          .eq('id', member.id);
      });

      if (error) throw error;

      setMembers(prevMembers => prevMembers.filter(m => m.id !== member.id));
      toast.success('Member deleted successfully');
    } catch (error) {
      console.error('Error deleting member:', error);
      toast.error('Failed to delete member');
    }
  };

  const handleMemberUpdate = (updatedMember: Member) => {
    setMembers(prevMembers => 
      prevMembers.map(member => 
        member.id === updatedMember.id ? updatedMember : member
      )
    );
    setShowForm(false);
  };

  const filteredMembers = members.filter((member) => {
    if (filter === 'all') return true;
    return member.status.toLowerCase() === filter.toLowerCase();
  });

  return (
    <ErrorBoundary>
      <div className="min-h-screen relative z-10">
        <Toaster position="top-right" />
        
        {!isAuthenticated ? (
          <LoginPage onLogin={() => setIsAuthenticated(true)} />
        ) : isLoading ? (
          <div className="min-h-screen flex items-center justify-center">
            <div className="text-lg font-semibold text-gray-600">Loading...</div>
          </div>
        ) : connectionError ? (
          <div className="min-h-screen flex items-center justify-center">
            <div className="bg-white p-8 rounded-lg shadow-lg text-center max-w-md w-full mx-4">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Connection Error</h2>
              <p className="text-gray-600 mb-6">
                Unable to connect to the database. Please check your connection and try again.
              </p>
              <button
                onClick={handleRetryConnection}
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                <RefreshCw className="h-5 w-5 mr-2" />
                Retry Connection
              </button>
            </div>
          </div>
        ) : (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 sm:mb-8 gap-4">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-light-action-primary mr-3" />
                <h1 className="text-2xl font-bold text-light-text-primary">SANNA (MMS)</h1>
              </div>
              <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                <button
                  onClick={() => {
                    setSelectedMember(undefined);
                    setShowForm(true);
                  }}
                  className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex-grow sm:flex-grow-0"
                >
                  <Plus className="h-5 w-5 mr-2" />
                  Add Member
                </button>
                {isAdminUser && (
                  <>
                    <button
                      onClick={() => setShowMembershipFees(true)}
                      className="flex items-center px-4 py-2 bg-light-action-orange text-white rounded-md hover:bg-opacity-90 transition-colors flex-grow sm:flex-grow-0"
                    >
                      <Settings className="h-5 w-5 mr-2" />
                      Membership Fees
                    </button>
                    <button
                      onClick={() => setShowImport(true)}
                      className="flex items-center px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 transition-colors flex-grow sm:flex-grow-0"
                    >
                      <Upload className="h-5 w-5 mr-2" />
                      Import
                    </button>
                  </>
                )}
              </div>
            </div>
            
            <ErrorBoundary>
              <Dashboard members={members} />
            </ErrorBoundary>

            <div className="mt-8">
              <div className="bg-white shadow-lg rounded-lg overflow-hidden">
                <Suspense fallback={<LoadingFallback />}>
                  <ErrorBoundary>
                    {showMembershipFees ? (
                      <div className="p-4">
                        <MembershipFees />
                      </div>
                    ) : showForm ? (
                      <div className="p-4">
                        <MemberForm
                          initialData={selectedMember}
                          onSubmit={handleMemberUpdate}
                          onCancel={() => setShowForm(false)}
                        />
                      </div>
                    ) : showImport ? (
                      <ImportSpreadsheet
                        onComplete={() => {
                          setShowImport(false);
                          fetchMembers();
                        }}
                      />
                    ) : (
                      <MemberList
                        members={filteredMembers}
                        onEdit={handleEdit}
                        onDelete={handleDelete}
                      />
                    )}
                  </ErrorBoundary>
                </Suspense>
              </div>
            </div>

            <Suspense fallback={<LoadingFallback />}>
              <ErrorBoundary>
                <RegisteredUsers members={members} />
              </ErrorBoundary>
            </Suspense>
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
}

export default App;