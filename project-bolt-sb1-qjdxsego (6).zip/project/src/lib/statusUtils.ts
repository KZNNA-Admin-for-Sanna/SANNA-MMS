import { Member, MemberStatus } from '../types/member';

export function getStatusColor(status: MemberStatus): string {
  switch (status) {
    case 'Active':
      return 'bg-green-500 text-white';
    case 'Dormant':
      return 'bg-yellow-500 text-white';
    case 'Resigned':
      return 'bg-red-900 text-white';
    case 'Naughty':
      return 'bg-brown-600 text-white';
    case 'Banned':
      return 'bg-red-600 text-white';
    default:
      return 'bg-gray-500 text-white';
  }
}

export function validateStatusChange(
  newStatus: MemberStatus,
  note: string | undefined
): string | null {
  if (['Resigned', 'Naughty'].includes(newStatus)) {
    if (!note || note.length < 50) {
      return `A detailed note of at least 50 characters is required for ${newStatus} status`;
    }
  }
  return null;
}

export function isStatusChangeAllowed(
  currentStatus: MemberStatus,
  newStatus: MemberStatus
): boolean {
  // Don't allow manual changes to Dormant status
  if (newStatus === 'Dormant') {
    return false;
  }

  // Don't allow changes from Resigned unless by admin
  if (currentStatus === 'Resigned') {
    return false;
  }

  return true;
}

export function getStatusBadgeClass(member: Member): string {
  const baseClasses = 'status-badge';
  
  switch (member.status) {
    case 'Active':
      return `${baseClasses} active`;
    case 'Dormant':
      return `${baseClasses} dormant`;
    case 'Resigned':
      return `${baseClasses} resigned`;
    case 'Naughty':
      return `${baseClasses} naughty`;
    default:
      return `${baseClasses} bg-gray-500 text-white`;
  }
}