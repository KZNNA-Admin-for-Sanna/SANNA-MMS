import * as Sentry from '@sentry/react';
import { logger } from './logger';

export function initErrorTracking() {
  if (import.meta.env.PROD) {
    Sentry.init({
      dsn: "https://e6c5573b9eecf317dc45d4f6d33264b2@o4509034051600384.ingest.de.sentry.io/4509034079977552",
      integrations: [
        new Sentry.BrowserTracing({
          tracePropagationTargets: ["localhost", /^https:\/\/[^/]*\.sanna\.org\.za/],
        }),
        new Sentry.Replay()
      ],
      // Performance Monitoring
      tracesSampleRate: 1.0, // Capture 100% of transactions in development
      // Session Replay
      replaysSessionSampleRate: 0.1, // Sample rate for session replays
      replaysOnErrorSampleRate: 1.0, // Sample rate for replays on error
      environment: import.meta.env.MODE,
      beforeSend(event) {
        // Don't send events in development
        if (import.meta.env.DEV) {
          return null;
        }
        return event;
      },
    });
  }
}

export function captureError(error: Error, context?: Record<string, any>) {
  logger.error('Error captured:', error);
  
  if (import.meta.env.PROD) {
    Sentry.captureException(error, {
      extra: context
    });
  }
}

export function captureMessage(message: string, level: Sentry.SeverityLevel = 'info') {
  logger.info('Message captured:', message);
  
  if (import.meta.env.PROD) {
    Sentry.captureMessage(message, level);
  }
}

export function setUserContext(userId: string, email: string) {
  if (import.meta.env.PROD) {
    Sentry.setUser({
      id: userId,
      email: email
    });
  }
}

export function clearUserContext() {
  if (import.meta.env.PROD) {
    Sentry.setUser(null);
  }
}