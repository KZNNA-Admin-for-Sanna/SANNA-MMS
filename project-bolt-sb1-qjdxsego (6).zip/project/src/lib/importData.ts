import { supabase } from './supabase';
import { Member, PNAType } from '../types/member';
import { parse, isValid, format } from 'date-fns';
import toast from 'react-hot-toast';

interface ImportedMember {
  memberNo: string;
  association: string;
  firstName: string;
  surname: string;
  cellNo: string;
  email: string;
  infStamp: string;
  notes: string;
}

export async function importSpreadsheetData(data: any[]): Promise<{ success: boolean; message: string }> {
  try {
    // Transform spreadsheet data to match our schema
    const members = data
      .filter(row => row[0] && row[2] && row[3]) // Filter out empty rows
      .map((row): Partial<Member> => {
        const memberNo = row[0]?.toString().trim();
        const association = row[1]?.toString().trim() || 'GNA';
        const firstName = row[2]?.toString().trim();
        const surname = row[3]?.toString().trim();
        const telephone = row[4]?.toString().trim();
        const email = row[5]?.toString().trim();
        const infStamp = row[6]?.toString().trim() || memberNo;
        const notes = row[24]?.toString().trim();

        // Clean phone number
        const cleanPhone = telephone?.replace(/[^0-9+]/g, '');
        
        // Validate email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const validEmail = email && emailRegex.test(email) ? email : null;

        // Set default join date to today if not provided
        const joinDate = format(new Date(), 'yyyy-MM-dd');

        return {
          inf_stamp_number: infStamp || memberNo,
          first_name: firstName,
          surname: surname,
          telephone: cleanPhone || null,
          email: validEmail,
          join_date: joinDate,
          membership_type: 'annual',
          pna: (association || 'GNA') as PNAType,
          status: 'Active',
          amount_paid: 0,
          outstanding_balance: 0,
          renewal_amount: 0,
          notes: notes || null
        };
      });

    // Validate required fields
    const invalidMembers = members.filter(
      member => !member.inf_stamp_number || !member.first_name || !member.surname
    );

    if (invalidMembers.length > 0) {
      return {
        success: false,
        message: `Found ${invalidMembers.length} invalid records. Please ensure INF number, first name and surname are provided.`
      };
    }

    // Insert data in batches of 50
    const batchSize = 50;
    let importedCount = 0;
    let errorCount = 0;

    for (let i = 0; i < members.length; i += batchSize) {
      const batch = members.slice(i, i + batchSize);
      const { error, count } = await supabase.from('members').insert(batch);
      
      if (error) {
        console.error('Batch import error:', error);
        errorCount += batch.length;
      } else {
        importedCount += count || 0;
      }

      // Add a small delay between batches to prevent rate limiting
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    const message = `Successfully imported ${importedCount} members` + 
      (errorCount > 0 ? `. Failed to import ${errorCount} members.` : '');

    return {
      success: importedCount > 0,
      message
    };

  } catch (error) {
    console.error('Error importing data:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Failed to import data'
    };
  }
}