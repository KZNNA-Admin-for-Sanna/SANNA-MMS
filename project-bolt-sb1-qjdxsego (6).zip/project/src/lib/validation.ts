import { z } from 'zod';
import { memberSchema } from '../types/member';
import { differenceInMonths, isValid } from 'date-fns';
import { supabase } from './supabase';

export function validateMemberData(data: unknown) {
  try {
    return {
      success: true,
      data: memberSchema.parse(data)
    };
  } catch (error) {
    if (error instanceof z.ZodError) {
      return {
        success: false,
        errors: error.errors.map(err => ({
          field: err.path.join('.'),
          message: err.message
        }))
      };
    }
    return {
      success: false,
      errors: [{ field: 'unknown', message: 'Validation failed' }]
    };
  }
}

export async function validateInfNumber(infNumber: string | undefined, currentMemberId?: string): Promise<string | null> {
  if (!infNumber) return null;

  // Must be alphanumeric with optional hyphens
  if (!/^[a-zA-Z0-9-]+$/.test(infNumber)) {
    return 'INF number can only contain letters, numbers, and hyphens';
  }

  try {
    // Check if INF number is already in use by another active member
    const { data, error } = await supabase
      .from('members')
      .select('id')
      .eq('inf_stamp_number', infNumber)
      .eq('status', 'Active')
      .not('id', 'eq', currentMemberId || '')
      .maybeSingle();

    if (error) throw error;

    if (data) {
      return 'This INF number is already in use by an active member';
    }

    return null;
  } catch (error) {
    console.error('Error validating INF number:', error);
    return 'Failed to validate INF number';
  }
}

export function validatePhoneNumber(phone: string): string | null {
  if (!phone) return null;

  // Remove all non-digit characters
  const cleaned = phone.replace(/\D/g, '');
  
  // Must start with 0
  if (!cleaned.startsWith('0')) {
    return 'Phone number must start with 0';
  }

  // Must be 10 digits
  if (cleaned.length !== 10) {
    return 'Phone number must be 10 digits';
  }

  return null;
}

export function validateDates(joinDate: string, renewalDate?: string | null): string | null {
  if (!joinDate) {
    return 'Join date is required';
  }

  const join = new Date(joinDate);
  if (!isValid(join)) {
    return 'Invalid join date';
  }
  
  if (renewalDate) {
    const renewal = new Date(renewalDate);
    if (!isValid(renewal)) {
      return 'Invalid renewal date';
    }
    
    if (renewal < join) {
      return 'Renewal date cannot be before join date';
    }

    const monthsSinceRenewal = differenceInMonths(new Date(), renewal);
    if (monthsSinceRenewal > 12) {
      return 'Renewal date cannot be more than 12 months ago';
    }
  }

  return null;
}

export function validateEmail(email: string): string | null {
  if (!email) return null;

  // More permissive email regex that allows numbers at the start
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(email)) {
    return 'Invalid email address';
  }

  return null;
}

export function validateInfStampNumber(number: string | undefined): string | null {
  if (!number) return null;

  // Must be alphanumeric with optional hyphens
  if (!/^[a-zA-Z0-9-]+$/.test(number)) {
    return 'INF stamp number can only contain letters, numbers, and hyphens';
  }

  return null;
}