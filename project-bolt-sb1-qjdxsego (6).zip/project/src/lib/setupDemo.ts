import { supabase } from './supabase';
import { logger } from './logger';
import { retryOperation } from './supabase';

export async function setupDemoUser() {
  try {
    logger.info('Setting up demo SANNA user...');

    // First check if user already exists
    const { data: existingUser } = await retryOperation(async () => {
      return await supabase.auth.signInWithPassword({
        email: 'marketing@sanna.org.za',
        password: '@sanna2025'
      });
    }, 3, 1000);

    if (existingUser?.user) {
      logger.info('Demo user already exists');
      return;
    }

    // Create member record first
    const { data: member, error: memberError } = await retryOperation(async () => {
      const result = await supabase
        .from('members')
        .insert({
          first_name: 'SANNA',
          surname: 'Admin',
          email: 'marketing@sanna.org.za',
          join_date: new Date().toISOString(),
          membership_type: 'honorary',
          pna: 'GNA',
          status: 'Active',
          amount_paid: 0,
          outstanding_balance: 0,
          renewal_amount: 0
        })
        .select()
        .single();

      if (result.error) throw result.error;
      return result;
    }, 3, 1000);

    if (memberError) throw memberError;
    if (!member) throw new Error('Failed to create member record');

    // Wait for member record to be committed
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Create auth account
    const { data: signUpData, error: signUpError } = await retryOperation(async () => {
      return await supabase.auth.signUp({
        email: 'marketing@sanna.org.za',
        password: '@sanna2025'
      });
    }, 3, 1000);

    if (signUpError) throw signUpError;
    if (!signUpData?.user) throw new Error('No user data returned from signup');

    // Wait for auth to propagate
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Link member to auth user
    const { error: linkError } = await retryOperation(async () => {
      return await supabase
        .from('members')
        .update({ 
          auth_user_id: signUpData.user!.id,
          updated_at: new Date().toISOString()
        })
        .eq('id', member.id);
    }, 3, 1000);

    if (linkError) throw linkError;

    logger.info('Demo user created successfully');
  } catch (error) {
    logger.error('Error setting up demo user:', error);
    throw error;
  }
}