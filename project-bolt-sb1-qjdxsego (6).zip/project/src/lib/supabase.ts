import { createClient } from '@supabase/supabase-js';
import { logger } from './logger';
import { captureError } from './errorTracking';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export async function checkSupabaseConnection(): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('members')
      .select('count')
      .limit(1)
      .single();

    return !error;
  } catch (error) {
    logger.error('Error checking connection:', error);
    captureError(error as Error, { context: 'checkSupabaseConnection' });
    return false;
  }
}

export async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries = 3,
  initialDelay = 1000
): Promise<T> {
  let lastError: any;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      logger.debug(`Attempt ${i + 1}/${maxRetries}`);
      return await operation();
    } catch (error) {
      lastError = error;
      logger.error(`Attempt ${i + 1} failed:`, error);
      captureError(error as Error, { 
        context: 'retryOperation',
        attempt: i + 1,
        maxRetries
      });
      
      if (i < maxRetries - 1) {
        const delay = initialDelay * Math.pow(2, i);
        logger.debug(`Waiting ${delay}ms before retry`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw lastError;
}