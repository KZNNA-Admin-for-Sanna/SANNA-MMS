import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { Member, MemberNote } from '../types/member';
import { logger } from './logger';

interface MemberDB extends DBSchema {
  members: {
    key: string;
    value: Member;
    indexes: { 'by-email': string; 'by-status': string; 'by-pna': string };
  };
  memberNotes: {
    key: string;
    value: MemberNote;
    indexes: { 'by-member': string };
  };
  pendingChanges: {
    key: string;
    value: {
      type: 'create' | 'update' | 'delete';
      table: string;
      data: any;
      timestamp: number;
    };
  };
}

let db: IDBPDatabase<MemberDB>;

export async function initDB() {
  try {
    db = await openDB<MemberDB>('sanna-mms', 1, {
      upgrade(db) {
        // Members store
        const memberStore = db.createObjectStore('members', { keyPath: 'id' });
        memberStore.createIndex('by-email', 'email');
        memberStore.createIndex('by-status', 'status');
        memberStore.createIndex('by-pna', 'pna');

        // Member notes store
        const notesStore = db.createObjectStore('memberNotes', { keyPath: 'id' });
        notesStore.createIndex('by-member', 'member_id');

        // Pending changes store
        db.createObjectStore('pendingChanges', { 
          keyPath: 'id',
          autoIncrement: true 
        });
      },
    });
    logger.info('IndexedDB initialized successfully');
  } catch (error) {
    logger.error('Error initializing IndexedDB:', error);
    throw error;
  }
}

export async function saveMember(member: Member) {
  try {
    await db.put('members', {
      ...member,
      last_synced: new Date().toISOString()
    });

    await db.add('pendingChanges', {
      type: 'update',
      table: 'members',
      data: member,
      timestamp: Date.now()
    });

    logger.debug('Member saved locally:', member.id);
  } catch (error) {
    logger.error('Error saving member locally:', error);
    throw error;
  }
}

export async function getMember(id: string): Promise<Member | undefined> {
  try {
    return await db.get('members', id);
  } catch (error) {
    logger.error('Error getting member from local storage:', error);
    throw error;
  }
}

export async function getAllMembers(): Promise<Member[]> {
  try {
    return await db.getAll('members');
  } catch (error) {
    logger.error('Error getting all members from local storage:', error);
    throw error;
  }
}

export async function getMembersByStatus(status: string): Promise<Member[]> {
  try {
    return await db.getAllFromIndex('members', 'by-status', status);
  } catch (error) {
    logger.error('Error getting members by status:', error);
    throw error;
  }
}

export async function getMembersByPNA(pna: string): Promise<Member[]> {
  try {
    return await db.getAllFromIndex('members', 'by-pna', pna);
  } catch (error) {
    logger.error('Error getting members by PNA:', error);
    throw error;
  }
}

export async function deleteMember(id: string) {
  try {
    await db.delete('members', id);
    await db.add('pendingChanges', {
      type: 'delete',
      table: 'members',
      data: { id },
      timestamp: Date.now()
    });
  } catch (error) {
    logger.error('Error deleting member from local storage:', error);
    throw error;
  }
}

export async function getPendingChanges() {
  try {
    return await db.getAll('pendingChanges');
  } catch (error) {
    logger.error('Error getting pending changes:', error);
    throw error;
  }
}

export async function clearPendingChanges() {
  try {
    const tx = db.transaction('pendingChanges', 'readwrite');
    await tx.objectStore('pendingChanges').clear();
    await tx.done;
  } catch (error) {
    logger.error('Error clearing pending changes:', error);
    throw error;
  }
}