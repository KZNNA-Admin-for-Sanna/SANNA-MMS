import { format } from 'date-fns';

type LogLevel = 'debug' | 'info' | 'warn' | 'error';
type LogFunction = (message: string, ...args: any[]) => void;

interface Logger {
  debug: LogFunction;
  info: LogFunction;
  warn: LogFunction;
  error: LogFunction;
}

class ConsoleLogger implements Logger {
  private isDevelopment = import.meta.env.DEV;
  private static instance: ConsoleLogger;

  private constructor() {}

  static getInstance(): ConsoleLogger {
    if (!ConsoleLogger.instance) {
      ConsoleLogger.instance = new ConsoleLogger();
    }
    return ConsoleLogger.instance;
  }

  private formatMessage(level: LogLevel, message: string): string {
    const timestamp = format(new Date(), 'yyyy-MM-dd HH:mm:ss.SSS');
    return `[${timestamp}] [${level.toUpperCase()}] ${message}`;
  }

  debug(message: string, ...args: any[]) {
    if (this.isDevelopment) {
      console.debug(this.formatMessage('debug', message), ...args);
    }
  }

  info(message: string, ...args: any[]) {
    console.info(this.formatMessage('info', message), ...args);
  }

  warn(message: string, ...args: any[]) {
    console.warn(this.formatMessage('warn', message), ...args);
  }

  error(message: string, error?: Error | unknown, ...args: any[]) {
    console.error(
      this.formatMessage('error', message),
      error instanceof Error ? error.message : error,
      ...args
    );
  }
}

export const logger = ConsoleLogger.getInstance();