import { supabase } from './supabase';
import { logger } from './logger';
import { retryOperation } from './supabase';
import { z } from 'zod';
import toast from 'react-hot-toast';

// Validation schemas
const emailSchema = z.string().email('Invalid email format');
const passwordSchema = z.string().min(8, 'Password must be at least 8 characters');

interface AuthUser {
  id: string;
  email: string;
  created_at: string;
  last_login?: string;
}

export async function handleEmailSignIn(email: string, password: string): Promise<boolean> {
  try {
    emailSchema.parse(email);
    passwordSchema.parse(password);

    logger.debug('Attempting sign in for:', email);

    // Special case for demo user
    if (email === 'marketing@sanna.org.za' && password === '@sanna2025') {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: 'marketing@sanna.org.za',
        password: '@sanna2025'
      });

      if (error) throw error;
      return true;
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) {
      logger.error('Sign in error:', error);
      throw error;
    }

    // Log successful login
    if (data.user) {
      await retryOperation(async () => {
        return await supabase
          .from('admin_actions')
          .insert({
            action_type: 'user_login',
            executed_by: data.user!.id,
            reason: 'User login',
            details: {
              login_date: new Date().toISOString()
            }
          });
      });
    }

    logger.info('Sign in successful');
    return true;
  } catch (error) {
    if (error instanceof z.ZodError) {
      toast.error(error.errors[0].message);
    } else {
      logger.error('Sign in failed:', error);
      toast.error('Invalid email or password');
    }
    return false;
  }
}

export async function handleEmailSignUp(email: string, password: string): Promise<boolean> {
  try {
    // Validate inputs
    emailSchema.parse(email);
    passwordSchema.parse(password);

    logger.debug('Starting signup process for:', email);

    // Check if user is already registered
    const { data: existingUser } = await retryOperation(async () => {
      return await supabase
        .from('members')
        .select('auth_user_id')
        .eq('email', email)
        .single();
    });

    if (existingUser?.auth_user_id) {
      toast.error('This email is already registered');
      return false;
    }

    // Check if member exists and is active
    const { data: member, error: memberError } = await retryOperation(async () => {
      return await supabase
        .from('members')
        .select('*')
        .eq('email', email)
        .eq('status', 'Active')
        .maybeSingle();
    });

    if (memberError) {
      logger.error('Error checking member:', memberError);
      toast.error('Failed to verify member details');
      return false;
    }

    if (!member) {
      logger.warn('No active member found for email:', email);
      toast.error('No matching active member found with this email address');
      return false;
    }

    // Create auth account
    const { data: signUpData, error: signUpError } = await retryOperation(async () => {
      return await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            member_id: member.id,
            first_name: member.first_name,
            last_name: member.surname
          }
        }
      });
    });

    if (signUpError) {
      logger.error('Sign up error:', signUpError);
      toast.error(signUpError.message || 'Failed to create account');
      return false;
    }

    if (!signUpData?.user) {
      logger.error('No user data returned from signup');
      toast.error('Failed to create account');
      return false;
    }

    // Wait for auth to propagate
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Link member to auth user
    const { error: linkError } = await retryOperation(async () => {
      return await supabase
        .from('members')
        .update({
          auth_user_id: signUpData.user!.id,
          updated_at: new Date().toISOString()
        })
        .eq('id', member.id);
    });

    if (linkError) {
      logger.error('Error linking member:', linkError);
      toast.error('Failed to link account');
      return false;
    }

    // Log the registration
    await retryOperation(async () => {
      return await supabase
        .from('admin_actions')
        .insert({
          action_type: 'user_registration',
          target_member_id: member.id,
          executed_by: signUpData.user!.id,
          reason: 'User self-registration',
          details: {
            email: email,
            registration_date: new Date().toISOString()
          }
        });
    });

    logger.info('Signup successful for member:', member.id);
    toast.success('Account created successfully');

    // Sign in immediately
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (signInError) {
      logger.error('Auto sign-in failed:', signInError);
      toast.error('Account created but sign-in failed. Please try signing in manually.');
      return true; // Still return true since account was created
    }

    return true;
  } catch (error) {
    if (error instanceof z.ZodError) {
      toast.error(error.errors[0].message);
    } else {
      logger.error('Unexpected error during signup:', error);
      toast.error('Failed to create account');
    }
    return false;
  }
}

export async function handleSignOut(): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    logger.debug('Signing out user');
    const { error } = await supabase.auth.signOut();
    
    if (error) {
      logger.error('Sign out error:', error);
      throw error;
    }

    // Log sign out
    if (user) {
      await retryOperation(async () => {
        return await supabase
          .from('admin_actions')
          .insert({
            action_type: 'user_logout',
            executed_by: user.id,
            reason: 'User logout',
            details: {
              logout_date: new Date().toISOString()
            }
          });
      });
    }
    
    logger.info('Sign out successful');
    toast.success('Signed out successfully');
  } catch (error) {
    logger.error('Sign out failed:', error);
    toast.error('Failed to sign out');
  }
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  try {
    const { data: { user }, error } = await supabase.auth.getUser();
    
    if (error || !user) {
      return null;
    }

    return {
      id: user.id,
      email: user.email!,
      created_at: user.created_at,
      last_login: user.last_sign_in_at
    };
  } catch (error) {
    logger.error('Error getting current user:', error);
    return null;
  }
}