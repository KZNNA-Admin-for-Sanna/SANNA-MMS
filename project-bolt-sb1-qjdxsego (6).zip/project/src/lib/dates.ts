import { differenceInMonths, differenceInDays, addMonths, format, isValid } from 'date-fns';

export function isExpiringSoon(dateRenewed: string | null | undefined): boolean {
  if (!dateRenewed) return false;
  const renewalDate = new Date(dateRenewed);
  if (!isValid(renewalDate)) return false;
  
  const monthsSinceRenewal = differenceInMonths(new Date(), renewalDate);
  return monthsSinceRenewal >= 11 && monthsSinceRenewal < 12;
}

export function getDaysUntilExpiry(dateRenewed: string | null | undefined): number | null {
  if (!dateRenewed) return null;
  const renewalDate = new Date(dateRenewed);
  if (!isValid(renewalDate)) return null;
  
  const expiryDate = addMonths(renewalDate, 12);
  return differenceInDays(expiryDate, new Date());
}

export function formatDate(date: string | Date, formatString: string = 'dd/MM/yyyy'): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  if (!isValid(dateObj)) return 'Invalid date';
  return format(dateObj, formatString);
}

export function calculateMembershipStatus(
  membershipType: string,
  dateRenewed: string | null | undefined,
  currentStatus: string
): string {
  // Don't change status for resigned or banned members
  if (['Resigned', 'Banned'].includes(currentStatus)) {
    return currentStatus;
  }

  // Honorary members are always active
  if (membershipType === 'honorary') {
    return 'Active';
  }

  // No renewal date means dormant
  if (!dateRenewed) {
    return 'Dormant';
  }

  const renewalDate = new Date(dateRenewed);
  if (!isValid(renewalDate)) {
    return 'Dormant';
  }

  const monthsSinceRenewal = differenceInMonths(new Date(), renewalDate);
  return monthsSinceRenewal >= 12 ? 'Dormant' : 'Active';
}