import { supabase } from './supabase';
import { getPendingChanges, clearPendingChanges, saveMember } from './offlineStorage';
import { logger } from './logger';
import toast from 'react-hot-toast';

let isSyncing = false;

export async function syncData() {
  if (isSyncing) {
    logger.debug('Sync already in progress');
    return;
  }

  try {
    isSyncing = true;
    logger.info('Starting data sync...');

    const pendingChanges = await getPendingChanges();
    if (!pendingChanges.length) {
      logger.debug('No pending changes to sync');
      return;
    }

    // Sort changes by timestamp
    const sortedChanges = pendingChanges.sort((a, b) => a.timestamp - b.timestamp);

    for (const change of sortedChanges) {
      try {
        switch (change.type) {
          case 'create':
          case 'update':
            const { error: upsertError } = await supabase
              .from(change.table)
              .upsert(change.data);

            if (upsertError) throw upsertError;
            break;

          case 'delete':
            const { error: deleteError } = await supabase
              .from(change.table)
              .delete()
              .eq('id', change.data.id);

            if (deleteError) throw deleteError;
            break;
        }
      } catch (error) {
        logger.error(`Error syncing change:`, error);
        toast.error('Error syncing some changes');
      }
    }

    // Get latest data from server
    const { data: members, error: fetchError } = await supabase
      .from('members')
      .select('*');

    if (fetchError) throw fetchError;

    // Update local storage with latest data
    for (const member of members) {
      await saveMember(member);
    }

    await clearPendingChanges();
    logger.info('Data sync completed successfully');
    toast.success('Data synced successfully');
  } catch (error) {
    logger.error('Error during sync:', error);
    toast.error('Error syncing data');
  } finally {
    isSyncing = false;
  }
}

// Listen for online/offline events
if (typeof window !== 'undefined') {
  window.addEventListener('online', () => {
    logger.info('Connection restored, starting sync...');
    syncData();
  });

  window.addEventListener('offline', () => {
    logger.warn('Connection lost, switching to offline mode');
    toast.warning('Working offline - changes will sync when connection is restored');
  });
}