import { z } from 'zod';

export type MembershipType = 'annual' | 'honorary';

export type MemberStatus = 'Active' | 'Dormant' | 'Resigned' | 'Naughty' | 'Banned';

export type PNAType = 'GNA' | 'KZNNA' | 'WPNA' | 'NWNA' | 'IMNA' | 'SANYA' | 'FSNA' | 'NCNA' | 'LNA' | 'MPNA' | 'ECNA' | 'WCNA';

export interface MemberNote {
  id: string;
  member_id: string;
  note: string;
  created_at: string;
  created_by: string;
  effective_date: string;
}

export interface MemberStory {
  id: string;
  member_id: string;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
}

export interface GalleryPhoto {
  id: string;
  member_id: string;
  photo_url: string;
  caption?: string;
  created_at: string;
}

export interface Member {
  id: string;
  inf_stamp_number?: string;
  inf_registration_link?: string;
  first_name: string;
  surname: string;
  telephone?: string;
  town?: string;
  suburb?: string;
  email?: string;
  join_date: string;
  expiry_date?: string;
  membership_type: MembershipType;
  pna: PNAType;
  last_payment_date?: string;
  notes?: string;
  status: MemberStatus;
  created_at: string;
  updated_at: string;
  date_renewed?: string;
  photo_url?: string;
  id_document_url?: string;
  amount_paid: number;
  outstanding_balance: number;
  renewal_amount: number;
  role?: string;
  email_verified?: boolean;
  activation_token?: string;
  activation_token_expires_at?: string;
  last_synced?: string;
}

// Validation schema for member data
export const memberSchema = z.object({
  inf_stamp_number: z.string().optional(),
  first_name: z.string().min(1, 'First name is required'),
  surname: z.string().min(1, 'Surname is required'),
  telephone: z.string().optional(),
  town: z.string().optional(),
  suburb: z.string().optional(),
  email: z.string().email().optional(),
  join_date: z.string().min(1, 'Join date is required'),
  membership_type: z.enum(['annual', 'honorary']),
  pna: z.enum(['GNA', 'KZNNA', 'WPNA', 'NWNA', 'IMNA', 'SANYA', 'FSNA', 'NCNA', 'LNA', 'MPNA', 'ECNA', 'WCNA']),
  status: z.enum(['Active', 'Dormant', 'Resigned', 'Naughty', 'Banned']),
  date_renewed: z.string().optional(),
  inf_registration_link: z.string().url().optional().or(z.literal('')),
  notes: z.string().min(50).optional().or(z.literal('')),
});