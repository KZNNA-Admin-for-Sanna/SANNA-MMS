import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    target: 'esnext',
    minify: 'esbuild',
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom'],
          'supabase': ['@supabase/supabase-js'],
          'ui': ['react-hot-toast', 'lucide-react'],
          'utils': ['date-fns', 'zod']
        }
      }
    }
  },
  optimizeDeps: {
    include: ['@supabase/supabase-js', 'date-fns', 'lucide-react', 'react-hot-toast']
  },
  server: {
    headers: {
      'Cache-Control': 'public, max-age=31536000'
    }
  },
  preview: {
    port: 4173,
    host: true // Allow external access
  }
});