/*
  # Fix Admin Policies Recursion

  1. Changes
    - Drop all existing admin policies
    - Create new non-recursive policies using direct checks
    - Add security function for admin verification
    - Simplify policy logic to prevent recursion
  
  2. Security
    - Maintain secure access control
    - Prevent unauthorized access
    - Allow first admin creation
*/

-- Create a security definer function to check admin status
CREATE OR REPLACE FUNCTION check_is_admin(user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM admin_users
    WHERE id = user_id
    AND is_active = true
  );
$$;

-- Drop existing policies
DROP POLICY IF EXISTS "admin_users_select_self" ON admin_users;
DROP POLICY IF EXISTS "admin_users_select_admin" ON admin_users;
DROP POLICY IF EXISTS "admin_users_insert_first" ON admin_users;
DROP POLICY IF EXISTS "admin_users_insert_admin" ON admin_users;
DROP POLICY IF EXISTS "admin_users_update_admin" ON admin_users;
DROP POLICY IF EXISTS "admin_users_delete_admin" ON admin_users;

-- Create new simplified policies
CREATE POLICY "enable_self_read"
ON admin_users
FOR SELECT
TO authenticated
USING (id = auth.uid());

CREATE POLICY "enable_admin_read"
ON admin_users
FOR SELECT
TO authenticated
USING (check_is_admin(auth.uid()));

CREATE POLICY "enable_first_admin"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  NOT EXISTS (
    SELECT 1 FROM admin_users
  )
);

CREATE POLICY "enable_admin_insert"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (check_is_admin(auth.uid()));

CREATE POLICY "enable_admin_update"
ON admin_users
FOR UPDATE
TO authenticated
USING (check_is_admin(auth.uid()));

CREATE POLICY "enable_admin_delete"
ON admin_users
FOR DELETE
TO authenticated
USING (check_is_admin(auth.uid()));

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION check_is_admin TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON admin_users TO authenticated;
GRANT SELECT, INSERT ON admin_audit_logs TO authenticated;