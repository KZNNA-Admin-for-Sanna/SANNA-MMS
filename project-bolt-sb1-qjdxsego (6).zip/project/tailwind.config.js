/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brown: {
          50: '#fdf8f6',
          100: '#f2e8e5',
          200: '#eaddd7',
          300: '#e0cec7',
          400: '#d2bab0',
          500: '#bfa094',
          600: '#a18072',
          700: '#977669',
          800: '#846358',
          900: '#43302b',
        },
        light: {
          base: '#ffffff',
          surface: '#ffffff',
          secondary: '#f3f4f6',
          elevated: '#e5e7eb',
          'text-primary': '#111827',
          'text-secondary': '#6b7280',
          'action-primary': '#2563eb',
          'action-secondary': '#f59e0b',
          'action-error': '#dc2626',
          'action-link': '#3b82f6',
          'action-purple': '#9333ea',
          'action-orange': '#ea580c',
          'action-gold': '#b45309'
        }
      },
      boxShadow: {
        'light-sm': '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
        'light-md': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'light-lg': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)'
      }
    }
  },
  plugins: [],
};