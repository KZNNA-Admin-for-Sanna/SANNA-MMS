-- Remove email verification columns and triggers
ALTER TABLE members
  DROP COLUMN IF EXISTS email_verified,
  DROP COLUMN IF EXISTS activation_token,
  DROP COLUMN IF EXISTS activation_token_expires_at;

-- Drop related functions and triggers
DROP TRIGGER IF EXISTS generate_member_activation_token ON members;
DROP FUNCTION IF EXISTS generate_activation_token();
DROP FUNCTION IF EXISTS verify_member_email();
DROP TRIGGER IF EXISTS on_email_verification ON auth.users;
DROP FUNCTION IF EXISTS handle_email_verification();