/*
  # Fix Auth User Creation and Member Linking

  1. Changes
    - Add trigger to handle auth user creation
    - Add function to validate and link members
    - Add constraints for auth user linking
  
  2. Security
    - Ensure proper member validation
    - Prevent duplicate registrations
*/

-- Create function to validate and link member
CREATE OR REPLACE FUNCTION handle_auth_user_created()
RETURNS TRIGGER AS $$
DECLARE
  matching_member_id uuid;
BEGIN
  -- Find matching member by email
  SELECT id INTO matching_member_id
  FROM members
  WHERE 
    email = NEW.email 
    AND status = 'Active'
    AND auth_user_id IS NULL;

  -- If matching member found, link them
  IF matching_member_id IS NOT NULL THEN
    UPDATE members
    SET 
      auth_user_id = NEW.id,
      updated_at = now()
    WHERE id = matching_member_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for auth user creation
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_auth_user_created();

-- Add index for faster member lookups
CREATE INDEX IF NOT EXISTS idx_members_email_status 
ON members(email, status) 
WHERE auth_user_id IS NULL;