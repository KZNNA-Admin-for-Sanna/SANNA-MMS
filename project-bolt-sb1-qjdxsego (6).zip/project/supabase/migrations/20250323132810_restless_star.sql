/*
  # Update Email Settings

  1. Changes
    - Update SMTP password in email_settings table
    - Ensure email is sent from marketing@kznna.org.za
  
  2. Security
    - Store SMTP password securely
    - Maintain existing RLS policies
*/

-- Update email settings with the correct SMTP password
UPDATE email_settings
SET 
  smtp_password = 'KZMkt##2023*',
  smtp_user = 'marketing@kznna.org.za',
  from_email = 'marketing@kznna.org.za',
  from_name = 'SANNA Member Management',
  updated_at = now()
WHERE id = (
  SELECT id 
  FROM email_settings 
  LIMIT 1
);

-- If no settings exist, insert them
INSERT INTO email_settings (
  smtp_host,
  smtp_port,
  smtp_user,
  smtp_password,
  from_email,
  from_name
)
SELECT
  'smtp.gmail.com',
  587,
  'marketing@kznna.org.za',
  'KZMkt##2023*',
  'marketing@kznna.org.za',
  'SANNA Member Management'
WHERE NOT EXISTS (
  SELECT 1 FROM email_settings
);