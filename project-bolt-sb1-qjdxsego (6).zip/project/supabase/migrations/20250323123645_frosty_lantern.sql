/*
  # Fix Telephone Numbers Format

  1. Changes
    - Update existing telephone numbers to start with '0'
    - Add validation trigger for future telephone numbers
    - Add function to validate telephone number format
  
  2. Notes
    - Removes any non-digit characters from phone numbers
    - Ensures numbers start with '0'
    - Allows null values for telephone field
*/

-- Create function to clean and validate telephone numbers
CREATE OR REPLACE FUNCTION clean_telephone_number(phone text)
RETURNS text AS $$
DECLARE
  cleaned text;
BEGIN
  IF phone IS NULL THEN
    RETURN NULL;
  END IF;

  -- Remove all non-digit characters
  cleaned := regexp_replace(phone, '[^0-9]', '', 'g');
  
  -- If empty after cleaning, return null
  IF cleaned = '' THEN
    RETURN NULL;
  END IF;
  
  -- Add leading 0 if missing
  IF LEFT(cleaned, 1) != '0' THEN
    cleaned := '0' || cleaned;
  END IF;
  
  RETURN cleaned;
END;
$$ LANGUAGE plpgsql;

-- Update existing telephone numbers
UPDATE members
SET telephone = clean_telephone_number(telephone)
WHERE telephone IS NOT NULL;

-- Create trigger function to validate telephone numbers
CREATE OR REPLACE FUNCTION validate_telephone_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.telephone IS NOT NULL THEN
    -- Clean and validate the number
    NEW.telephone := clean_telephone_number(NEW.telephone);
    
    -- Ensure it starts with 0
    IF LEFT(NEW.telephone, 1) != '0' THEN
      RAISE EXCEPTION 'Telephone number must start with 0';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for telephone number validation
CREATE TRIGGER validate_telephone_number_trigger
  BEFORE INSERT OR UPDATE OF telephone
  ON members
  FOR EACH ROW
  EXECUTE FUNCTION validate_telephone_number();