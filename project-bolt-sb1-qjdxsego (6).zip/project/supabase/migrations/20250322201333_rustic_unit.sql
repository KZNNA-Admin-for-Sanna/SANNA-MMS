/*
  # Fix Admin User Policies and Function

  1. Changes
    - Drop function with CASCADE to handle dependencies
    - Recreate has_admin_users function with proper security context
    - Create new non-recursive policies
  
  2. Security
    - Maintain strict access control
    - Allow first admin creation
    - Prevent policy recursion
*/

-- Drop function with CASCADE to handle dependencies
DROP FUNCTION IF EXISTS public.has_admin_users() CASCADE;

-- Create simplified policies first
CREATE POLICY "Enable read for self and admins"
ON admin_users
FOR SELECT
TO authenticated
USING (
  id = auth.uid() OR
  EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid() AND is_active = true
  )
);

CREATE POLICY "Enable first admin creation"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  NOT EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE is_active = true
  )
);

CREATE POLICY "Enable admin creation by admins"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid() AND is_active = true
  )
);

CREATE POLICY "Enable update by admins"
ON admin_users
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid() AND is_active = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid() AND is_active = true
  )
);

-- Recreate the function last
CREATE OR REPLACE FUNCTION public.has_admin_users()
RETURNS boolean
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE is_active = true 
    LIMIT 1
  );
END;
$$;