/*
  # Add Admin User Management

  1. New Tables
    - `admin_users`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `is_active` (boolean)
      - `requires_password_change` (boolean)
      - `created_at` (timestamp)
      - `created_by` (uuid)
      - `last_login` (timestamp)

    - `admin_audit_logs`
      - `id` (uuid, primary key)
      - `action` (text)
      - `admin_id` (uuid)
      - `target_admin_id` (uuid)
      - `details` (jsonb)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for admin access
    - Add email validation check
*/

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
  is_active boolean DEFAULT true,
  requires_password_change boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id),
  last_login timestamptz,
  CONSTRAINT valid_email CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

-- Create admin_audit_logs table
CREATE TABLE IF NOT EXISTS admin_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action text NOT NULL,
  admin_id uuid REFERENCES auth.users(id),
  target_admin_id uuid REFERENCES admin_users(id),
  details jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_audit_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for admin_users
CREATE POLICY "Allow admin users to read admin_users"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.id = auth.uid() AND au.is_active = true
  ));

CREATE POLICY "Allow admin users to create admin_users"
  ON admin_users
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.id = auth.uid() AND au.is_active = true
  ));

CREATE POLICY "Allow admin users to update admin_users"
  ON admin_users
  FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.id = auth.uid() AND au.is_active = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.id = auth.uid() AND au.is_active = true
  ));

-- Create policies for admin_audit_logs
CREATE POLICY "Allow admin users to read audit logs"
  ON admin_audit_logs
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.id = auth.uid() AND au.is_active = true
  ));

CREATE POLICY "Allow admin users to create audit logs"
  ON admin_audit_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM admin_users au
    WHERE au.id = auth.uid() AND au.is_active = true
  ));

-- Create function to log admin actions
CREATE OR REPLACE FUNCTION log_admin_action()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO admin_audit_logs (action, admin_id, target_admin_id, details)
  VALUES (
    TG_OP,
    auth.uid(),
    NEW.id,
    jsonb_build_object(
      'email', NEW.email,
      'is_active', NEW.is_active,
      'requires_password_change', NEW.requires_password_change
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for admin_users
CREATE TRIGGER log_admin_users_changes
  AFTER INSERT OR UPDATE
  ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION log_admin_action();