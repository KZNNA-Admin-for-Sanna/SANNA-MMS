/*
  # Add INF Registration Link Field

  1. Changes
    - Add inf_registration_link column to members table
    - Add validation for URL format
  
  2. Notes
    - Field is optional
    - Must be a valid URL
*/

ALTER TABLE members
ADD COLUMN IF NOT EXISTS inf_registration_link text;

-- Add URL format validation
ALTER TABLE members
ADD CONSTRAINT inf_registration_link_url_format
CHECK (
  inf_registration_link IS NULL OR
  inf_registration_link ~ '^https?://[^\s/$.?#].[^\s]*$'
);