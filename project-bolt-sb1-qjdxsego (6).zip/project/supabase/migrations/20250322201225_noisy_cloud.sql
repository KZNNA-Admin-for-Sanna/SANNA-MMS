/*
  # Fix Admin User Policies Recursion

  1. Changes
    - Drop existing policies that cause recursion
    - Implement new non-recursive policies
    - Add initial admin user check function
  
  2. Security
    - Maintain strict access control
    - Prevent unauthorized access
    - Allow first admin to be created
*/

-- Create a function to check if there are any admin users
CREATE OR REPLACE FUNCTION public.has_admin_users()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM admin_users LIMIT 1);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access to admin users" ON admin_users;
DROP POLICY IF EXISTS "Enable insert access for admin users" ON admin_users;
DROP POLICY IF EXISTS "Enable update access for admin users" ON admin_users;

-- Create new non-recursive policies
CREATE POLICY "Allow self read and admin read"
ON admin_users
FOR SELECT
TO authenticated
USING (
  id = auth.uid() OR
  auth.uid() IN (SELECT id FROM admin_users WHERE is_active = true)
);

CREATE POLICY "Allow first admin or existing admin to create"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  NOT public.has_admin_users() OR -- Allow first admin to be created
  auth.uid() IN (SELECT id FROM admin_users WHERE is_active = true)
);

CREATE POLICY "Allow admin update"
ON admin_users
FOR UPDATE
TO authenticated
USING (
  auth.uid() IN (SELECT id FROM admin_users WHERE is_active = true)
)
WITH CHECK (
  auth.uid() IN (SELECT id FROM admin_users WHERE is_active = true)
);