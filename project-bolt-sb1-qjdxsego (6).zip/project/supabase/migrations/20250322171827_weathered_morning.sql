/*
  # Add member status tracking and notes system

  1. Changes
    - Update member status types
    - Add notes history table
    - Add constraints and validations
    - Add triggers for note history

  2. New Tables
    - `member_notes`
      - `id` (uuid, primary key)
      - `member_id` (uuid, foreign key)
      - `note` (text)
      - `created_at` (timestamp)
      - `created_by` (uuid)
      - `effective_date` (date)

  3. Security
    - Enable RLS on new tables
    - Add policies for authenticated users
*/

-- First, update the status type
ALTER TABLE members 
  ALTER COLUMN status TYPE text;

-- Add note validation function
CREATE OR REPLACE FUNCTION validate_member_status_note()
RETURNS TRIGGER AS $$
BEGIN
  -- Check if status is Resigned or Banned
  IF NEW.status IN ('Resigned', 'Banned') THEN
    -- Verify note exists and meets minimum length
    IF NOT EXISTS (
      SELECT 1 FROM member_notes 
      WHERE member_id = NEW.id 
      AND created_at = (SELECT MAX(created_at) FROM member_notes WHERE member_id = NEW.id)
      AND char_length(note) >= 100
    ) THEN
      RAISE EXCEPTION 'Status change to % requires a detailed note of at least 100 characters', NEW.status;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create member_notes table
CREATE TABLE IF NOT EXISTS member_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id uuid REFERENCES members(id) ON DELETE CASCADE,
  note text NOT NULL CHECK (char_length(note) >= 20),
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id),
  effective_date date NOT NULL,
  CONSTRAINT note_length_check CHECK (char_length(note) >= 20)
);

-- Add trigger for status changes
CREATE TRIGGER validate_status_change
  BEFORE UPDATE OF status ON members
  FOR EACH ROW
  WHEN (OLD.status IS DISTINCT FROM NEW.status)
  EXECUTE FUNCTION validate_member_status_note();

-- Enable RLS on member_notes
ALTER TABLE member_notes ENABLE ROW LEVEL SECURITY;

-- Create policies for member_notes
CREATE POLICY "Enable read access for authenticated users"
  ON member_notes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable insert access for authenticated users"
  ON member_notes FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Update existing status values
UPDATE members
SET status = 'Active'
WHERE status NOT IN ('Active', 'Inactive', 'Resigned', 'Banned');