/*
  # Add Member Relationships Support

  1. New Tables
    - `member_relationships`
      - `id` (uuid, primary key)
      - `member_id` (uuid, references members)
      - `partner_id` (uuid, references members)
      - `relationship_type` (enum: spouse, partner)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Changes
    - Add relationship_status to members table
    - Add constraints to ensure valid relationships
    - Add triggers to maintain relationship consistency

  3. Security
    - Enable RLS on new table
    - Add policies for relationship management
*/

-- Create relationship type enum
CREATE TYPE relationship_type AS ENUM ('spouse', 'partner');

-- Create relationship status type
CREATE TYPE relationship_status AS ENUM ('single', 'coupled');

-- Add relationship status to members
ALTER TABLE members
ADD COLUMN relationship_status relationship_status DEFAULT 'single';

-- Create member relationships table
CREATE TABLE member_relationships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id uuid NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  partner_id uuid NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  relationship_type relationship_type NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),

  -- Ensure member can't be partnered with themselves
  CONSTRAINT different_members CHECK (member_id != partner_id),
  
  -- Ensure unique relationships
  UNIQUE(member_id, partner_id),
  
  -- Ensure no duplicate partnerships
  CONSTRAINT one_partner_only UNIQUE (member_id),
  CONSTRAINT one_partner_only_reverse UNIQUE (partner_id)
);

-- Enable RLS
ALTER TABLE member_relationships ENABLE ROW LEVEL SECURITY;

-- Create function to update relationship status
CREATE OR REPLACE FUNCTION update_member_relationship_status()
RETURNS TRIGGER AS $$
BEGIN
  -- For new relationships
  IF TG_OP = 'INSERT' THEN
    UPDATE members 
    SET relationship_status = 'coupled'
    WHERE id IN (NEW.member_id, NEW.partner_id);
  
  -- For deleted relationships
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE members 
    SET relationship_status = 'single'
    WHERE id IN (OLD.member_id, OLD.partner_id)
    AND NOT EXISTS (
      SELECT 1 FROM member_relationships
      WHERE member_id = members.id OR partner_id = members.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for relationship status updates
CREATE TRIGGER update_relationship_status_on_insert
  AFTER INSERT ON member_relationships
  FOR EACH ROW
  EXECUTE FUNCTION update_member_relationship_status();

CREATE TRIGGER update_relationship_status_on_delete
  AFTER DELETE ON member_relationships
  FOR EACH ROW
  EXECUTE FUNCTION update_member_relationship_status();

-- Create function to validate relationship creation
CREATE OR REPLACE FUNCTION validate_relationship()
RETURNS TRIGGER AS $$
BEGIN
  -- Check if both members are active
  IF NOT EXISTS (
    SELECT 1 FROM members 
    WHERE id IN (NEW.member_id, NEW.partner_id)
    AND status = 'Active'
    AND relationship_status = 'single'
  ) THEN
    RAISE EXCEPTION 'Both members must be active and single to create a relationship';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for relationship validation
CREATE TRIGGER validate_relationship_before_insert
  BEFORE INSERT ON member_relationships
  FOR EACH ROW
  EXECUTE FUNCTION validate_relationship();

-- Create policies
CREATE POLICY "Enable read access for authenticated users"
  ON member_relationships FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable relationship management for authenticated users"
  ON member_relationships FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);