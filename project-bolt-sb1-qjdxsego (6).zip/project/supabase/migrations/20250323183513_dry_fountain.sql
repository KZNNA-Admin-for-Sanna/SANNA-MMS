/*
  # Fix Auth Trigger and Permissions

  1. Changes
    - Drop and recreate auth trigger with better error handling
    - Add proper transaction handling
    - Fix permission issues
  
  2. Security
    - Maintain proper auth flow
    - Ensure data consistency
*/

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_auth_user_created();

-- Create improved function to handle auth user creation
CREATE OR REPLACE FUNCTION handle_auth_user_created()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  v_member_id uuid;
BEGIN
  -- Start transaction
  BEGIN
    -- Get member_id from metadata if present
    IF NEW.raw_user_meta_data->>'member_id' IS NOT NULL THEN
      v_member_id := (NEW.raw_user_meta_data->>'member_id')::uuid;
      
      -- Update member record
      UPDATE members
      SET 
        auth_user_id = NEW.id,
        updated_at = now()
      WHERE 
        id = v_member_id
        AND auth_user_id IS NULL;
        
      -- Return early if successful
      RETURN NEW;
    END IF;

    -- If no member_id in metadata, try to find by email
    UPDATE members
    SET 
      auth_user_id = NEW.id,
      updated_at = now()
    WHERE 
      email = NEW.email
      AND status = 'Active'
      AND auth_user_id IS NULL;

    RETURN NEW;
  EXCEPTION WHEN OTHERS THEN
    -- Log error but don't fail the transaction
    RAISE WARNING 'Error in handle_auth_user_created: %', SQLERRM;
    RETURN NEW;
  END;
END;
$$;

-- Create new trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_auth_user_created();

-- Reset and regrant permissions
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon, authenticated;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM anon, authenticated;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon, authenticated;

-- Grant proper permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- Grant table permissions
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON members TO authenticated;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;

-- Grant function permissions
GRANT EXECUTE ON FUNCTION handle_auth_user_created TO anon, authenticated, service_role;