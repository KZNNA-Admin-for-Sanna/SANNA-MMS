/*
  # Add Member Registration Validation

  1. Changes
    - Add function to validate member registration details
    - Add trigger to ensure registration details match member record
    - Add constraints for email, phone, and INF number matching
  
  2. Notes
    - Validates that registration details match existing member record
    - Prevents registration with mismatched information
*/

-- Create function to validate member registration details
CREATE OR REPLACE FUNCTION validate_member_registration()
RETURNS TRIGGER AS $$
DECLARE
  matching_member RECORD;
BEGIN
  -- Find matching member record
  SELECT *
  INTO matching_member
  FROM members
  WHERE 
    (NEW.email IS NOT NULL AND email = NEW.email) OR
    (NEW.raw_user_meta_data->>'inf_stamp_number' IS NOT NULL AND inf_stamp_number = NEW.raw_user_meta_data->>'inf_stamp_number');

  -- If no matching member found
  IF matching_member IS NULL THEN
    RAISE EXCEPTION 'No matching member record found. Please contact your PNA administrator.';
  END IF;

  -- Validate email matches
  IF matching_member.email IS NOT NULL AND matching_member.email != NEW.email THEN
    RAISE EXCEPTION 'Email address does not match member record';
  END IF;

  -- Validate INF number matches
  IF matching_member.inf_stamp_number IS NOT NULL AND 
     NEW.raw_user_meta_data->>'inf_stamp_number' IS NOT NULL AND
     matching_member.inf_stamp_number != NEW.raw_user_meta_data->>'inf_stamp_number' THEN
    RAISE EXCEPTION 'INF number does not match member record';
  END IF;

  -- Update member record with auth user ID
  UPDATE members
  SET 
    auth_user_id = NEW.id,
    updated_at = now()
  WHERE id = matching_member.id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add auth_user_id column to members table
ALTER TABLE members
ADD COLUMN IF NOT EXISTS auth_user_id uuid REFERENCES auth.users(id);

-- Create trigger for member registration validation
DROP TRIGGER IF EXISTS validate_member_registration_trigger ON auth.users;
CREATE TRIGGER validate_member_registration_trigger
  AFTER INSERT
  ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION validate_member_registration();

-- Update existing auth_user_id values
UPDATE members m
SET auth_user_id = u.id
FROM auth.users u
WHERE m.email = u.email
AND m.auth_user_id IS NULL;