/*
  # Update Membership Types and Payment Structure

  1. Changes
    - Add 'honorary' to membership types
    - Remove payment tracking columns for simplification
    - Add honorary_member flag
  
  2. Notes
    - Honorary members are exempt from fees
    - Annual members have yearly renewals
    - Lifetime members remain unchanged
*/

-- Update membership type enum
ALTER TYPE membership_type RENAME TO membership_type_old;
CREATE TYPE membership_type AS ENUM ('annual', 'lifetime', 'honorary');

-- Update the column type
ALTER TABLE members 
  ALTER COLUMN membership_type TYPE membership_type 
  USING (
    CASE 
      WHEN membership_type::text = 'monthly' THEN 'annual'
      ELSE membership_type::text
    END
  )::membership_type;

-- Drop the old type
DROP TYPE membership_type_old;

-- Remove payment-related columns
ALTER TABLE members 
  DROP COLUMN IF EXISTS amount_paid,
  DROP COLUMN IF EXISTS outstanding_balance,
  DROP COLUMN IF EXISTS renewal_amount;