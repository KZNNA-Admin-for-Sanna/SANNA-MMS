/*
  # Add Date Renewal Validation

  1. Changes
    - Add trigger to validate date renewal
    - Update member payment totals function
    - Add constraints for date validation
  
  2. Notes
    - Renewal date must be after join date
    - Honorary members are exempt from date renewal
*/

-- Create function to validate renewal date
CREATE OR REPLACE FUNCTION validate_renewal_date()
RETURNS TRIGGER AS $$
BEGIN
  -- Only validate for annual members
  IF NEW.membership_type = 'annual' THEN
    -- Ensure renewal date is after join date if both are set
    IF NEW.date_renewed IS NOT NULL AND NEW.join_date IS NOT NULL THEN
      IF NEW.date_renewed < NEW.join_date THEN
        RAISE EXCEPTION 'Renewal date cannot be before join date';
      END IF;
    END IF;

    -- Set status based on renewal date
    IF NEW.date_renewed IS NULL THEN
      NEW.status := 'Dormant';
    ELSIF NEW.status = 'Dormant' THEN
      NEW.status := 'Active';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for renewal date validation
CREATE TRIGGER validate_renewal_date_trigger
  BEFORE INSERT OR UPDATE OF date_renewed, join_date, membership_type
  ON members
  FOR EACH ROW
  EXECUTE FUNCTION validate_renewal_date();

-- Update the member payment totals function
CREATE OR REPLACE FUNCTION update_member_payment_totals()
RETURNS TRIGGER AS $$
BEGIN
  -- Only update payment fields for non-honorary members
  IF NEW.membership_type != 'honorary' THEN
    -- Get current year's fee
    NEW.renewal_amount := get_current_membership_fee();
    
    -- For active and dormant members, use current year's rate
    IF NEW.status IN ('Active', 'Dormant') THEN
      -- If this is a new member or first renewal
      IF OLD IS NULL OR OLD.amount_paid = 0 THEN
        NEW.amount_paid := NEW.renewal_amount;
        NEW.outstanding_balance := 0;
      END IF;
    END IF;
  ELSE
    -- Honorary members don't pay fees
    NEW.renewal_amount := 0;
    NEW.outstanding_balance := 0;
    -- Honorary members don't need renewal dates
    NEW.date_renewed := NULL;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;