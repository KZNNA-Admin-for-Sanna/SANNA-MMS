/*
  # Make INF Numbers Optional

  1. Changes
    - Make inf_stamp_number column nullable
    - Update unique constraint to only apply when inf_stamp_number is not null
    - Update validation function to handle optional INF numbers
  
  2. Notes
    - Existing records will maintain their INF numbers
    - Uniqueness is only enforced for active members with INF numbers
    - Validation still applies when INF numbers are provided
*/

-- Make INF stamp number optional
ALTER TABLE members
  ALTER COLUMN inf_stamp_number DROP NOT NULL;

-- Drop the unique constraint on inf_stamp_number
DROP INDEX IF EXISTS members_active_inf_stamp_number_key;

-- Create a new partial unique index that only applies when inf_stamp_number is not null
CREATE UNIQUE INDEX members_active_inf_stamp_number_key 
ON members(inf_stamp_number) 
WHERE status = 'Active' AND inf_stamp_number IS NOT NULL;

-- Update the validation function to handle optional INF numbers
CREATE OR REPLACE FUNCTION validate_inf_stamp_number()
RETURNS TRIGGER AS $$
BEGIN
  -- Only check uniqueness for active members with INF numbers
  IF NEW.status = 'Active' AND NEW.inf_stamp_number IS NOT NULL THEN
    IF EXISTS (
      SELECT 1 
      FROM members 
      WHERE inf_stamp_number = NEW.inf_stamp_number 
      AND id != NEW.id 
      AND status = 'Active'
      AND inf_stamp_number IS NOT NULL
    ) THEN
      RAISE EXCEPTION 'INF stamp number % is already in use by an active member', NEW.inf_stamp_number;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;