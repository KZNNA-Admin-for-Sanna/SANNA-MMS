/*
  # Update Registered Users Schema

  1. Changes
    - Add auth_user_id column to members table
    - Add foreign key constraint to auth.users
    - Add index for faster lookups
    - Add trigger to handle user registration
    - Remove old auth-related columns
  
  2. Security
    - Maintain link between members and auth users
    - Ensure data consistency
*/

-- Add auth_user_id column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'members' AND column_name = 'auth_user_id'
  ) THEN
    ALTER TABLE members 
    ADD COLUMN auth_user_id uuid REFERENCES auth.users(id);
  END IF;
END $$;

-- Remove old auth-related columns
ALTER TABLE members
  DROP COLUMN IF EXISTS email_verified,
  DROP COLUMN IF EXISTS activation_token,
  DROP COLUMN IF EXISTS activation_token_expires_at;

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_members_auth_user 
ON members(auth_user_id) 
WHERE auth_user_id IS NOT NULL;

-- Create index for email lookups
CREATE INDEX IF NOT EXISTS idx_members_email_status 
ON members(email, status) 
WHERE auth_user_id IS NULL;

-- Create function to handle user registration
CREATE OR REPLACE FUNCTION handle_auth_user_created()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  matching_member RECORD;
BEGIN
  -- Find matching member with detailed info
  SELECT *
  INTO matching_member
  FROM members
  WHERE 
    email = NEW.email 
    AND status = 'Active'
    AND auth_user_id IS NULL;

  -- If matching member found, link them
  IF matching_member IS NOT NULL THEN
    UPDATE members
    SET 
      auth_user_id = NEW.id,
      updated_at = now()
    WHERE id = matching_member.id;

    -- Update auth user metadata
    UPDATE auth.users
    SET 
      raw_user_meta_data = jsonb_build_object(
        'member_id', matching_member.id,
        'first_name', matching_member.first_name,
        'last_name', matching_member.surname,
        'inf_number', matching_member.inf_stamp_number
      ),
      updated_at = now()
    WHERE id = NEW.id;
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger for auth user creation
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_auth_user_created();

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO postgres, anon, authenticated, service_role;
GRANT ALL ON ALL TABLES IN SCHEMA public TO postgres, anon, authenticated, service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO postgres, anon, authenticated, service_role;
GRANT ALL ON ALL FUNCTIONS IN SCHEMA public TO postgres, anon, authenticated, service_role;