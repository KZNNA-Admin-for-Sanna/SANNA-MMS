/*
  # Add Payment Tracking Fields

  1. Changes
    - Add amount_paid column to members table
    - Add outstanding_balance column to members table
    - Add renewal_amount column to members table
  
  2. Notes
    - All amounts use numeric(10,2) for precise currency handling
    - Default values set to 0 for new records
*/

-- Add payment tracking columns
ALTER TABLE members
  ADD COLUMN IF NOT EXISTS amount_paid numeric(10,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS outstanding_balance numeric(10,2) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS renewal_amount numeric(10,2) DEFAULT 0;

-- Update existing records to have 0 instead of null
UPDATE members 
SET 
  amount_paid = COALESCE(amount_paid, 0),
  outstanding_balance = COALESCE(outstanding_balance, 0),
  renewal_amount = COALESCE(renewal_amount, 0);

-- Set NOT NULL constraints after updating
ALTER TABLE members
  ALTER COLUMN amount_paid SET NOT NULL,
  ALTER COLUMN outstanding_balance SET NOT NULL,
  ALTER COLUMN renewal_amount SET NOT NULL;