/*
  # Add Dormant Status Logic

  1. Changes
    - Update member payment totals function to handle dormant status
    - Set member status to dormant when renewal date is not set
    - Add validation for status changes
  
  2. Notes
    - Only applies to annual members
    - Honorary members are exempt
*/

-- Update the function to handle dormant status
CREATE OR REPLACE FUNCTION update_member_payment_totals()
RETURNS TRIGGER AS $$
BEGIN
  -- Only update payment fields for non-honorary members
  IF NEW.membership_type != 'honorary' THEN
    -- Get current year's fee
    NEW.renewal_amount := get_current_membership_fee();
    
    -- Set status based on renewal date
    IF NEW.membership_type = 'annual' THEN
      IF NEW.date_renewed IS NULL THEN
        NEW.status := 'Dormant';
      ELSIF NEW.status = 'Dormant' AND NEW.date_renewed IS NOT NULL THEN
        NEW.status := 'Active';
      END IF;
    END IF;

    -- For active and dormant members, use current year's rate
    IF NEW.status IN ('Active', 'Dormant') THEN
      -- If this is a new member or first renewal
      IF OLD IS NULL OR OLD.amount_paid = 0 THEN
        NEW.amount_paid := NEW.renewal_amount;
        NEW.outstanding_balance := 0;
      END IF;
    END IF;
  ELSE
    -- Honorary members don't pay fees
    NEW.renewal_amount := 0;
    NEW.outstanding_balance := 0;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;