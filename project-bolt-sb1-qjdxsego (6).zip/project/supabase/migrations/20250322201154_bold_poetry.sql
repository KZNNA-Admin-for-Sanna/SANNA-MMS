/*
  # Fix Admin User Policies

  1. Changes
    - Remove recursive policies that were causing infinite recursion
    - Add new policies based on auth.uid() directly
    - Simplify policy checks for better performance
  
  2. Security
    - Maintain strict access control
    - Prevent unauthorized access to admin functions
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Allow admin users to read admin_users" ON admin_users;
DROP POLICY IF EXISTS "Allow admin users to create admin_users" ON admin_users;
DROP POLICY IF EXISTS "Allow admin users to update admin_users" ON admin_users;

-- Create new policies without recursion
CREATE POLICY "Enable read access to admin users"
ON admin_users
FOR SELECT
TO authenticated
USING (
  id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE id = auth.uid()
    AND is_active = true
  )
);

CREATE POLICY "Enable insert access for admin users"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE id = auth.uid()
    AND is_active = true
  )
);

CREATE POLICY "Enable update access for admin users"
ON admin_users
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE id = auth.uid()
    AND is_active = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE id = auth.uid()
    AND is_active = true
  )
);