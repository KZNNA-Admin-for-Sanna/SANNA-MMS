/*
  # Fix User Registration

  1. Changes
    - Drop and recreate auth trigger with proper error handling
    - Add proper permissions for auth operations
    - Fix member linking process
  
  2. Security
    - Maintain proper auth flow
    - Ensure data consistency
*/

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_auth_user_created();

-- Create improved function to handle auth user creation
CREATE OR REPLACE FUNCTION handle_auth_user_created()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Update member record if metadata contains member_id
  IF NEW.raw_user_meta_data->>'member_id' IS NOT NULL THEN
    UPDATE members
    SET 
      auth_user_id = NEW.id,
      updated_at = now()
    WHERE 
      id = (NEW.raw_user_meta_data->>'member_id')::uuid
      AND auth_user_id IS NULL;
  END IF;

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log error but don't fail the transaction
  RAISE WARNING 'Error in handle_auth_user_created: %', SQLERRM;
  RETURN NEW;
END;
$$;

-- Create new trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_auth_user_created();

-- Ensure proper permissions
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO service_role;

-- Grant access to necessary tables
GRANT ALL ON members TO authenticated;
GRANT ALL ON members TO anon;
GRANT ALL ON members TO service_role;

-- Grant execute permission on the function
GRANT EXECUTE ON FUNCTION handle_auth_user_created() TO authenticated;
GRANT EXECUTE ON FUNCTION handle_auth_user_created() TO anon;
GRANT EXECUTE ON FUNCTION handle_auth_user_created() TO service_role;