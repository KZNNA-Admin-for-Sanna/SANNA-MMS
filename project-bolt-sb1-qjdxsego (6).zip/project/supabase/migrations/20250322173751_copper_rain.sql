/*
  # Add PNA field to members table

  1. Changes
    - Add PNA (Provincial Netball Association) field to members table
    - Create enum type for PNA values
    - Set default PNA value for existing records
  
  2. Notes
    - PNA is a required field for all members
    - Valid PNA values are predefined provincial associations
*/

-- Create PNA type enum
CREATE TYPE pna_type AS ENUM (
  'GNA',   -- Gauteng Netball Association
  'KZNNA', -- KwaZulu-Natal Netball Association
  'WPNA',  -- Western Province Netball Association
  'NWNA',  -- North West Netball Association
  'IMNA',  -- Ilembe Netball Association
  'SANYA', -- South African Netball Youth Association
  'FSNA',  -- Free State Netball Association
  'NCNA',  -- Northern Cape Netball Association
  'LNA',   -- Limpopo Netball Association
  'MPNA',  -- Mpumalanga Netball Association
  'ECNA',  -- Eastern Cape Netball Association
  'WCNA'   -- Western Cape Netball Association
);

-- Add PNA column to members table
ALTER TABLE members
  ADD COLUMN pna pna_type NOT NULL DEFAULT 'GNA';

-- Remove default constraint after adding the column
ALTER TABLE members
  ALTER COLUMN pna DROP DEFAULT;