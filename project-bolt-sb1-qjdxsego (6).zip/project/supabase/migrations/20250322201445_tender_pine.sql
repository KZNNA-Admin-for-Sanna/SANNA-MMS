/*
  # Fix Admin Policies Recursion - Final Fix

  1. Changes
    - Drop all existing admin policies
    - Create new non-recursive policies using direct conditions
    - Add special case for first admin
    - Simplify policy logic to prevent any possible recursion
  
  2. Security
    - Maintain same security model with better implementation
    - Allow first admin creation without recursion
    - Allow admin management by existing admins
*/

-- Drop all existing policies
DROP POLICY IF EXISTS "admin_users_read" ON admin_users;
DROP POLICY IF EXISTS "admin_users_insert_first" ON admin_users;
DROP POLICY IF EXISTS "admin_users_insert_admin" ON admin_users;
DROP POLICY IF EXISTS "admin_users_update" ON admin_users;
DROP POLICY IF EXISTS "admin_users_delete" ON admin_users;

-- Create new simplified policies
CREATE POLICY "admin_users_select"
ON admin_users
FOR SELECT
TO authenticated
USING (
  CASE 
    WHEN id = auth.uid() THEN true
    WHEN EXISTS (SELECT 1 FROM admin_users WHERE id = auth.uid() LIMIT 1) THEN true
    ELSE false
  END
);

CREATE POLICY "admin_users_insert_first"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  NOT EXISTS (SELECT 1 FROM admin_users LIMIT 1)
);

CREATE POLICY "admin_users_insert"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (SELECT 1 FROM admin_users WHERE id = auth.uid() AND is_active = true LIMIT 1)
);

CREATE POLICY "admin_users_update"
ON admin_users
FOR UPDATE
TO authenticated
USING (
  EXISTS (SELECT 1 FROM admin_users WHERE id = auth.uid() AND is_active = true LIMIT 1)
)
WITH CHECK (
  EXISTS (SELECT 1 FROM admin_users WHERE id = auth.uid() AND is_active = true LIMIT 1)
);

CREATE POLICY "admin_users_delete"
ON admin_users
FOR DELETE
TO authenticated
USING (
  EXISTS (SELECT 1 FROM admin_users WHERE id = auth.uid() AND is_active = true LIMIT 1)
);