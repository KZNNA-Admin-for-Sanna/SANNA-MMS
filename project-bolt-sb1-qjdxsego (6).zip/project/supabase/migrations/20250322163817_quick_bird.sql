/*
  # Remove monthly membership type

  1. Changes
    - Update membership_type enum to remove 'monthly' option
    - Convert any existing monthly memberships to annual

  2. Security
    - No changes to RLS policies required
*/

-- First convert any existing monthly memberships to annual
UPDATE members 
SET membership_type = 'annual'
WHERE membership_type = 'monthly';

-- Then alter the enum type
ALTER TYPE membership_type RENAME TO membership_type_old;
CREATE TYPE membership_type AS ENUM ('annual', 'lifetime');

-- Update the column type
ALTER TABLE members 
  ALTER COLUMN membership_type TYPE membership_type 
  USING membership_type::text::membership_type;

-- Drop the old type
DROP TYPE membership_type_old;