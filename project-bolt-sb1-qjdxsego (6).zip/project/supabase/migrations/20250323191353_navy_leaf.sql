/*
  # Add User Authentication Audit Log

  1. Changes
    - Add audit logging for auth events
    - Add constraints for auth user linking
    - Add indexes for performance
  
  2. Security
    - Maintain audit trail of all auth events
    - Ensure data consistency
*/

-- Create index for auth user lookups
CREATE INDEX IF NOT EXISTS idx_members_auth_user 
ON members(auth_user_id) 
WHERE auth_user_id IS NOT NULL;

-- Create index for email lookups
CREATE INDEX IF NOT EXISTS idx_members_email_status 
ON members(email, status) 
WHERE auth_user_id IS NULL;

-- Add audit logging
CREATE OR REPLACE FUNCTION log_auth_event()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO admin_actions (
    action_type,
    executed_by,
    reason,
    details
  ) VALUES (
    CASE TG_OP
      WHEN 'INSERT' THEN 'user_created'
      WHEN 'UPDATE' THEN 'user_updated'
      WHEN 'DELETE' THEN 'user_deleted'
    END,
    NEW.id,
    'Auth system event',
    jsonb_build_object(
      'email', NEW.email,
      'event_date', now(),
      'operation', TG_OP
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for auth events
DROP TRIGGER IF EXISTS auth_audit_log ON auth.users;
CREATE TRIGGER auth_audit_log
  AFTER INSERT OR UPDATE OR DELETE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION log_auth_event();

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON members TO authenticated;
GRANT ALL ON admin_actions TO authenticated;
GRANT EXECUTE ON FUNCTION log_auth_event TO authenticated;