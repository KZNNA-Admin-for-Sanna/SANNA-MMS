/*
  # Add Membership Fees Table

  1. New Tables
    - `membership_fees`
      - `id` (uuid, primary key)
      - `year` (integer)
      - `amount` (numeric)
      - `created_at` (timestamp)

  2. Notes
    - Each year can only have one fee amount
    - Amount is stored in ZAR (South African Rand)
*/

CREATE TABLE IF NOT EXISTS membership_fees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  year integer NOT NULL,
  amount numeric(10,2) NOT NULL CHECK (amount >= 0),
  created_at timestamptz DEFAULT now(),
  UNIQUE(year)
);

-- Insert initial fee for current year
INSERT INTO membership_fees (year, amount)
VALUES (EXTRACT(YEAR FROM CURRENT_DATE), 330.00)
ON CONFLICT (year) DO NOTHING;

-- Grant access
GRANT ALL ON membership_fees TO PUBLIC;