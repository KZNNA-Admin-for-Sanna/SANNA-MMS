/*
  # Add email templates and email logs

  1. New Tables
    - `email_templates`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `subject` (text)
      - `content` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `email_logs`
      - `id` (uuid, primary key)
      - `template_id` (uuid, references email_templates)
      - `sent_to` (text[])
      - `pna` (pna_type)
      - `sent_at` (timestamp)
      - `sent_by` (uuid, references auth.users)
      - `status` (text)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create email templates table
CREATE TABLE IF NOT EXISTS email_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  subject text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create email logs table
CREATE TABLE IF NOT EXISTS email_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid REFERENCES email_templates(id) ON DELETE SET NULL,
  sent_to text[] NOT NULL,
  pna pna_type NOT NULL,
  sent_at timestamptz DEFAULT now(),
  sent_by uuid REFERENCES auth.users(id),
  status text NOT NULL DEFAULT 'sent'
);

-- Enable RLS
ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_logs ENABLE ROW LEVEL SECURITY;

-- Policies for email_templates
CREATE POLICY "Allow authenticated users to read email templates"
ON email_templates
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Allow authenticated users to create email templates"
ON email_templates
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update email templates"
ON email_templates
FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

-- Policies for email_logs
CREATE POLICY "Allow authenticated users to read email logs"
ON email_logs
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Allow authenticated users to create email logs"
ON email_logs
FOR INSERT
TO authenticated
WITH CHECK (true);