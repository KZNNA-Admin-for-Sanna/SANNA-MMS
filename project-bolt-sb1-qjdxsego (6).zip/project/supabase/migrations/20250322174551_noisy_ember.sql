/*
  # Add photo URL field to members table

  1. Changes
    - Add photo_url column to members table to store the image URL
    - Create storage bucket for member photos
  
  2. Notes
    - photo_url is optional
    - Storage bucket will be used to store member photos
*/

-- Add photo_url column to members table
ALTER TABLE members
ADD COLUMN photo_url text;

-- Enable storage
DO $$
BEGIN
  -- Create storage bucket for member photos if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM storage.buckets WHERE id = 'member-photos'
  ) THEN
    INSERT INTO storage.buckets (id, name)
    VALUES ('member-photos', 'member-photos');
  END IF;
END $$;