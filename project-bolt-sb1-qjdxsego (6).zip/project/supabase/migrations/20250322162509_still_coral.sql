/*
  # Fix Row Level Security Policies

  1. Changes
    - Drop existing policies and create new comprehensive ones
    - Enable RLS on members table
    - Add policies for all CRUD operations
  
  2. Security
    - Only authenticated users can access the members table
    - All authenticated users can perform CRUD operations
*/

-- Enable RLS
ALTER TABLE members ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow authenticated users to read members" ON members;
DROP POLICY IF EXISTS "Allow authenticated users to insert members" ON members;
DROP POLICY IF EXISTS "Allow authenticated users to update members" ON members;
DROP POLICY IF EXISTS "Allow authenticated users to delete members" ON members;

-- Create new policies
CREATE POLICY "Enable read access for authenticated users"
ON members FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Enable insert access for authenticated users"
ON members FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Enable update access for authenticated users"
ON members FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Enable delete access for authenticated users"
ON members FOR DELETE
TO authenticated
USING (true);