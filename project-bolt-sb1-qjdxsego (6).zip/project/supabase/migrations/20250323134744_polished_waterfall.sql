/*
  # Add Email Verification Trigger

  1. Changes
    - Add trigger to update member email_verified status
    - Add function to handle email verification updates
    - Update existing members based on auth status
  
  2. Notes
    - Automatically updates member status when email is verified
    - Syncs with auth.users verification status
*/

-- Create function to handle email verification
CREATE OR REPLACE FUNCTION handle_email_verification()
RETURNS TRIGGER AS $$
BEGIN
  -- Update members table when email is verified
  UPDATE members
  SET 
    email_verified = TRUE,
    updated_at = now()
  WHERE 
    email = NEW.email
    AND (NEW.email_confirmed_at IS NOT NULL OR NEW.confirmed_at IS NOT NULL);

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger on auth.users table
CREATE TRIGGER on_email_verification
  AFTER UPDATE OF email_confirmed_at, confirmed_at
  ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_email_verification();

-- Update existing members based on auth status
UPDATE members m
SET 
  email_verified = TRUE,
  updated_at = now()
FROM auth.users u
WHERE 
  m.email = u.email 
  AND (u.email_confirmed_at IS NOT NULL OR u.confirmed_at IS NOT NULL);