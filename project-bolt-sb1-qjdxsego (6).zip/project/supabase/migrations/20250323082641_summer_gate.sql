/*
  # Reset Member Accounts for Email Activation

  1. Changes
    - Add email_verified column to members table
    - Add activation_token column to members table
    - Add activation_token_expires_at column to members table
    - Reset all existing accounts to require email verification
    - Add trigger to handle email verification updates
  
  2. Security
    - Tokens expire after 24 hours
    - Secure token generation using crypto functions
*/

-- Add new columns for email verification
ALTER TABLE members
  ADD COLUMN IF NOT EXISTS email_verified boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS activation_token uuid,
  ADD COLUMN IF NOT EXISTS activation_token_expires_at timestamptz;

-- Create function to generate new activation token
CREATE OR REPLACE FUNCTION generate_activation_token()
RETURNS TRIGGER AS $$
BEGIN
  -- Only generate new token if email is changed or account is not verified
  IF (TG_OP = 'INSERT') OR 
     (TG_OP = 'UPDATE' AND 
      (OLD.email IS DISTINCT FROM NEW.email OR NOT COALESCE(OLD.email_verified, false))
     ) THEN
    NEW.activation_token := gen_random_uuid();
    NEW.activation_token_expires_at := NOW() + INTERVAL '24 hours';
    NEW.email_verified := false;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for activation token generation
DROP TRIGGER IF EXISTS generate_member_activation_token ON members;
CREATE TRIGGER generate_member_activation_token
  BEFORE INSERT OR UPDATE OF email
  ON members
  FOR EACH ROW
  EXECUTE FUNCTION generate_activation_token();

-- Reset all existing accounts to require verification
UPDATE members
SET 
  email_verified = false,
  activation_token = gen_random_uuid(),
  activation_token_expires_at = NOW() + INTERVAL '24 hours'
WHERE email IS NOT NULL;

-- Create index for faster token lookups
CREATE INDEX IF NOT EXISTS idx_members_activation_token 
ON members(activation_token) 
WHERE activation_token IS NOT NULL;

-- Create function to verify email
CREATE OR REPLACE FUNCTION verify_member_email(token uuid)
RETURNS boolean AS $$
DECLARE
  updated_rows integer;
BEGIN
  UPDATE members
  SET 
    email_verified = true,
    activation_token = NULL,
    activation_token_expires_at = NULL,
    updated_at = NOW()
  WHERE 
    activation_token = token
    AND activation_token_expires_at > NOW()
    AND NOT email_verified;
    
  GET DIAGNOSTICS updated_rows = ROW_COUNT;
  RETURN updated_rows > 0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;