/*
  # Update INF Stamp Number Constraint

  1. Changes
    - Drop existing unique constraint on inf_stamp_number
    - Add partial unique index for active members only
    - Add function to validate INF number uniqueness
    - Add trigger to enforce uniqueness on insert/update
  
  2. Notes
    - Only active members must have unique INF numbers
    - Deleted members' INF numbers can be reused
*/

-- Drop existing unique constraint
ALTER TABLE members 
DROP CONSTRAINT IF EXISTS members_inf_stamp_number_key;

-- Create partial unique index for active members
CREATE UNIQUE INDEX members_active_inf_stamp_number_key 
ON members(inf_stamp_number) 
WHERE status = 'Active';

-- Create function to validate INF number uniqueness
CREATE OR REPLACE FUNCTION validate_inf_stamp_number()
RETURNS TRIGGER AS $$
BEGIN
  -- Only check uniqueness for active members
  IF NEW.status = 'Active' THEN
    IF EXISTS (
      SELECT 1 
      FROM members 
      WHERE inf_stamp_number = NEW.inf_stamp_number 
      AND id != NEW.id 
      AND status = 'Active'
    ) THEN
      RAISE EXCEPTION 'INF stamp number % is already in use by an active member', NEW.inf_stamp_number;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for INF number validation
CREATE TRIGGER validate_inf_stamp_number_trigger
  BEFORE INSERT OR UPDATE OF inf_stamp_number, status
  ON members
  FOR EACH ROW
  EXECUTE FUNCTION validate_inf_stamp_number();