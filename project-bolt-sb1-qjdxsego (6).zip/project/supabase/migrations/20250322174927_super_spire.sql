/*
  # Add RLS policies for members and storage

  1. Security Updates
    - Add RLS policies for members table
    - Add RLS policies for storage bucket
    - Enable public access to member photos

  2. Policies Added
    - Members table:
      - Allow authenticated users to insert their own records
      - Allow authenticated users to update their own records
      - Allow authenticated users to read all records
      - Allow authenticated users to delete their own records
    - Storage bucket:
      - Allow authenticated users to upload files
      - Allow public access to read files
*/

-- Members table policies
CREATE POLICY "Allow authenticated users to insert members"
ON members
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update members"
ON members
FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Allow authenticated users to read members"
ON members
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Allow authenticated users to delete members"
ON members
FOR DELETE
TO authenticated
USING (true);

-- Storage policies
INSERT INTO storage.buckets (id, name, public) 
VALUES ('member-photos', 'member-photos', true)
ON CONFLICT (id) DO UPDATE
SET public = true;

CREATE POLICY "Allow authenticated users to upload member photos"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'member-photos'
);

CREATE POLICY "Allow public access to member photos"
ON storage.objects
FOR SELECT
TO public
USING (
  bucket_id = 'member-photos'
);