/*
  # Fix Admin Policies Recursion - Final Fix V2

  1. Changes
    - Drop all existing policies
    - Create new non-recursive policies using direct conditions
    - Add special case for first admin
    - Simplify policy logic to prevent any possible recursion
    - Use materialized view for caching admin status
  
  2. Security
    - Maintain same security model with better implementation
    - Allow first admin creation without recursion
    - Allow admin management by existing admins
    - Use materialized view to avoid recursive policy checks
*/

-- Create materialized view for active admins
CREATE MATERIALIZED VIEW active_admins AS
SELECT id
FROM admin_users
WHERE is_active = true;

-- Create function to refresh the materialized view
CREATE OR REPLACE FUNCTION refresh_active_admins()
RETURNS TRIGGER AS $$
BEGIN
  REFRESH MATERIALIZED VIEW active_admins;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to refresh the view
CREATE TRIGGER refresh_active_admins_trigger
AFTER INSERT OR UPDATE OR DELETE ON admin_users
FOR EACH STATEMENT
EXECUTE FUNCTION refresh_active_admins();

-- Drop all existing policies
DROP POLICY IF EXISTS "admin_users_select" ON admin_users;
DROP POLICY IF EXISTS "admin_users_insert_first" ON admin_users;
DROP POLICY IF EXISTS "admin_users_insert" ON admin_users;
DROP POLICY IF EXISTS "admin_users_update" ON admin_users;
DROP POLICY IF EXISTS "admin_users_delete" ON admin_users;

-- Create new simplified policies using materialized view
CREATE POLICY "admin_users_select"
ON admin_users
FOR SELECT
TO authenticated
USING (
  id = auth.uid() OR
  auth.uid() IN (SELECT id FROM active_admins)
);

CREATE POLICY "admin_users_insert_first"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  NOT EXISTS (
    SELECT 1 
    FROM active_admins 
    LIMIT 1
  )
);

CREATE POLICY "admin_users_insert"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() IN (SELECT id FROM active_admins)
);

CREATE POLICY "admin_users_update"
ON admin_users
FOR UPDATE
TO authenticated
USING (
  auth.uid() IN (SELECT id FROM active_admins)
)
WITH CHECK (
  auth.uid() IN (SELECT id FROM active_admins)
);

CREATE POLICY "admin_users_delete"
ON admin_users
FOR DELETE
TO authenticated
USING (
  auth.uid() IN (SELECT id FROM active_admins)
);