/*
  # Add Heartbeat Function
  
  1. Changes
    - Add heartbeat function for connection testing
    - Grant execute permission to authenticated users
  
  2. Notes
    - Simple function that returns true
    - Used for API availability checks
*/

CREATE OR REPLACE FUNCTION heartbeat()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN true;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION heartbeat() TO authenticated;