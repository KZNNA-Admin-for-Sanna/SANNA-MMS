/*
  # Fix Admin Policies Recursion

  1. Changes
    - Drop all existing admin policies
    - Create new non-recursive policies using direct queries
    - Remove dependency on has_admin_users function
    - Simplify policy logic to prevent circular references
  
  2. Security
    - Maintain same security model but with better implementation
    - Allow first admin creation without recursion
    - Allow admin management by existing admins
*/

-- Drop all existing policies to start fresh
DROP POLICY IF EXISTS "Enable read for self and admins" ON admin_users;
DROP POLICY IF EXISTS "Enable first admin creation" ON admin_users;
DROP POLICY IF EXISTS "Enable admin creation by admins" ON admin_users;
DROP POLICY IF EXISTS "Enable update by admins" ON admin_users;
DROP POLICY IF EXISTS "Allow self read and admin read" ON admin_users;
DROP POLICY IF EXISTS "Allow first admin or existing admin to create" ON admin_users;
DROP POLICY IF EXISTS "Allow admin update" ON admin_users;

-- Create new simplified policies
CREATE POLICY "admin_users_read"
ON admin_users
FOR SELECT
TO authenticated
USING (
  id = auth.uid() OR
  (SELECT is_active FROM admin_users WHERE id = auth.uid())
);

CREATE POLICY "admin_users_insert_first"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  NOT EXISTS (
    SELECT 1 FROM admin_users
  )
);

CREATE POLICY "admin_users_insert_admin"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  (SELECT is_active FROM admin_users WHERE id = auth.uid())
);

CREATE POLICY "admin_users_update"
ON admin_users
FOR UPDATE
TO authenticated
USING (
  (SELECT is_active FROM admin_users WHERE id = auth.uid())
)
WITH CHECK (
  (SELECT is_active FROM admin_users WHERE id = auth.uid())
);

CREATE POLICY "admin_users_delete"
ON admin_users
FOR DELETE
TO authenticated
USING (
  (SELECT is_active FROM admin_users WHERE id = auth.uid())
);