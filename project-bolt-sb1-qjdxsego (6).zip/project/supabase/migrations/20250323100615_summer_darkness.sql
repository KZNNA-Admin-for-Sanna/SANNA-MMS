/*
  # Member Linking System

  1. New Tables
    - `member_links`
      - `id` (uuid, primary key)
      - `member_id_1` (uuid, references members)
      - `member_id_2` (uuid, references members)
      - `link_status` (enum: pending, active, broken)
      - `consent_member_1` (boolean)
      - `consent_member_2` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `broken_at` (timestamp)
      - `broken_reason` (text)

  2. Changes
    - Add relationship_type to member_relationships table
    - Add last_status_change to members table
    - Add constraints and triggers for data integrity

  3. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Create link status enum
CREATE TYPE link_status AS ENUM ('pending', 'active', 'broken');

-- Create member links table
CREATE TABLE member_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id_1 uuid NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  member_id_2 uuid NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  link_status link_status NOT NULL DEFAULT 'pending',
  consent_member_1 boolean NOT NULL DEFAULT false,
  consent_member_2 boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  broken_at timestamptz,
  broken_reason text,

  -- Ensure members are different
  CONSTRAINT different_members CHECK (member_id_1 < member_id_2),
  
  -- Ensure unique links
  UNIQUE(member_id_1, member_id_2),
  
  -- Validate link status
  CONSTRAINT valid_link_status CHECK (
    (link_status = 'broken' AND broken_at IS NOT NULL AND broken_reason IS NOT NULL) OR
    (link_status != 'broken' AND broken_at IS NULL AND broken_reason IS NULL)
  ),
  
  -- Validate consent for active links
  CONSTRAINT valid_active_link CHECK (
    link_status != 'active' OR (consent_member_1 AND consent_member_2)
  )
);

-- Add last_status_change to members
ALTER TABLE members
ADD COLUMN IF NOT EXISTS last_status_change timestamptz DEFAULT now();

-- Create function to update member status
CREATE OR REPLACE FUNCTION update_member_link_status()
RETURNS TRIGGER AS $$
BEGIN
  -- Update member status based on link changes
  IF TG_OP = 'INSERT' OR (TG_OP = 'UPDATE' AND OLD.link_status != NEW.link_status) THEN
    -- For new active links
    IF NEW.link_status = 'active' THEN
      UPDATE members 
      SET 
        relationship_status = 'coupled',
        last_status_change = now()
      WHERE id IN (NEW.member_id_1, NEW.member_id_2);
    
    -- For broken links
    ELSIF NEW.link_status = 'broken' THEN
      UPDATE members 
      SET 
        relationship_status = 'single',
        last_status_change = now()
      WHERE id IN (NEW.member_id_1, NEW.member_id_2)
      AND NOT EXISTS (
        SELECT 1 FROM member_links
        WHERE link_status = 'active'
        AND (member_id_1 = members.id OR member_id_2 = members.id)
        AND id != NEW.id
      );
    END IF;
  END IF;
  
  -- Update timestamps
  IF TG_OP = 'UPDATE' THEN
    NEW.updated_at = now();
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to validate link creation
CREATE OR REPLACE FUNCTION validate_member_link()
RETURNS TRIGGER AS $$
BEGIN
  -- Check if both members exist and are active
  IF NOT EXISTS (
    SELECT 1 FROM members 
    WHERE id IN (NEW.member_id_1, NEW.member_id_2)
    AND status = 'Active'
  ) THEN
    RAISE EXCEPTION 'Both members must be active to create a link';
  END IF;
  
  -- Check for existing active links
  IF EXISTS (
    SELECT 1 FROM member_links
    WHERE link_status = 'active'
    AND (
      member_id_1 IN (NEW.member_id_1, NEW.member_id_2) OR
      member_id_2 IN (NEW.member_id_1, NEW.member_id_2)
    )
  ) THEN
    RAISE EXCEPTION 'One or both members already have an active link';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER update_link_status
  AFTER INSERT OR UPDATE OF link_status ON member_links
  FOR EACH ROW
  EXECUTE FUNCTION update_member_link_status();

CREATE TRIGGER validate_link_before_insert
  BEFORE INSERT ON member_links
  FOR EACH ROW
  EXECUTE FUNCTION validate_member_link();

-- Enable RLS
ALTER TABLE member_links ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for authenticated users"
  ON member_links FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable link management for authenticated users"
  ON member_links FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create index for faster queries
CREATE INDEX idx_member_links_members 
ON member_links(member_id_1, member_id_2);

CREATE INDEX idx_member_links_status 
ON member_links(link_status);