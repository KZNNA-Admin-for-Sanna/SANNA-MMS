/*
  # Remove Security and Admin Permissions

  1. Changes
    - Drop all admin-related tables
    - Drop all RLS policies
    - Remove all security restrictions
    - Grant public access to all tables
  
  2. Notes
    - This removes all security measures
    - All tables will be publicly accessible
*/

-- Drop admin-related tables
DROP TABLE IF EXISTS admin_audit_logs;
DROP TABLE IF EXISTS admin_users;

-- Disable RLS on all tables
ALTER TABLE members DISABLE ROW LEVEL SECURITY;
ALTER TABLE member_notes DISABLE ROW LEVEL SECURITY;
ALTER TABLE member_stories DISABLE ROW LEVEL SECURITY;
ALTER TABLE member_gallery DISABLE ROW LEVEL SECURITY;
ALTER TABLE email_templates DISABLE ROW LEVEL SECURITY;
ALTER TABLE email_logs DISABLE ROW LEVEL SECURITY;

-- Drop all existing policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON members;
DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON members;
DROP POLICY IF EXISTS "Enable update access for authenticated users" ON members;
DROP POLICY IF EXISTS "Enable delete access for authenticated users" ON members;

DROP POLICY IF EXISTS "Enable read access for authenticated users" ON member_notes;
DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON member_notes;

DROP POLICY IF EXISTS "Members can create their own stories" ON member_stories;
DROP POLICY IF EXISTS "Active members can view stories" ON member_stories;
DROP POLICY IF EXISTS "Members can update their own stories" ON member_stories;
DROP POLICY IF EXISTS "Members can delete their own stories" ON member_stories;

DROP POLICY IF EXISTS "Members can upload their own photos" ON member_gallery;
DROP POLICY IF EXISTS "Active members can view photos" ON member_gallery;
DROP POLICY IF EXISTS "Members can update their own photos" ON member_gallery;
DROP POLICY IF EXISTS "Members can delete their own photos" ON member_gallery;

DROP POLICY IF EXISTS "Allow authenticated users to read email templates" ON email_templates;
DROP POLICY IF EXISTS "Allow authenticated users to create email templates" ON email_templates;
DROP POLICY IF EXISTS "Allow authenticated users to update email templates" ON email_templates;

DROP POLICY IF EXISTS "Allow authenticated users to read email logs" ON email_logs;
DROP POLICY IF EXISTS "Allow authenticated users to create email logs" ON email_logs;

-- Grant public access to all tables
GRANT ALL ON members TO PUBLIC;
GRANT ALL ON member_notes TO PUBLIC;
GRANT ALL ON member_stories TO PUBLIC;
GRANT ALL ON member_gallery TO PUBLIC;
GRANT ALL ON email_templates TO PUBLIC;
GRANT ALL ON email_logs TO PUBLIC;