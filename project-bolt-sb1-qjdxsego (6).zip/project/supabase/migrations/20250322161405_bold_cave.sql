/*
  # Create Members Management Schema

  1. New Tables
    - `members`
      - `id` (uuid, primary key)
      - `inf_stamp_number` (text, unique)
      - `first_name` (text)
      - `surname` (text)
      - `telephone` (text)
      - `town` (text)
      - `suburb` (text)
      - `email` (text)
      - `join_date` (date)
      - `expiry_date` (date)
      - `membership_type` (enum: annual, lifetime, monthly)
      - `last_payment_date` (date)
      - `amount_paid` (decimal)
      - `outstanding_balance` (decimal)
      - `notes` (text)
      - `status` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on members table
    - Add policies for authenticated users to perform CRUD operations
*/

-- Create membership type enum
CREATE TYPE membership_type AS ENUM ('annual', 'lifetime', 'monthly');

-- Create members table
CREATE TABLE IF NOT EXISTS members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  inf_stamp_number text UNIQUE NOT NULL,
  first_name text NOT NULL,
  surname text NOT NULL,
  telephone text,
  town text,
  suburb text,
  email text,
  join_date date NOT NULL,
  expiry_date date,
  membership_type membership_type NOT NULL,
  last_payment_date date,
  amount_paid decimal(10,2) DEFAULT 0,
  outstanding_balance decimal(10,2) DEFAULT 0,
  notes text,
  status text DEFAULT 'Active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE members ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow authenticated users to read members"
  ON members
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert members"
  ON members
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update members"
  ON members
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to delete members"
  ON members
  FOR DELETE
  TO authenticated
  USING (true);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_members_updated_at
  BEFORE UPDATE ON members
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();