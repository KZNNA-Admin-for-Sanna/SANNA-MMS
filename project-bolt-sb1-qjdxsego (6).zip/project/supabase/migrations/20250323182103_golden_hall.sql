/*
  # Add Demo SANNA User

  1. Changes
    - Add demo SANNA member record
    - Set up initial member data
    - Handle duplicate email addresses properly
  
  2. Notes
    - Member will be registered as an active member
    - Email set to marketing@sanna.org.za
*/

-- First ensure any existing demo user is inactive
UPDATE members
SET status = 'Dormant'
WHERE email = 'marketing@sanna.org.za';

-- Then insert new demo user
INSERT INTO members (
  first_name,
  surname,
  email,
  join_date,
  membership_type,
  pna,
  status,
  amount_paid,
  outstanding_balance,
  renewal_amount
) VALUES (
  'SANNA',
  'Admin',
  'marketing@sanna.org.za',
  CURRENT_DATE,
  'honorary',
  'GNA',
  'Active',
  0,
  0,
  0
);