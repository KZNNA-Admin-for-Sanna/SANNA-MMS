/*
  # Remove Lifetime Membership Type

  1. Changes
    - Update membership_type enum to remove 'lifetime' option
    - Convert any existing lifetime memberships to annual
  
  2. Notes
    - Only annual and honorary memberships will be available
    - Existing lifetime members will be converted to annual members
*/

-- First convert any existing lifetime memberships to annual
UPDATE members 
SET membership_type = 'annual'
WHERE membership_type = 'lifetime';

-- Then alter the enum type
ALTER TYPE membership_type RENAME TO membership_type_old;
CREATE TYPE membership_type AS ENUM ('annual', 'honorary');

-- Update the column type
ALTER TABLE members 
  ALTER COLUMN membership_type TYPE membership_type 
  USING membership_type::text::membership_type;

-- Drop the old type
DROP TYPE membership_type_old;