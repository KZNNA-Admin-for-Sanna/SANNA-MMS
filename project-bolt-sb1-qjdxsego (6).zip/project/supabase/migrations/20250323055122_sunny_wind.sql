/*
  # Fix Admin Policies and Permissions

  1. Changes
    - Drop existing policies that depend on materialized view
    - Drop materialized view and related objects
    - Create new simplified policies using direct table checks
    - Add proper permissions for authenticated users
  
  2. Security
    - Maintain same security model with better implementation
    - Allow first admin creation without recursion
    - Allow admin management by existing admins
*/

-- First drop the policies that depend on the materialized view
DROP POLICY IF EXISTS "admin_users_select" ON admin_users;
DROP POLICY IF EXISTS "admin_users_insert_first" ON admin_users;
DROP POLICY IF EXISTS "admin_users_insert" ON admin_users;
DROP POLICY IF EXISTS "admin_users_update" ON admin_users;
DROP POLICY IF EXISTS "admin_users_delete" ON admin_users;

-- Now we can safely drop the materialized view and related objects
DROP MATERIALIZED VIEW IF EXISTS active_admins;
DROP TRIGGER IF EXISTS refresh_active_admins_trigger ON admin_users;
DROP FUNCTION IF EXISTS refresh_active_admins();

-- Create new simplified policies
CREATE POLICY "admin_users_select"
ON admin_users
FOR SELECT
TO authenticated
USING (
  id = auth.uid() OR
  EXISTS (
    SELECT 1 
    FROM admin_users au 
    WHERE au.id = auth.uid() 
    AND au.is_active = true
  )
);

CREATE POLICY "admin_users_insert_first"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  NOT EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE is_active = true
  )
);

CREATE POLICY "admin_users_insert"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM admin_users au 
    WHERE au.id = auth.uid() 
    AND au.is_active = true
  )
);

CREATE POLICY "admin_users_update"
ON admin_users
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au 
    WHERE au.id = auth.uid() 
    AND au.is_active = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM admin_users au 
    WHERE au.id = auth.uid() 
    AND au.is_active = true
  )
);

CREATE POLICY "admin_users_delete"
ON admin_users
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users au 
    WHERE au.id = auth.uid() 
    AND au.is_active = true
  )
);

-- Grant necessary permissions
GRANT ALL ON admin_users TO authenticated;
GRANT ALL ON admin_audit_logs TO authenticated;