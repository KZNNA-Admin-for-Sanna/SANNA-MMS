/*
  # Update Member Status Classification

  1. Changes
    - Update member status rules based on renewal date
    - Add automatic status updates based on renewal date
    - Add validation for renewal dates
  
  2. Notes
    - Active: Membership renewed within last 11 months
    - Expiring Soon: Between 11-12 months since renewal
    - Dormant: No renewal date or renewal date exceeded 12 months
*/

-- Create function to calculate months between dates
CREATE OR REPLACE FUNCTION months_between(start_date date, end_date date)
RETURNS integer AS $$
BEGIN
  RETURN (
    (EXTRACT(year FROM end_date) - EXTRACT(year FROM start_date)) * 12 +
    (EXTRACT(month FROM end_date) - EXTRACT(month FROM start_date))
  );
END;
$$ LANGUAGE plpgsql;

-- Update the validate_renewal_date function
CREATE OR REPLACE FUNCTION validate_renewal_date()
RETURNS TRIGGER AS $$
BEGIN
  -- Only validate for annual members
  IF NEW.membership_type = 'annual' THEN
    -- Ensure renewal date is after join date if both are set
    IF NEW.date_renewed IS NOT NULL AND NEW.join_date IS NOT NULL THEN
      IF NEW.date_renewed < NEW.join_date THEN
        RAISE EXCEPTION 'Renewal date cannot be before join date';
      END IF;
    END IF;

    -- Calculate months since renewal
    IF NEW.date_renewed IS NOT NULL THEN
      DECLARE
        months_since_renewal integer;
      BEGIN
        months_since_renewal := months_between(NEW.date_renewed::date, CURRENT_DATE);
        
        -- Set status based on months since renewal
        IF months_since_renewal < 11 THEN
          NEW.status := 'Active';
        ELSIF months_since_renewal >= 11 AND months_since_renewal < 12 THEN
          -- Keep status as Active but will be marked as "Expiring Soon" in the UI
          NEW.status := 'Active';
        ELSE
          NEW.status := 'Dormant';
        END IF;
      END;
    ELSE
      -- No renewal date means dormant
      NEW.status := 'Dormant';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Update existing members based on new rules
DO $$
BEGIN
  UPDATE members
  SET status = CASE
    WHEN membership_type = 'honorary' THEN status
    WHEN date_renewed IS NULL THEN 'Dormant'
    WHEN months_between(date_renewed::date, CURRENT_DATE) >= 12 THEN 'Dormant'
    ELSE 'Active'
  END
  WHERE membership_type = 'annual';
END $$;