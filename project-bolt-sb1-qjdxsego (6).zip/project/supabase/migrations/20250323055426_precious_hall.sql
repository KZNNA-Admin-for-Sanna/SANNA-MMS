/*
  # Fix Admin User Policies Recursion

  1. Changes
    - Drop existing policies that cause recursion
    - Create new simplified policies without recursive checks
    - Add basic security checks for admin operations
  
  2. Security
    - Maintain secure access control
    - Prevent unauthorized access
    - Allow first admin creation
*/

-- Drop existing policies
DROP POLICY IF EXISTS "admin_users_select" ON admin_users;
DROP POLICY IF EXISTS "admin_users_insert_first" ON admin_users;
DROP POLICY IF EXISTS "admin_users_insert" ON admin_users;
DROP POLICY IF EXISTS "admin_users_update" ON admin_users;
DROP POLICY IF EXISTS "admin_users_delete" ON admin_users;

-- Create new simplified policies
CREATE POLICY "admin_users_select_self"
ON admin_users
FOR SELECT
TO authenticated
USING (id = auth.uid());

CREATE POLICY "admin_users_select_admin"
ON admin_users
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid() 
    AND is_active = true
    LIMIT 1
  )
);

CREATE POLICY "admin_users_insert_first"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  NOT EXISTS (
    SELECT 1 
    FROM admin_users 
    LIMIT 1
  )
);

CREATE POLICY "admin_users_insert_admin"
ON admin_users
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid() 
    AND is_active = true
    LIMIT 1
  )
);

CREATE POLICY "admin_users_update_admin"
ON admin_users
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid() 
    AND is_active = true
    LIMIT 1
  )
);

CREATE POLICY "admin_users_delete_admin"
ON admin_users
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid() 
    AND is_active = true
    LIMIT 1
  )
);

-- Ensure proper permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON admin_users TO authenticated;
GRANT SELECT, INSERT ON admin_audit_logs TO authenticated;