/*
  # Add Membership Payment Tracking

  1. Changes
    - Add function to calculate current year's membership fee
    - Add function to update member payment totals
    - Create trigger to automatically update payment totals
  
  2. Notes
    - Uses current year's fee rate for active and dormant members
    - Maintains historical payment records
*/

-- Function to get current year's membership fee
CREATE OR REPLACE FUNCTION get_current_membership_fee()
RETURNS numeric AS $$
DECLARE
  current_fee numeric;
BEGIN
  SELECT amount INTO current_fee
  FROM membership_fees
  WHERE year = EXTRACT(YEAR FROM CURRENT_DATE);
  
  RETURN COALESCE(current_fee, 330.00); -- Default to 330 if no fee is set
END;
$$ LANGUAGE plpgsql;

-- Function to update member payment totals
CREATE OR REPLACE FUNCTION update_member_payment_totals()
RETURNS TRIGGER AS $$
BEGIN
  -- Only update payment fields for non-honorary members
  IF NEW.membership_type != 'honorary' THEN
    -- Get current year's fee
    NEW.renewal_amount := get_current_membership_fee();
    
    -- For active and dormant members, use current year's rate
    IF NEW.status IN ('Active', 'Dormant') THEN
      -- If this is a new member or first renewal
      IF OLD IS NULL OR OLD.amount_paid = 0 THEN
        NEW.amount_paid := NEW.renewal_amount;
        NEW.outstanding_balance := 0;
      END IF;
    END IF;
  ELSE
    -- Honorary members don't pay fees
    NEW.renewal_amount := 0;
    NEW.outstanding_balance := 0;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for member payment updates
DROP TRIGGER IF EXISTS update_member_payments ON members;
CREATE TRIGGER update_member_payments
  BEFORE INSERT OR UPDATE OF status, membership_type
  ON members
  FOR EACH ROW
  EXECUTE FUNCTION update_member_payment_totals();

-- Update existing members with current fees
UPDATE members
SET 
  renewal_amount = CASE 
    WHEN membership_type = 'honorary' THEN 0 
    ELSE get_current_membership_fee()
  END,
  amount_paid = CASE 
    WHEN membership_type = 'honorary' THEN 0
    WHEN status IN ('Active', 'Dormant') THEN get_current_membership_fee()
    ELSE amount_paid
  END
WHERE TRUE;