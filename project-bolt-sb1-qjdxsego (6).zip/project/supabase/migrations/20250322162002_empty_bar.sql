/*
  # Add renewal tracking fields

  1. Changes
    - Add `date_renewed` column to track when membership was last renewed
    - Add `renewal_amount` column to track the amount paid for renewal
  
  2. Notes
    - Both fields are nullable since they may not be applicable for new members
    - renewal_amount uses numeric(10,2) for precise currency handling
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'members' AND column_name = 'date_renewed'
  ) THEN
    ALTER TABLE members ADD COLUMN date_renewed date;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'members' AND column_name = 'renewal_amount'
  ) THEN
    ALTER TABLE members ADD COLUMN renewal_amount numeric(10,2) DEFAULT 0;
  END IF;
END $$;