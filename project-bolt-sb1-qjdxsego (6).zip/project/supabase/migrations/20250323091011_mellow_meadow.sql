/*
  # Create Admin Actions Table

  1. New Tables
    - `admin_actions`
      - `id` (uuid, primary key)
      - `action_type` (text)
      - `target_member_id` (uuid, references members)
      - `executed_by` (uuid, references auth.users)
      - `reason` (text)
      - `details` (jsonb)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow authenticated users to read admin actions" ON admin_actions;
DROP POLICY IF EXISTS "Allow authenticated users to create admin actions" ON admin_actions;

-- Create or update the admin_actions table
CREATE TABLE IF NOT EXISTS admin_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action_type text NOT NULL,
  target_member_id uuid REFERENCES members(id) ON DELETE SET NULL,
  executed_by uuid REFERENCES auth.users(id),
  reason text NOT NULL,
  details jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE admin_actions ENABLE ROW LEVEL SECURITY;

-- Create new policies
CREATE POLICY "admin_actions_read"
ON admin_actions FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "admin_actions_insert"
ON admin_actions FOR INSERT
TO authenticated
WITH CHECK (true);