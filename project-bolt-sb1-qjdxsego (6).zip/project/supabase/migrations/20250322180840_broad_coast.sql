/*
  # Add member stories and gallery tables

  1. New Tables
    - member_stories
      - id (uuid, primary key)
      - member_id (uuid, foreign key to members)
      - title (text)
      - content (text)
      - created_at (timestamp)
      - updated_at (timestamp)
    
    - member_gallery
      - id (uuid, primary key)
      - member_id (uuid, foreign key to members)
      - photo_url (text)
      - caption (text, optional)
      - created_at (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for CRUD operations based on member status
*/

-- Create member stories table
CREATE TABLE IF NOT EXISTS member_stories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id uuid REFERENCES members(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create member gallery table
CREATE TABLE IF NOT EXISTS member_gallery (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id uuid REFERENCES members(id) ON DELETE CASCADE,
  photo_url text NOT NULL,
  caption text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE member_stories ENABLE ROW LEVEL SECURITY;
ALTER TABLE member_gallery ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ BEGIN
  DROP POLICY IF EXISTS "Members can create their own stories" ON member_stories;
  DROP POLICY IF EXISTS "Active members can view stories" ON member_stories;
  DROP POLICY IF EXISTS "Members can update their own stories" ON member_stories;
  DROP POLICY IF EXISTS "Members can delete their own stories" ON member_stories;
  
  DROP POLICY IF EXISTS "Members can upload their own photos" ON member_gallery;
  DROP POLICY IF EXISTS "Active members can view photos" ON member_gallery;
  DROP POLICY IF EXISTS "Members can update their own photos" ON member_gallery;
  DROP POLICY IF EXISTS "Members can delete their own photos" ON member_gallery;
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;

-- Policies for member_stories
CREATE POLICY "Members can create their own stories"
ON member_stories
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM members
    WHERE id = member_id
    AND status = 'Active'
  )
);

CREATE POLICY "Active members can view stories"
ON member_stories
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM members
    WHERE id = member_id
    AND status = 'Active'
  )
);

CREATE POLICY "Members can update their own stories"
ON member_stories
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM members
    WHERE id = member_id
    AND status = 'Active'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM members
    WHERE id = member_id
    AND status = 'Active'
  )
);

CREATE POLICY "Members can delete their own stories"
ON member_stories
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM members
    WHERE id = member_id
    AND status = 'Active'
  )
);

-- Policies for member_gallery
CREATE POLICY "Members can upload their own photos"
ON member_gallery
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM members
    WHERE id = member_id
    AND status = 'Active'
  )
);

CREATE POLICY "Active members can view photos"
ON member_gallery
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM members
    WHERE id = member_id
    AND status = 'Active'
  )
);

CREATE POLICY "Members can update their own photos"
ON member_gallery
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM members
    WHERE id = member_id
    AND status = 'Active'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM members
    WHERE id = member_id
    AND status = 'Active'
  )
);

CREATE POLICY "Members can delete their own photos"
ON member_gallery
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM members
    WHERE id = member_id
    AND status = 'Active'
  )
);