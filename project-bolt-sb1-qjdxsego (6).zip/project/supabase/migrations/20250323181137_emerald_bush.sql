/*
  # Fix Auth User Registration

  1. Changes
    - Drop existing auth triggers
    - Create new function to handle auth user creation
    - Add better error handling and validation
    - Fix member linking process
  
  2. Security
    - Ensure proper member validation
    - Prevent duplicate registrations
    - Add proper error messages
*/

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_auth_user_created();

-- Create improved function to handle auth user creation
CREATE OR REPLACE FUNCTION handle_auth_user_created()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  matching_member RECORD;
BEGIN
  -- Find matching member with detailed info
  SELECT *
  INTO matching_member
  FROM members
  WHERE 
    email = NEW.email 
    AND status = 'Active'
    AND auth_user_id IS NULL;

  -- Validate member exists
  IF matching_member IS NULL THEN
    RAISE EXCEPTION 'No matching active member found for email %', NEW.email;
  END IF;

  -- Update member record with auth user ID
  UPDATE members
  SET 
    auth_user_id = NEW.id,
    updated_at = now()
  WHERE id = matching_member.id;

  -- Update auth user metadata
  UPDATE auth.users
  SET 
    raw_user_meta_data = jsonb_build_object(
      'member_id', matching_member.id,
      'first_name', matching_member.first_name,
      'last_name', matching_member.surname,
      'inf_number', matching_member.inf_stamp_number
    ),
    updated_at = now()
  WHERE id = NEW.id;

  RETURN NEW;
END;
$$;

-- Create new trigger with better error handling
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_auth_user_created();

-- Recreate index for performance
DROP INDEX IF EXISTS idx_members_email_status;
CREATE INDEX idx_members_email_status 
ON members(email, status) 
WHERE auth_user_id IS NULL;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION handle_auth_user_created() TO service_role;