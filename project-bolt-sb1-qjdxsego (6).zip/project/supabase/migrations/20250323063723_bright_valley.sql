-- Remove all RLS policies that restrict profile access based on payment status
DROP POLICY IF EXISTS "Members can create their own stories" ON member_stories;
DROP POLICY IF EXISTS "Active members can view stories" ON member_stories;
DROP POLICY IF EXISTS "Members can update their own stories" ON member_stories;
DROP POLICY IF EXISTS "Members can delete their own stories" ON member_stories;

DROP POLICY IF EXISTS "Members can upload their own photos" ON member_gallery;
DROP POLICY IF EXISTS "Active members can view photos" ON member_gallery;
DROP POLICY IF EXISTS "Members can update their own photos" ON member_gallery;
DROP POLICY IF EXISTS "Members can delete their own photos" ON member_gallery;

-- Create new policies that allow access based on member ownership only
CREATE POLICY "Members can manage their own stories"
ON member_stories
FOR ALL
TO authenticated
USING (member_id = (SELECT id FROM members WHERE id = member_id))
WITH CHECK (member_id = (SELECT id FROM members WHERE id = member_id));

CREATE POLICY "Members can manage their own photos"
ON member_gallery
FOR ALL
TO authenticated
USING (member_id = (SELECT id FROM members WHERE id = member_id))
WITH CHECK (member_id = (SELECT id FROM members WHERE id = member_id));

-- Grant necessary permissions
GRANT ALL ON member_stories TO authenticated;
GRANT ALL ON member_gallery TO authenticated;