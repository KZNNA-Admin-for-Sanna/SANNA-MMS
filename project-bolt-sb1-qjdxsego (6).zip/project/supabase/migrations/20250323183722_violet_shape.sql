/*
  # Fix Auth Flow and Permissions

  1. Changes
    - Drop and recreate auth trigger with better timing
    - Add proper transaction isolation
    - Fix permission issues
    - Add indexes for performance
*/

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_auth_user_created();

-- Create improved function to handle auth user creation
CREATE OR REPLACE FUNCTION handle_auth_user_created()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  v_member_id uuid;
  v_member RECORD;
BEGIN
  -- Get member_id from metadata if present
  IF NEW.raw_user_meta_data->>'member_id' IS NOT NULL THEN
    v_member_id := (NEW.raw_user_meta_data->>'member_id')::uuid;
    
    -- Find member record
    SELECT * INTO v_member
    FROM members
    WHERE id = v_member_id
    AND auth_user_id IS NULL
    FOR UPDATE SKIP LOCKED;
    
    IF FOUND THEN
      -- Update member record
      UPDATE members
      SET 
        auth_user_id = NEW.id,
        updated_at = now()
      WHERE id = v_member_id;
      
      RETURN NEW;
    END IF;
  END IF;

  -- If no member_id or not found, try email
  SELECT * INTO v_member
  FROM members
  WHERE 
    email = NEW.email
    AND status = 'Active'
    AND auth_user_id IS NULL
  FOR UPDATE SKIP LOCKED;
  
  IF FOUND THEN
    -- Update member record
    UPDATE members
    SET 
      auth_user_id = NEW.id,
      updated_at = now()
    WHERE id = v_member.id;
  END IF;

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log error but don't fail
  RAISE WARNING 'Error in handle_auth_user_created: %', SQLERRM;
  RETURN NEW;
END;
$$;

-- Create new trigger
CREATE TRIGGER on_auth_user_created
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_auth_user_created();

-- Drop and recreate indexes
DROP INDEX IF EXISTS idx_members_auth_user;
DROP INDEX IF EXISTS idx_members_email_status;

CREATE INDEX idx_members_auth_user 
ON members(auth_user_id) 
WHERE auth_user_id IS NOT NULL;

CREATE INDEX idx_members_email_status 
ON members(email, status) 
WHERE auth_user_id IS NULL;

-- Reset permissions
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon, authenticated;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM anon, authenticated;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon, authenticated;

-- Grant base permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- Grant table permissions
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon, authenticated;
GRANT ALL ON members TO authenticated;
GRANT ALL ON member_notes TO authenticated;
GRANT ALL ON member_stories TO authenticated;
GRANT ALL ON member_gallery TO authenticated;
GRANT ALL ON email_templates TO authenticated;
GRANT ALL ON email_logs TO authenticated;
GRANT ALL ON membership_fees TO authenticated;

-- Grant sequence permissions
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;

-- Grant function permissions
GRANT EXECUTE ON FUNCTION handle_auth_user_created TO service_role;